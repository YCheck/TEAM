//
//  CoreObject+Hospital.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/13.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CoreObject_Hospital : NSObject

@property (nonatomic, copy) NSString *id;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *hospitalAddress;
@property (nonatomic, copy) NSString *gid;


@property (nonatomic,assign) BOOL isSelected;//是否被选中

@end
