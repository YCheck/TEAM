//
//  CoreObject+Bill.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/23.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "CoreObject+Bill.h"

@implementation CoreObject_Bill



@end
