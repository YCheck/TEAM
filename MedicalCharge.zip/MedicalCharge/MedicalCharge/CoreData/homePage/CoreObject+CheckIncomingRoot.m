//
//  CoreObject+CheckIncomingRoot.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/5.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "CoreObject+CheckIncomingRoot.h"

@implementation CoreObject_CheckIncomingRoot

+(NSDictionary *)mj_objectClassInArray{
    return @{@"detailsList":@"CoreObject_CheckIncoming"};
}

@end
