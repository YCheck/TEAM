//
//  CoreObject+ReadySingleRoot.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/13.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "CoreObject+ReadySingleRoot.h"

@implementation CoreObject_ReadySingleRoot

+(NSDictionary *)mj_objectClassInArray{
    return @{@"list":@"CoreObject_ReadySingle"};
}

@end
