//
//  CoreObject+Bill.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/23.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CoreObject_Bill : NSObject
@property (nonatomic, copy) NSString *gid;
//对账单请求
@property (nonatomic, copy) NSString *requestNumber;
@property (nonatomic, copy) NSString *hospitalName;
@property (nonatomic, copy) NSString *hospitalGuid;
@property (nonatomic, copy) NSString *handleStatus;
@property (nonatomic, copy) NSString *reconciliationDate1;
@property (nonatomic, copy) NSString *reconciliationDate2;
@property (nonatomic, copy) NSString *createTime;

//已请求对账单
@property (nonatomic, copy) NSString *confirmStatus;
@property (nonatomic, copy) NSString *actualAmount;//实际金额
@property (nonatomic, copy) NSString *pretendAmount;//形式入库金额
@property (nonatomic, copy) NSString *returnAmount;//退货金额
@property (nonatomic, copy) NSString *reconciliationAmount;//应付金额

@end
