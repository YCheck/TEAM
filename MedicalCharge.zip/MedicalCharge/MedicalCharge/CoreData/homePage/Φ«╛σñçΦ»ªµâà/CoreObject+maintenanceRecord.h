//
//  CoreObject+maintenanceRecord.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/24.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CoreObject_maintenanceRecord : NSObject


@property (nonatomic, copy) NSString *repairUser;
@property (nonatomic, copy) NSString *businessNumber;
@property (nonatomic, copy) NSString *departmentName;
@property (nonatomic, copy) NSString *maintenanceStage;//处理阶段
@property (nonatomic, copy) NSString *maintenanceType;//维修方式
@property (nonatomic, copy) NSString *specification;
@property (nonatomic, copy) NSString *repairTime;
@end
