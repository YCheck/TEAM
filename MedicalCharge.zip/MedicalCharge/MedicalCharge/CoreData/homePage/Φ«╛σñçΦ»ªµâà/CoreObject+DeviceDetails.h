//
//  CoreObject+DeviceDetails.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/24.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CoreObject_DeviceDetails : NSObject
@property (nonatomic, copy) NSString *applyId;
@property (nonatomic, copy) NSString *applyGuid;
@property (nonatomic, copy) NSString *id;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *hospitalGuid;
@property (nonatomic, copy) NSString *materialNumber;//编号
@property (nonatomic, copy) NSString *maintenanceStage;//处理阶段
@property (nonatomic, copy) NSString *maintenanceType;//维修方式
@property (nonatomic, copy) NSString *specification;
@property (nonatomic, copy) NSString *model;
@property (nonatomic, copy) NSString *brand;//品牌
@property (nonatomic, copy) NSString *worth;//设备价值
@property (nonatomic, copy) NSString *useDepartment;//使用科室
@property (nonatomic, copy) NSString *responsible;//负责人
@property (nonatomic, copy) NSString *responsiblePhone;
@property (nonatomic, copy) NSString *departmentName;
@property (nonatomic, copy) NSString *useStatus;
@property (nonatomic, copy) NSString *unit;
@property (nonatomic, copy) NSString *manufacturer;//生产厂家
@property (nonatomic, copy) NSString *repairUser;//报修人
@property (nonatomic, copy) NSString *registrationNumber;//注册证号
@property (nonatomic, copy) NSString *repairTime;
@property (nonatomic, copy) NSString *supplierName;//供应商
@property (nonatomic, copy) NSString *faultDescription;
@property (nonatomic, copy) NSString *completionDate;//验收日期
@property (nonatomic, copy) NSString *acceptanceComments;//验收描述

@property (nonatomic,retain) NSArray *imgList;
@end
