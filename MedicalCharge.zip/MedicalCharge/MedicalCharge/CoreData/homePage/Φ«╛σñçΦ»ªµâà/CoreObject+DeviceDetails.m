//
//  CoreObject+DeviceDetails.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/24.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "CoreObject+DeviceDetails.h"

@implementation CoreObject_DeviceDetails

@end
