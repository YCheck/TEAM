//
//  CoreObject+CheckIncoming.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/5.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CoreObject_CheckIncoming : NSObject

@property (nonatomic, copy) NSString *gid;//订单id
@property (nonatomic, copy) NSString *quantity;//数量
@property (nonatomic, copy) NSString *price;//单价
@property (nonatomic, copy) NSString *unit;//单位
@property (nonatomic, copy) NSString *specification;//规格
@property (nonatomic, copy) NSString *packing;//包装规格
@property (nonatomic, copy) NSString *model;//型号
@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *noAcceptanceQuantity;//未验收数量
@property (nonatomic, copy) NSString *acceptanceQuantity;//已验收数量
@property (nonatomic, copy) NSString *acceptanceResult;//验收状态
@property (nonatomic, copy) NSString *batchNumber;//批号
@property (nonatomic, copy) NSString *serialNumber;//序列号
@property (nonatomic, copy) NSString *materialNumber;//编号
@property (nonatomic, copy) NSString *valid;//有效期
@property (nonatomic, copy) NSString *manufacturer;//厂家

@property (nonatomic, copy) NSString *serialNum;//序列号
@property (nonatomic, copy) NSString *productNum;//编号

@end
