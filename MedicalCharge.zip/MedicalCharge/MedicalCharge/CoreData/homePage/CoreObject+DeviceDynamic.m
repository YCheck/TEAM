//
//  CoreObject+DeviceDynamic.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/9.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "CoreObject+DeviceDynamic.h"

@implementation CoreObject_DeviceDynamic



@end
