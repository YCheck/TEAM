//
//  CoreObject+CheckIncomingRoot.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/5.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CoreObject+CheckIncoming.h"
@interface CoreObject_CheckIncomingRoot : NSObject

@property (nonatomic,assign) BOOL isShow;//是否展开cell

@property (nonatomic, copy) NSString *id;
@property (nonatomic, copy) NSString *gid;//订单id
@property (nonatomic, copy) NSString *businessNumber;
@property (nonatomic, copy) NSString *orderTime;
@property (nonatomic, copy) NSString *acceptanceResult;
@property (nonatomic, copy) NSString *orderStage;//订单状态
@property (nonatomic, copy) NSString *orderStageColor;

@property (nonatomic, copy) NSString *hospitalGUID;
@property (nonatomic, copy) NSString *hospitalGuid;
@property (nonatomic, copy) NSString *hospitalName;
@property (nonatomic, copy) NSString *supplierName;//供应商
@property (nonatomic, copy) NSString *departmentName;
@property (nonatomic, copy) NSString *totalAmount;

@property (nonatomic,retain) NSArray *detailsList;

@end
