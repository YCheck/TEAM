//
//  CoreObject+ReadySingleRoot.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/13.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CoreObject+ReadySingle.h"

@interface CoreObject_ReadySingleRoot : NSObject

@property (nonatomic,assign) BOOL isShow;//是否展开cell

@property (nonatomic, copy) NSString *id;
@property (nonatomic,retain) NSArray *list;


@end
