//
//  CoreObject+RecordList.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/21.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "CoreObject+RecordList.h"

@implementation CoreObject_RecordList

@end
