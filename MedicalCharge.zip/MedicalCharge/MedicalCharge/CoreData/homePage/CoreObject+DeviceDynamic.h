//
//  CoreObject+DeviceDynamic.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/9.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CoreObject_DeviceDynamic : NSObject

@property (nonatomic, copy) NSString *id;//设备id
@property (nonatomic, copy) NSString *gid;//设备guid
@property (nonatomic, copy) NSString *hospitalGuid;//医院guid
@property (nonatomic, copy) NSString *materialNumber;//编号
@property (nonatomic, copy) NSString *specification;//规格
@property (nonatomic, copy) NSString *useDepartment;//设备所属科室
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *useStatus;

@property (nonatomic,assign) BOOL isSelected;//是否被选中

@end
