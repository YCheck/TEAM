//
//  CoreObject+MaintenanceDetails.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/19.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "CoreObject+MaintenanceDetails.h"

@implementation CoreObject_MaintenanceDetails

+(NSDictionary *)mj_objectClassInArray{
    return @{@"hospitalProcessList":@"CoreObject_MaintenanceList",@"outHospitalProcessList":@"CoreObject_MaintenanceList",@"repairFeeList":@"CoreObject_RepairFee",@"replacingFittingList":@"CoreObject_PartMessage",@"evaluationList":@"CoreObject_CheckMessage"};
}

@end
