//
//  CoreObject+RepairFee.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/19.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "CoreObject+RepairFee.h"

@implementation CoreObject_RepairFee

@end
