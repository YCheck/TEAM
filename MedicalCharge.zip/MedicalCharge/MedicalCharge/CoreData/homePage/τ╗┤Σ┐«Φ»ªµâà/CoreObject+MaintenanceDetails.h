//
//  CoreObject+MaintenanceDetails.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/19.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CoreObject+MaintenanceList.h"
#import "CoreObject+RepairFee.h"
#import "CoreObject+PartMessage.h"
#import "CoreObject+CheckMessage.h"
@interface CoreObject_MaintenanceDetails : NSObject

@property (nonatomic, copy) NSString *applyId;
@property (nonatomic, copy) NSString *applyGuid;
@property (nonatomic, copy) NSString *id;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *businessNumber;//编号
@property (nonatomic, copy) NSString *maintenanceStage;//处理阶段
@property (nonatomic, copy) NSString *maintenanceType;//维修方式
@property (nonatomic, copy) NSString *specification;
@property (nonatomic, copy) NSString *model;
@property (nonatomic, copy) NSString *worth;//设备价值
@property (nonatomic, copy) NSString *responsible;//科室负责人
@property (nonatomic, copy) NSString *departmentName;
@property (nonatomic, copy) NSString *departmentID;
@property (nonatomic, copy) NSString *manufacturer;//生产厂家
@property (nonatomic, copy) NSString *repairUser;//报修人
@property (nonatomic, copy) NSString *repairTime;
@property (nonatomic, copy) NSString *acceptanceUser;//审核人
@property (nonatomic, copy) NSString *AccountingID;
@property (nonatomic, copy) NSString *faultDescription;
@property (nonatomic, copy) NSString *completionDate;//验收日期
@property (nonatomic, copy) NSString *acceptanceComments;//验收描述

@property (nonatomic, copy) NSString *processTime;//处理时间
@property (nonatomic, copy) NSString *maintenanceStartDate;//维修开始时间
@property (nonatomic, copy) NSString *hospitalName;
@property (nonatomic, copy) NSString *hospitalGUID;
@property (nonatomic, copy) NSString *hospitalId;
@property (nonatomic, copy) NSString *engineerName;//维修工程师
@property (nonatomic, copy) NSString *faultAnalysis;//原因分析
@property (nonatomic, copy) NSString *maintenanceEndDate;//维修结束时间
@property (nonatomic, copy) NSString *totalRepairPrice;//维修总费用
@property (nonatomic, copy) NSString *longShutdown;//停机时长
@property (nonatomic, copy) NSString *manHour;//维修工时

@property (nonatomic, retain) NSArray *maintenanceEngineer;//维修工程师合集
@property (nonatomic, retain) NSArray *attachmentUrl;//附件路径

@property (nonatomic,retain) NSArray *hospitalProcessList;//院内维修
@property (nonatomic,retain) NSArray *outHospitalProcessList;//院外维修
@property (nonatomic,retain) NSArray *repairFeeList;//维修费用
@property (nonatomic,retain) NSArray *replacingFittingList;//配件信息
@property (nonatomic,retain) NSArray *evaluationList;//验收信息


@end
