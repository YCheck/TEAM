//
//  CoreObject+PartMessage.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/19.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CoreObject_PartMessage : NSObject

@property (nonatomic, copy) NSString *name;//名称
@property (nonatomic, copy) NSString *quantity;//数量
@property (nonatomic, retain) NSString *prict;//单价
@property (nonatomic, copy) NSString *fundSource;
@property (nonatomic,retain) NSString *price;//维修费用
@property (nonatomic,retain) NSString *unitName;//单位
@property (nonatomic,retain) NSString *model;//型号
@property (nonatomic,retain) NSString *placeOriginName;//产地
@property (nonatomic,retain) NSString *specification;//厂家
@property (nonatomic, copy) NSString *supplierName;//供应商
@property (nonatomic, copy) NSString *serialNumber;//序列号
@property (nonatomic, retain) NSString *factoryTime;//出厂时间
@property (nonatomic,retain) NSString *factoryCode;//出厂编号

@end
