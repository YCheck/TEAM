//
//  CoreObject+RepairFee.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/19.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CoreObject_RepairFee : NSObject
@property (nonatomic, copy) NSString *id;
@property (nonatomic, copy) NSString *feeName;//名称
@property (nonatomic, copy) NSString *feeType;//维修类型
@property (nonatomic, copy) NSString *fundSource;//资金来源
@property (nonatomic, copy) NSString *quotePrice;//计划金额
@property (nonatomic, copy) NSString *actualPrice;//实际金额
@property (nonatomic, copy) NSString *remark;//备注
@end
