//
//  CoreObject+CheckMessage.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/19.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "CoreObject+CheckMessage.h"

@implementation CoreObject_CheckMessage

@end
