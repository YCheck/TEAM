//
//  CoreObject+MaintenanceList.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/19.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CoreObject_MaintenanceList : NSObject

@property (nonatomic, copy) NSString *id;
@property (nonatomic, copy) NSString *maintenanceLevelName;//维修级别
@property (nonatomic, copy) NSString *faultAnalysisName;//原因分析
@property (nonatomic, copy) NSString *processTime;//处理时间
@property (nonatomic, copy) NSString *maintenanceStartDate;//开始时间
@property (nonatomic, copy) NSString *maintenanceEndDate;//结束时间
@property (nonatomic, copy) NSString *manHour;//维修时长
@property (nonatomic, copy) NSString *longShutdown;//停机时长
@property (nonatomic, copy) NSString *testUser;//测试人员
@property (nonatomic, copy) NSString *maintenanceSituation;//处理情况

@end
