//
//  CoreObject+CheckMessage.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/19.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CoreObject_CheckMessage : NSObject

@property (nonatomic, copy) NSString *id;
@property (nonatomic, copy) NSString *engineerName;//名称
@property (nonatomic, copy) NSString *maintenanceType;//维修类型
@property (nonatomic, copy) NSString *serviceEvaluation;//资金来源
@property (nonatomic, copy) NSString *evaluationComment;//计划金额

@end
