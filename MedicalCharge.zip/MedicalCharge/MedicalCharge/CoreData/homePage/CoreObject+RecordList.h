//
//  CoreObject+RecordList.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/21.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CoreObject_RecordList : NSObject

@property (nonatomic, copy) NSString *id;
@property (nonatomic, copy) NSString *maintenanceEngineer;
@property (nonatomic, copy) NSString *maintenanceStartDate;
@property (nonatomic, copy) NSString *maintenanceEndDate;
@property (nonatomic, copy) NSString *manHour;
@property (nonatomic, copy) NSString *longShutdown;
@property (nonatomic, copy) NSString *maintenanceSituation;

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *fittingType;
@property (nonatomic, copy) NSString *price;

@property (nonatomic, copy) NSString *feeName;
@property (nonatomic, copy) NSString *quotePrice;
@property (nonatomic, copy) NSString *actualPrice;
@property (nonatomic, copy) NSString *fundSource;

@end
