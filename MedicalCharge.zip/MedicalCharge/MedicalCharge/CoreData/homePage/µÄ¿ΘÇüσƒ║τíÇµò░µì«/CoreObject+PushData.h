//
//  CoreObject+PushData.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/22.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CoreObject_PushData : NSObject

@property (nonatomic, copy) NSString *id;
@property (nonatomic, copy) NSString *model;
@property (nonatomic, copy) NSString *specification;
@property (nonatomic, copy) NSString *price;

@end
