//
//  CoreObject+PushDataRoot.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/22.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "CoreObject+PushDataRoot.h"

@implementation CoreObject_PushDataRoot
+(NSDictionary *)mj_objectClassInArray{
    return @{@"listMany":@"CoreObject_PushData"};
}
@end
