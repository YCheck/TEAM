//
//  CoreObject+PushDataRoot.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/22.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CoreObject+PushData.h"
@interface CoreObject_PushDataRoot : NSObject
@property (nonatomic,assign) BOOL isShow;//是否展开cell

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *manufacturerName;
@property (nonatomic, copy) NSString *registrationNumber;
@property (nonatomic, copy) NSString *price;

@property (nonatomic, retain) NSArray *hospitalGuid;
@property (nonatomic, retain) NSArray *listMany;

@end
