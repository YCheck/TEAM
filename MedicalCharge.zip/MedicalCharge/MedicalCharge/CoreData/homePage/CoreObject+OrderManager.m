//
//  CoreObject+OrderManager.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/11.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "CoreObject+OrderManager.h"

@implementation CoreObject_OrderManager

@end
