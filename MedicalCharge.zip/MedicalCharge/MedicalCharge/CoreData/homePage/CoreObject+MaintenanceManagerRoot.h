//
//  CoreObject_MaintenanceManagerRoot.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/6.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CoreObject_MaintenanceManagerRoot : NSObject
@property (nonatomic,assign) BOOL isShow;//是否展开cell

@property (nonatomic, copy) NSString *id;
@property (nonatomic, copy) NSString *gid;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *businessNumber;//编号
@property (nonatomic, copy) NSString *hospitalGuid;
@property (nonatomic, copy) NSString *repairTime;
@property (nonatomic, copy) NSString *departmentName;
@property (nonatomic, copy) NSString *maintenanceStage;
@property (nonatomic, copy) NSString *faultDescription;
@property (nonatomic, assign) BOOL scanTiming;//当前登陆人是否能计时
@property (nonatomic, assign) BOOL checkIn;//当前登陆人是否能维修登记
@property (nonatomic, retain) NSArray *imgList;//报修图片


@property (nonatomic, assign) NSInteger contentHeight;//下拉后cell显示高度

@end
