//
//  CoreObject+OrderManagerRoot.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/11.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "CoreObject+OrderManagerRoot.h"

@implementation CoreObject_OrderManagerRoot

+(NSDictionary *)mj_objectClassInArray{
    return @{@"list":@"CoreObject_OrderManager"};
}

@end
