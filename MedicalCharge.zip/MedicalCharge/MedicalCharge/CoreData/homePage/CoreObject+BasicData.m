//
//  CoreObject+BasicData.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/12.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "CoreObject+BasicData.h"

@implementation CoreObject_BasicData

@end
