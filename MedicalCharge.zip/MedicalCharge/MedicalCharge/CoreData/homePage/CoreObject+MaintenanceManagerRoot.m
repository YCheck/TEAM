//
//  CoreObject_MaintenanceManagerRoot.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/6.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "CoreObject+MaintenanceManagerRoot.h"

@implementation CoreObject_MaintenanceManagerRoot

- (NSInteger)contentHeight{
    if (!_contentHeight) {
        CGFloat introHeight = [[self.faultDescription stringByRemovingPercentEncoding] ycy_heightWithFont:YCYFont(13) constrainedToWidth:(YCYScreen_Width - 105)];
        
        NSArray *images = self.imgList;NSInteger imgHeight = 0;
        NSInteger row = 0,x = 0,y = 0,width = 55,margin = 10;
        NSInteger imageViewWidth = YCYScreen_Width - 105;
        for (int i = 0; i < images.count; i ++) {
            if (imageViewWidth - x - width > 0) {
                x += width;
                
            }else{
                x = 0;y += width + margin;
                row ++;
            }
            
            //显示imageview
            
            x += margin;
        }
        if (images.count > 0) {
            imgHeight = y + width;
        }
        _contentHeight = introHeight + imgHeight + 20;
    }
    return _contentHeight;
}

@end
