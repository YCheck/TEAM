//
//  CoreObject+Hospital.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/13.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "CoreObject+Hospital.h"

@implementation CoreObject_Hospital

@end
