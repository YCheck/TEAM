//
//  CoreObject+RepairAcceptRoot.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/8.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CoreObject_RepairAcceptRoot : NSObject
@property (nonatomic,assign) BOOL isShow;//是否展开cell

@property (nonatomic, copy) NSString *id;
@property (nonatomic, copy) NSString *gid;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *businessNumber;//编号
@property (nonatomic, copy) NSString *hospitalGuid;
@property (nonatomic, copy) NSString *repairTime;
@property (nonatomic, copy) NSString *departmentName;
@property (nonatomic, copy) NSString *maintenanceStage;
@property (nonatomic, copy) NSString *faultDescription;


@end
