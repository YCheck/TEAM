//
//  CoreObject+BasicData.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/12.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CoreObject_BasicData : NSObject

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *specification;
@property (nonatomic, copy) NSString *model;
@property (nonatomic, copy) NSString *price;
@property (nonatomic, copy) NSString *manufacturerName;
@property (nonatomic, copy) NSString *registrationNumber;


@property (nonatomic, copy) NSString *code;
@property (nonatomic, copy) NSString *hospitalName;

@end
