//
//  CoreObject+Message.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/24.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CoreObject_Message : NSObject

@property (nonatomic, copy) NSString *gid;
@property (nonatomic, copy) NSString *messageContent;
@property (nonatomic, copy) NSString *messageType;
@property (nonatomic, copy) NSString *msgUrl;
@property (nonatomic, copy) NSString *readState;
@property (nonatomic, copy) NSString *jumpType;//1 跳转文本，2跳转地址
@property (nonatomic, copy) NSString *sendTime;

@end
