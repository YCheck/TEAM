//
//  CoreObject+Message.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/24.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "CoreObject+Message.h"

@implementation CoreObject_Message

@end
