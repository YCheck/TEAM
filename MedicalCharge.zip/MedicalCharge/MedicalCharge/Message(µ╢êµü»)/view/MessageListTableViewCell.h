//
//  MessageListTableViewCell.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/3.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CoreObject+Message.h"
@interface MessageListTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *headerImageView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@property (weak, nonatomic) IBOutlet UILabel *contentLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;

- (void)configureForCell:(CoreObject_Message *)model;

@end
