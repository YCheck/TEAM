//
//  MessageListTableViewCell.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/3.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "MessageListTableViewCell.h"

@implementation MessageListTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)configureForCell:(CoreObject_Message *)model{
    if ([model.messageType isEqualToString:@"普通消息"] || [model.messageType isEqualToString:@"邮件消息"]) {
        self.headerImageView.image = YCYImage(@"msg");
    }else if ([model.messageType isEqualToString:@"推送消息"]) {
        self.headerImageView.image = YCYImage(@"push");
    }else if ([model.messageType isEqualToString:@"通知消息"]) {
        self.headerImageView.image = YCYImage(@"notice");
    }
    self.titleLabel.text = model.messageType;
    self.contentLabel.text = model.messageContent;
    self.timeLabel.text = [TimeTransform timeSubstringYMD:model.sendTime];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
