//
//  YZGMessageDetailsViewController.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/24.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BaseViewController.h"
#import "CoreObject+Message.h"
@interface YZGMessageDetailsViewController : BaseViewController

@property (weak, nonatomic) IBOutlet UIWebView *webview;

@property (nonatomic,retain) CoreObject_Message *messageModel;

@end
