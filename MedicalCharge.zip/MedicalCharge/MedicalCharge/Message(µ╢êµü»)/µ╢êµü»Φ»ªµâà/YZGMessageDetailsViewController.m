//
//  YZGMessageDetailsViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/24.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGMessageDetailsViewController.h"

@interface YZGMessageDetailsViewController ()

@end

@implementation YZGMessageDetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"消息详情";
    
    _webview.backgroundColor = WhiteColor;
    if ([self.messageModel.jumpType integerValue] == 1) {
        NSString *strHTML = self.messageModel.messageContent;
        [self setData:strHTML];
    }else if ([self.messageModel.jumpType integerValue] == 2){
        [_webview loadRequest:[NSURLRequest requestWithURL:YCYURL(self.messageModel.msgUrl)]];
    }
}

- (void)setData:(NSString *)htmlStr{
    [_webview loadHTMLString:[self reSizeImageWithHTML:[htmlStr stringByReplacingOccurrencesOfString:@"<p>" withString:@"<p style=\"color: #333333;font-size: 13px;\">"]] baseURL:nil];
}

- (NSString *)reSizeImageWithHTML:(NSString *)html {
    return [NSString stringWithFormat:@"<meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0'><meta name='apple-mobile-web-app-capable' content='yes'><meta name='apple-mobile-web-app-status-bar-style' content='black'><meta name='format-detection' content='telephone=no'><style type='text/css'>img{width:%fpx}</style>%@", YCYScreen_Width - 30, html];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
