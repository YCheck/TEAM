//
//  YZGMaintenanceManagerViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/6.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGMaintenanceManagerViewController.h"
#import "ScanViewController.h"
#import "MaintenanceManagerTableViewCell.h"
#import "CoreObject+MaintenanceManagerRoot.h"
#import "MaintenanceTimeSetTableViewCell.h"
#import "YZGMaintenanceDetailsViewController.h"
#import "YZGChooseRepairDevicesViewController.h"
#import "YZGRepairDeviceViewController.h"
#import "YZGMaintenanceRegisterViewController.h"

@interface YZGMaintenanceManagerViewController ()<YCYActionSheetDelegate,YZGSearchViewDelegate>

@property (nonatomic,retain) NSMutableArray *dataSource;
@property (nonatomic, retain) NSIndexPath *indexPath;
@property (nonatomic,assign) NSInteger startIndex;
@property (nonatomic,assign) NSInteger type;//选择状态

@end

@implementation YZGMaintenanceManagerViewController

- (void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self uploadHeader];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"维修单汇总";
    [self initNavigationButtons];
    
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(scanTimingNotification:) name:@"ScanTiming" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(scanRegisterNotification:) name:@"ScanRegister" object:nil];
    self.type = 1;
    self.searchViewHeight.constant = 0;
    self.searchView.hidden = YES;
    self.searchView.delegate = self;
    [self initTableView];
}

- (void)initNavigationButtons{
    UIButton *button0  = [UIButton buttonWithType:UIButtonTypeCustom];
    button0.frame = CGRectMake(0, 0, 30, 44);
    [button0 setImage:YCYImage(@"search") forState:UIControlStateNormal];
    [button0 addTarget:self action:@selector(searchCheckincoming) forControlEvents:UIControlEventTouchUpInside];
    button0.imageEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);
    
    UIBarButtonItem *item0 = [[UIBarButtonItem alloc] initWithCustomView:button0];
    
    UIButton *button1  = [UIButton buttonWithType:UIButtonTypeCustom];
    button1.frame = CGRectMake(0, 0, 30, 44);
    [button1 setImage:YCYImage(@"add") forState:UIControlStateNormal];
    [button1 addTarget:self action:@selector(addMaintenanceList) forControlEvents:UIControlEventTouchUpInside];
    button1.imageEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);
    
    UIBarButtonItem *item1 = [[UIBarButtonItem alloc] initWithCustomView:button1];
    
    UIButton *button2  = [UIButton buttonWithType:UIButtonTypeCustom];
    button2.frame = CGRectMake(0, 0, 40, 44);
    [button2 setImage:YCYImage(@"qr") forState:UIControlStateNormal];
    [button2 addTarget:self action:@selector(scanButtonAction) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *item2 = [[UIBarButtonItem alloc] initWithCustomView:button2];
    
    if (ROLE == 1) {
        self.navigationItem.rightBarButtonItems = @[item2,item1,item0];
    }else if (ROLE == 2){
        self.navigationItem.rightBarButtonItems = @[item2,item0];
    }
}

- (void)scanTimingNotification:(NSNotification *)notification{
//    NSDictionary *info = notification.userInfo;
    
}

- (void)scanRegisterNotification:(NSNotification *)notification{
    NSDictionary *info = notification.userInfo;
    
    YZGMaintenanceRegisterViewController *controller = [[YZGMaintenanceRegisterViewController alloc] init];
    controller.repairId = info[@"gid"];
    [self.navigationController pushViewController:controller animated:YES];
}

- (void)searchCheckincoming{
    if (self.searchViewHeight.constant == 0) {
        self.searchViewHeight.constant = 45;
        self.searchView.hidden = NO;
    }else{
        self.searchView.hidden = YES;
        self.searchViewHeight.constant = 0;
    }
}

- (void)addMaintenanceList{
    YCYActionSheet *actionSheet = [[YCYActionSheet alloc] initWithTarget:self andTitles:@[@"选择设备报修",@"手工录入报修"]];
    [actionSheet showView];
}

- (void)scanButtonAction{
    ScanViewController *controller = [[ScanViewController alloc] init];
    controller.fromView = 3;
    [self.navigationController pushViewController:controller animated:YES];
}

#pragma mark -- YZGSearchViewDelegate
- (void)yzg_searchView:(YZGSearchView *)searchView searchContent:(NSString *)content andCollation:(NSInteger)sort{
    [self uploadHeader];
}

#pragma mark -- YCYActionSheetDelegate
- (void)ycyActionSheet:(YCYActionSheet *)actionSheet andSelectedIndex:(NSInteger)selectIndex{
    if (selectIndex == 0) {
        YZGChooseRepairDevicesViewController *controller = [[YZGChooseRepairDevicesViewController alloc] init];
        [self.navigationController pushViewController:controller animated:YES];
    }else if (selectIndex == 1){
        YZGRepairDeviceViewController *controller = [[YZGRepairDeviceViewController alloc] init];
        controller.fromView = 2;
        [self.navigationController pushViewController:controller animated:YES];
    }
}

- (void)initTableView{
    _startIndex = 1;
    self.dataSource = [NSMutableArray array];
    
    for (int i = 0; i < 4; i ++) {
        CoreObject_MaintenanceManagerRoot *model = [[CoreObject_MaintenanceManagerRoot alloc] init];
        model.isShow = NO;
        [self.dataSource addObject:model];
    }
    
    self.tableView.backgroundColor = LightGrayColor;
    self.tableView.estimatedRowHeight = 120.0f;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    [self.tableView registerNib:[MaintenanceManagerTableViewCell ycy_nib] forCellReuseIdentifier:[MaintenanceManagerTableViewCell ycy_className]];
    [self.tableView registerNib:[MaintenanceTimeSetTableViewCell ycy_nib] forCellReuseIdentifier:[MaintenanceTimeSetTableViewCell ycy_className]];
    
    [self initWithTableViewRefreshAnimation];
}

#pragma mark -- UITableViewDelegate,UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.dataSource.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    CoreObject_MaintenanceManagerRoot *model = self.dataSource[section];
    if (model.isShow == NO) {
        return 0;
    }
    if (IsEngineer) {
        return 2;
    }
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CoreObject_MaintenanceManagerRoot *model = self.dataSource[indexPath.section];
    if (indexPath.row == 0) {
        
        MaintenanceManagerTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[MaintenanceManagerTableViewCell ycy_className] forIndexPath:indexPath];
        
        [cell configureForCell:model];
        return cell;
    }else{
        MaintenanceTimeSetTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[MaintenanceTimeSetTableViewCell ycy_className] forIndexPath:indexPath];
        [cell configureForCell:model andIndexPath:indexPath];
        return cell;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (IsEngineer) {
        if (indexPath.row == 0) {
            CoreObject_MaintenanceManagerRoot *model = self.dataSource[indexPath.section];
            return model.contentHeight;
        }else{
            return 44;
        }
    }else{
        CoreObject_MaintenanceManagerRoot *model = self.dataSource[indexPath.section];
        return model.contentHeight;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 85;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 30;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    CoreObject_MaintenanceManagerRoot *model = self.dataSource[section];
    
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, YCYScreen_Width, 85)];
    headerView.backgroundColor = LightGrayColor;
    
    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 10, YCYScreen_Width, 75)];
    header.backgroundColor = [UIColor whiteColor];
    [headerView addSubview:header];
    
    UILabel *label = [[UILabel alloc] init];
    label.frame = CGRectMake(15, 12, 60, 15);
    label.font = YCYFont(13);
    label.textColor = TextCOLOR333;
    label.text = @"维修单号";
    [header addSubview:label];
    
    UILabel *order = [[UILabel alloc] init];
    order.frame = CGRectMake(CGRectGetMaxX(label.frame) + 15, 12, 180, 15);
    order.font = YCYFont(13);
    order.textColor = TextCOLOR333;
    order.text = model.businessNumber;
    [header addSubview:order];
    
    UILabel *timeTitle = [[UILabel alloc] init];
    timeTitle.frame = CGRectMake(15, CGRectGetMaxY(label.frame) + 8, 60, 15);
    timeTitle.font = YCYFont(13);
    timeTitle.textColor = TextCOLOR333;
    timeTitle.text = @"报修时间";
    [header addSubview:timeTitle];
    
    UILabel *time = [[UILabel alloc] init];
    time.frame = CGRectMake(CGRectGetMaxX(timeTitle.frame) + 15, CGRectGetMaxY(label.frame) + 8, 180, 15);
    time.font = YCYFont(13);
    time.textColor = TextCOLOR333;
    time.text = model.repairTime;
    [header addSubview:time];
    
    UILabel *nameTitle = [[UILabel alloc] init];
    nameTitle.frame = CGRectMake(15, CGRectGetMaxY(timeTitle.frame) + 8, 60, 15);
    nameTitle.font = YCYFont(13);
    nameTitle.textColor = TextCOLOR333;
    nameTitle.text = @"设备名称";
    [header addSubview:nameTitle];
    
    UILabel *deviceName = [[UILabel alloc] init];
    deviceName.frame = CGRectMake(CGRectGetMaxX(timeTitle.frame) + 15, CGRectGetMaxY(timeTitle.frame) + 8, 180, 15);
    deviceName.font = YCYFont(13);
    deviceName.textColor = TextCOLOR333;
    deviceName.text = model.name;
    [header addSubview:deviceName];
    
    UILabel *subject = [[UILabel alloc] init];
    subject.frame = CGRectMake(YCYScreen_Width - 150, CGRectGetMaxY(timeTitle.frame) + 8, 135, 15);
    subject.font = YCYFont(13);
    subject.textColor = TextCOLOR333;
    subject.textAlignment = NSTextAlignmentRight;
    subject.text = [NSString stringWithFormat:@"科室    %@",model.departmentName];
    [header addSubview:subject];
    
    UILabel *orderStatus = [[UILabel alloc] init];
    orderStatus.frame = CGRectMake(YCYScreen_Width - 110, 12, 95, 15);
    orderStatus.font = YCYFont(13);
    orderStatus.textColor = RedCOLOR;
    orderStatus.backgroundColor = [UIColor clearColor];
    orderStatus.textAlignment = NSTextAlignmentRight;
    orderStatus.text = model.maintenanceStage;
    [header addSubview:orderStatus];
    
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = header.bounds;
    button.backgroundColor = [UIColor clearColor];
    button.tag = section + 10000;
    [button addTarget:self action:@selector(lookAtOrderDetail:) forControlEvents:UIControlEventTouchUpInside];
    button.titleLabel.font = YCYFont(13);
    [header addSubview:button];
    
    return headerView;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    
    CoreObject_MaintenanceManagerRoot *model = self.dataSource[section];
    
    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, YCYScreen_Width, 41)];
    header.backgroundColor = [UIColor clearColor];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(0, 0, YCYScreen_Width, 30);
    button.backgroundColor = [UIColor whiteColor];
    [button setTitle:@"" forState:UIControlStateNormal];
    if (model.isShow) {
        [button setImage:YCYImage(@"keepimg") forState:UIControlStateNormal];
    }else{
        [button setImage:YCYImage(@"spreadoutimg") forState:UIControlStateNormal];
    }
    button.tag = section + 20000;
    button.selected = NO;
    [button addTarget:self action:@selector(moreBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [header addSubview:button];
    
    return header;
    
}

- (void)lookAtOrderDetail:(UIButton *)sender{
    NSInteger index = sender.tag - 10000;
    
    CoreObject_MaintenanceManagerRoot *model = self.dataSource[index];
    
    YZGMaintenanceDetailsViewController *controller = [[YZGMaintenanceDetailsViewController alloc] init];
    controller.repairId = model.gid;
    [self.navigationController pushViewController:controller animated:YES];
}

#pragma mark -- 点击查看更多
- (void)moreBtnAction:(UIButton *)sender{
    sender.selected = !sender.selected;
    
    CoreObject_MaintenanceManagerRoot *model = self.dataSource[sender.tag - 20000];
    if (model.isShow) {
        
    }else{
        for (CoreObject_MaintenanceManagerRoot *model in self.dataSource) {
            model.isShow = NO;
        }
    }
    model.isShow = !model.isShow;
    
    //    NSIndexSet *set = [NSIndexSet indexSetWithIndex:sender.tag];
    //    [self.tableView reloadSections:set withRowAnimation:UITableViewRowAnimationAutomatic];
    
    [self.tableView reloadData];
}

- (void)routerEventWithName:(NSString *)eventName dataInfo:(NSDictionary *)dataInfo{
        if ([ChooseButtonAction isEqualToString:eventName]) {
            NSInteger section = [dataInfo[@"section"] integerValue];
            NSInteger row = [dataInfo[@"row"] integerValue];
            NSInteger type = [dataInfo[@"type"] integerValue];
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:row inSection:section];
            self.indexPath = indexPath;
            if (type == 1) {
                [self maintenanceTimingRequest];
            }else if (type == 2){
                CoreObject_MaintenanceManagerRoot *model = self.dataSource[section];
                YZGMaintenanceRegisterViewController *controller = [[YZGMaintenanceRegisterViewController alloc] init];
                controller.repairId = model.gid;
                [self.navigationController pushViewController:controller animated:YES];
            }
        }
}

#pragma mark -- 顶部按钮切换 11 12 13
- (IBAction)topButtonAction:(id)sender {
    
    UIButton *button = (UIButton *)sender;
    self.lineView.center = CGPointMake(button.center.x, self.lineView.center.y);
    
    self.type = button.tag - 10;
    [self uploadHeader];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --------  网络请求 ------

- (void)getCheckInComingListRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:[CoreObject_MaintenanceManagerRoot class] andIsPersistence:NO andNumber:1];
}

- (void)maintenanceTimingRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:2];
}

- (void)uploadHeader{
    _startIndex = 1;
    [self getCheckInComingListRequest];
}

- (void)uploadFooter{
    _startIndex ++;
    [self getCheckInComingListRequest];
}

#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    if (manager.requestNumber == 1) {
        NSString *sort = @"desc";//默认降序
        if (self.searchView.timeButton.selected) {
            sort = @"asc";
        }
        
        NSString *value1 = @"0";NSString *value2 = @"";
        if (self.type == 2) {
            value1 = @"1";
        }else if (self.type == 3){
            value1 = @"8";
        }
        value2 = self.searchView.textField.text;
        
        NSDictionary *param1 = @{@"Rules":@[@{@"Field":@"maintenanceStage",@"Value":value1,@"Operate":@"equal"}],@"Groups":@[@{@"Rules":@[@{@"Field":@"businessNumber",@"Value":value2,@"Operate":@"contains"}],@"Operate":@"or"}],@"Operate":@"and"};
        return @{@"url":MaintenanceListAPI,@"params":@{@"pageIndex":@(_startIndex),@"pageSize":@(ListPageSize),@"sortField":@"Id",@"sortOrder":sort,@"filter_group":param1.ycy_JSONString}};
    }else if (manager.requestNumber == 2){
        
        CoreObject_MaintenanceManagerRoot *model = self.dataSource[self.indexPath.section];
        return @{@"url":MaintenanceTimingAPI,@"params":@{@"number":model.businessNumber,@"hospitalGuid":model.hospitalGuid}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([result isKindOfClass:[NSDictionary class]] && [manager.response.content[@"success"] integerValue] != 1) {
        [XHToast showCenterWithText:result[@"msg"] duration:2];
        if (manager.requestNumber == 1) {
            [self.dataSource removeAllObjects];
            [self.tableView reloadData];
        }
    }else{
        if (manager.requestNumber == 1){
            
            NSArray *array = manager.model;
            
            if (_startIndex == 1) {
                [_dataSource removeAllObjects];
            }
            if (array.count < ListPageSize) {
                self.tableView.mj_footer.state = MJRefreshStateNoMoreData;
            }else{
                [self.tableView.mj_footer endRefreshing];
            }
            
            [self.dataSource addObjectsFromArray:manager.model];
            [self.tableView reloadData];
            
            if (self.type == 1) {
                [self.allButton setTitle:[NSString stringWithFormat:@"全部(%@)",result[@"data"][@"total"]] forState:UIControlStateNormal];
            }
        }else if (manager.requestNumber == 2){
//            [XHToast showBottomWithText:@"计时已开始~"];
            [XHToast showCenterWithText:result[@"msg"] duration:2];
            CoreObject_MaintenanceManagerRoot *model = self.dataSource[self.indexPath.section];
            model.scanTiming = NO;
            model.checkIn = YES;
            if (ROLE == 1) {
                model.maintenanceStage = @"院内维修中";
            }else if (ROLE == 2){
                model.maintenanceStage = @"院外维修中";
            }
            [self.tableView reloadData];
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
