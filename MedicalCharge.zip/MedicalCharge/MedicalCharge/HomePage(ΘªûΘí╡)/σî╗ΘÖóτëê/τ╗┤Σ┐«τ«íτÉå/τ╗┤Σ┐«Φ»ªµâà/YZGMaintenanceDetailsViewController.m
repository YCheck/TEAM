//
//  YZGMaintenanceDetailsViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/8.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGMaintenanceDetailsViewController.h"
#import "DetailTitlesTableViewCell.h"
#import "DeviceDetailsTableViewCell.h"
#import "CoreObject+MaintenanceDetails.h"

@interface YZGMaintenanceDetailsViewController ()
@property (nonatomic,retain) NSMutableArray *firstArray;
@property (nonatomic,retain) NSMutableArray *secondArray;

@property (nonatomic,assign) NSInteger selectIndex;

@property (nonatomic,retain) DetailTitlesTableViewCell *selectCell;

@property (nonatomic,retain) CoreObject_MaintenanceDetails *detailModel;

@end

@implementation YZGMaintenanceDetailsViewController

- (NSMutableArray *)firstArray{
    if (!_firstArray) {
        _firstArray = [NSMutableArray arrayWithArray:@[@"基本信息",@"院内维修",@"院外维修",@"维修费用",@"配件信息",@"验收信息"]];
    }
    return _firstArray;
}

- (void)initWithDataSource1{
    _secondArray = [NSMutableArray arrayWithArray:@[
                    @{@"维修单号":emptyTransform(self.detailModel.businessNumber)},
                    @{@"设备名称":emptyTransform(self.detailModel.name)},
                    @{@"处理阶段":emptyTransform(self.detailModel.maintenanceStage)},
                    @{@"维修方式":emptyTransform(self.detailModel.maintenanceType)},
                    @{@"报修时间":emptyTransform(self.detailModel.repairTime)},
                    @{@"规格":emptyTransform(self.detailModel.specification)},
                    @{@"型号":emptyTransform(self.detailModel.model)},
                    @{@"设备价值":emptyTransform(self.detailModel.worth)},
                    @{@"科室负责人":emptyTransform(self.detailModel.responsible)},
                    @{@"使用科室":emptyTransform(self.detailModel.departmentName)},
                    @{@"生产厂家":emptyTransform(self.detailModel.manufacturer)},
                    @{@"报修人":emptyTransform(self.detailModel.repairUser)},
                    @{@"报修描述":emptyTransform(self.detailModel.faultDescription)},
                    @{@"审核人员":emptyTransform(self.detailModel.acceptanceUser)},
                    @{@"验收日期":emptyTransform(self.detailModel.completionDate)},
                    @{@"验收备注":emptyTransform(self.detailModel.acceptanceComments)}
                                                    ]];
}

- (void)initWithDataSource2:(NSInteger)section{
    CoreObject_MaintenanceList *model = self.detailModel.hospitalProcessList[section];
    if (self.selectIndex == 2) {
        model = self.detailModel.outHospitalProcessList[section];
    }
    _secondArray = [NSMutableArray arrayWithArray:@[
                @{@"维修级别":emptyTransform(model.maintenanceLevelName)},
                @{@"原因分析":emptyTransform(model.faultAnalysisName)},
                @{@"维修时间":emptyTransform(model.processTime)},
                @{@"开始时间":emptyTransform(model.maintenanceStartDate)},
                @{@"结束时间":emptyTransform(model.maintenanceEndDate)},
                @{@"维修时长":emptyTransform(model.manHour)},
                @{@"停机时长":emptyTransform(model.longShutdown)},
                @{@"测试人员":emptyTransform(model.testUser)},
                @{@"处理情况":emptyTransform(model.maintenanceSituation)}
                ]];
}

- (void)initWithDataSource4:(NSInteger)section{
    CoreObject_RepairFee *model = self.detailModel.repairFeeList[section];
    
    _secondArray = [NSMutableArray arrayWithArray:@[
                                                    @{@"名称":emptyTransform(model.feeName)},
                                                    @{@"维修类别":emptyTransform(model.feeType)},
                                                    @{@"资金来源":emptyTransform(model.fundSource)},
                                                    @{@"计划金额":emptyTransform(model.quotePrice)},
                                                    @{@"实际金额":emptyTransform(model.actualPrice)},
                                                    @{@"备注":emptyTransform(model.remark)}
                                                    ]];
}

- (void)initWithDataSource5:(NSInteger)section{
    CoreObject_PartMessage *model = self.detailModel.replacingFittingList[section];
    
    _secondArray = [NSMutableArray arrayWithArray:@[
                                                    @{@"费用名称":emptyTransform(model.name)},
                                                    @{@"数量":emptyTransform(model.quantity)},
                                                    @{@"单价":emptyTransform(model.prict)},
                                                    @{@"维修费用":emptyTransform(model.price)},
                                                    @{@"单位":emptyTransform(model.unitName)},
                                                    @{@"型号":emptyTransform(model.model)},
                                                    @{@"产地":emptyTransform(model.placeOriginName)},
                                                    @{@"厂家":emptyTransform(model.specification)},
                                                    @{@"供应商":emptyTransform(model.supplierName)},
                                                    @{@"序列号":emptyTransform(model.serialNumber)},
                                                    @{@"出厂时间":emptyTransform(model.factoryTime)},
                                                    @{@"出厂编号":emptyTransform(model.factoryCode)}
                                                    ]];
}

- (void)initWithDataSource6:(NSInteger)section{
    CoreObject_CheckMessage *model = self.detailModel.evaluationList[section];
    
    _secondArray = [NSMutableArray arrayWithArray:@[
                                                    @{@"工程师":emptyTransform(model.engineerName)},
                                                    @{@"分类":emptyTransform(model.maintenanceType)},
                                                    @{@"结果":emptyTransform(model.serviceEvaluation)},
                                                    @{@"意见":emptyTransform(model.evaluationComment)}
                                                    ]];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"维修详情";
    
    self.detailModel = [[CoreObject_MaintenanceDetails alloc] init];
    [self initTableView];
    [self getMaintenanceDetailRequest];
}

- (void)initScrollView{
    [self.customScrollView gainImage:self.detailModel.attachmentUrl];
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    DetailTitlesTableViewCell *cell = [self.firstTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
    cell.backgroundColor = WhiteColor;
    self.selectCell = cell;
}

- (void)initTableView{
    
    self.secondArray = [NSMutableArray array];
    
    self.firstTableView.backgroundColor = LineCOLOR;
    self.firstTableView.estimatedRowHeight = 44.0f;
    self.firstTableView.rowHeight = UITableViewAutomaticDimension;
    self.firstTableView.showsVerticalScrollIndicator = NO;
    [self.firstTableView registerNib:[DetailTitlesTableViewCell ycy_nib] forCellReuseIdentifier:[DetailTitlesTableViewCell ycy_className]];
    
    self.secondTableView.backgroundColor = WhiteColor;
    self.secondTableView.estimatedRowHeight = 40;
    self.secondTableView.rowHeight = UITableViewAutomaticDimension;
    [self.secondTableView registerNib:[DeviceDetailsTableViewCell ycy_nib] forCellReuseIdentifier:[DeviceDetailsTableViewCell ycy_className]];
}

#pragma mark -- UITableViewDelegate,UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (tableView == _firstTableView) {
        return 1;
    }else{
        if (self.selectIndex > 0) {
            if (self.selectIndex == 1) {
                return self.detailModel.hospitalProcessList.count;
            }else if (self.selectIndex == 2) {
                return self.detailModel.outHospitalProcessList.count;
            }else if (self.selectIndex == 3) {
                return self.detailModel.repairFeeList.count;
            }else if (self.selectIndex == 4) {
                return self.detailModel.replacingFittingList.count;
            }else if (self.selectIndex == 5) {
                return self.detailModel.evaluationList.count;
            }
            return 0;
        }else{
            return 1;
        }
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (tableView == _firstTableView) {
        return self.firstArray.count;
    }else{
        if (self.selectIndex > 0){
            if (self.selectIndex == 1) {
                [self initWithDataSource2:section];
                if (self.detailModel.hospitalProcessList.count == 0) {
                    return 0;
                }
            }else if (self.selectIndex == 2) {
                [self initWithDataSource2:section];
                if (self.detailModel.outHospitalProcessList.count == 0) {
                    return 0;
                }
            }else if (self.selectIndex == 3) {
                [self initWithDataSource4:section];
                if (self.detailModel.repairFeeList.count == 0) {
                    return 0;
                }
            }else if (self.selectIndex == 4) {
                [self initWithDataSource5:section];
                if (self.detailModel.replacingFittingList.count == 0) {
                    return 0;
                }
            }else if (self.selectIndex == 5) {
                [self initWithDataSource6:section];
                if (self.detailModel.evaluationList.count == 0) {
                    return 0;
                }
            }
            return _secondArray.count;
        }else{
            return self.secondArray.count;
        }
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView == _firstTableView) {
        DetailTitlesTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[DetailTitlesTableViewCell ycy_className] forIndexPath:indexPath];
        [cell configureForCell:self.firstArray[indexPath.row]];
        return cell;
    }else{
        DeviceDetailsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[DeviceDetailsTableViewCell ycy_className] forIndexPath:indexPath];
        if (self.selectIndex == 1) {
            [self initWithDataSource2:indexPath.section];
        }else if (self.selectIndex == 2) {
            [self initWithDataSource2:indexPath.section];
        }else if (self.selectIndex == 3) {
            [self initWithDataSource4:indexPath.section];
        }else if (self.selectIndex == 4) {
            [self initWithDataSource5:indexPath.section];
        }else if (self.selectIndex == 5) {
            [self initWithDataSource6:indexPath.section];
        }
        [cell configureForCell:self.secondArray[indexPath.row]];
        return cell;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView == _firstTableView) {
        self.selectIndex = indexPath.row;
        if (self.selectCell) {
            self.selectCell.backgroundColor = LineCOLOR;
        }
        DetailTitlesTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
        cell.backgroundColor = WhiteColor;
        self.selectCell = cell;
        if (self.selectIndex == 0) {
            [self initWithDataSource1];
        }
//        [self initScrollView];
        [self.secondTableView reloadData];
    }
}

//- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
//    if (tableView == _firstTableView) {
//        return 40;
//    }
//    return 75;
//}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (tableView == _firstTableView) {
        return 0.01;
    }
    if (self.selectIndex > 0) {
        return 60;
    }
    return 0.01;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    if (tableView == _firstTableView) {
        return nil;
    }else if (self.selectIndex == 0){
        return nil;
    }
    
    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, YCYScreen_Width, 60)];
    header.backgroundColor = [UIColor whiteColor];
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(15, 0, 300, 60)];
    label.text = [NSString stringWithFormat:@"(%zi)",section + 1];
    label.textColor = TextCOLOR333;
    label.font = YCYFont(15);
    [header addSubview:label];
    
    return header;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    
    return nil;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --------   网络请求------
- (void)getMaintenanceDetailRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:[CoreObject_MaintenanceDetails class] andIsPersistence:NO andNumber:1];
}

- (void)commitOrderRequest{
    [CHNetworkingConfig shardInstance].requestType = 1;
    
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:2];
}

#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    if (manager.requestNumber == 1) {
        return @{@"url":MaintenanceDetailAPI,@"params":@{@"guid":self.repairId}};
    }else if (manager.requestNumber == 2) {
        return @{@"url":CommitOrderAPI,@"params":@{}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([result isKindOfClass:[NSDictionary class]] && [manager.response.content[@"success"] integerValue] != 1) {
        [XHToast showCenterWithText:result[@"msg"]];
    }else{
        if (manager.requestNumber == 1){
            
            self.detailModel = manager.model;
            [self initScrollView];
            [self initWithDataSource1];
            [self.secondTableView reloadData];
            
        }else if (manager.requestNumber == 2){
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
