//
//  YZGEntryPartsViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/20.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGEntryPartsViewController.h"
#import "YZGEntryPartsView.h"

@interface YZGEntryPartsViewController ()
@property (nonatomic,retain) NSMutableArray *views;
@property (nonatomic,assign) NSInteger currentIndex;//当前选中按钮0 开始
@end

@implementation YZGEntryPartsViewController

- (NSMutableArray *)views{
    if (!_views) {
        _views = [NSMutableArray array];
    }
    return _views;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"录入配件费";
    
    WeakSelf
    [self actionCustomRightBtnWithNrlImage:nil htlImage:nil title:@"录入" btnFrame:CGRectMake(0, 0, 44, 44) action:^{
        [weakSelf rightButtonAction];
    }];
    
    self.currentIndex = 0;
    
    if (self.partDataArray.count == 0) {
        [self initUserInterface];
    }else{
        for (int i = 0; i < self.partDataArray.count; i ++) {
            YZGEntryPartsView *view = [[YZGEntryPartsView alloc] initWithFrame:self.contentView.bounds];
            view.tag = i + 1;
            [view configureDataForView:self.partDataArray[i]];
            [self.contentView addSubview:view];
            [self.views addObject:view];
        }
        self.currentIndex = self.views.count - 1;
    }
    [self initWithTopButtons];
}

- (void)rightButtonAction{
    if (![self checkData]) {
        return;
    }
    NSMutableArray *array = [NSMutableArray array];
    for (YZGEntryPartsView *view in self.views) {
        NSMutableDictionary *dic = [NSMutableDictionary dictionary];
        
        [dic setValue:view.partsName.text forKey:@"name"];
        [dic setValue:view.count.text forKey:@"quantity"];
        [dic setValue:view.price.text forKey:@"prict"];
        [dic setValue:[NSString stringWithFormat:@"%.2lf",[view.count.text integerValue] * [view.price.text floatValue]] forKey:@"price"];
        [dic setValue:@(view.unitId) forKey:@"unitId"];
        [dic setValue:view.unit.text forKey:@"unitName"];
        [dic setValue:view.specification.text forKey:@"specification"];
        [dic setValue:view.model.text forKey:@"model"];
        [dic setValue:@(view.placeId) forKey:@"placeOrigin"];
        [dic setValue:view.place.text forKey:@"placeOriginName"];
        [dic setValue:view.brand.text forKey:@"brand"];
        [dic setValue:view.company.text forKey:@"supplierName"];
        [dic setValue:view.production.text forKey:@"manufacturer"];
        [dic setValue:view.number.text forKey:@"serialNumber"];
        [dic setValue:@"" forKey:@"factoryCode"];
        [array addObject:dic];
    }
    if (_delegate && [_delegate respondsToSelector:@selector(entryPartsData:)]) {
        [_delegate entryPartsData:array];
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)initUserInterface{
    YZGEntryPartsView *view = [[YZGEntryPartsView alloc] initWithFrame:self.contentView.bounds];
    view.tag = self.views.count + 1;
    [self.contentView addSubview:view];
    [self.views addObject:view];
    self.currentIndex = self.views.count - 1;
}

- (void)initWithTopButtons{
    [self.buttonView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    NSInteger count = self.views.count + 1;
    NSInteger x = 15,y = 15,width = 50,height = 35;
    for (NSInteger i = 0; i < count; i ++) {
        if (i < count - 1) {
            UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
            button.frame = CGRectMake(x, y, width, height);
            [button setTitle:[NSString stringWithFormat:@"%zi",i + 1] forState:UIControlStateNormal];
            [button setTitleColor:TextCOLOR333 forState:UIControlStateNormal];
            button.titleLabel.font = YCYFont(13);
            button.tag = 1000 + i;
            [button addTarget:self action:@selector(clickTopButtonAction:) forControlEvents:UIControlEventTouchUpInside];
            button.layer.borderWidth = 0.5;
            button.layer.borderColor = LineCOLOR.CGColor;
            button.backgroundColor = WhiteColor;
            [self.buttonView addSubview:button];
            if (self.currentIndex == i) {
                button.layer.borderColor = WhiteColor.CGColor;
            }
        }else{
            UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
            button.frame = CGRectMake(x, y, width, height);
            [button setTitle:@"+ 添加" forState:UIControlStateNormal];
            [button setTitleColor:TextCOLOR333 forState:UIControlStateNormal];
            button.titleLabel.font = YCYFont(13);
            button.tag = 1000 + i;
            [button addTarget:self action:@selector(clickAddButtonAction:) forControlEvents:UIControlEventTouchUpInside];
            button.layer.borderWidth = 0.5;
            button.layer.borderColor = LineCOLOR.CGColor;
            button.backgroundColor = WhiteColor;
            [self.buttonView addSubview:button];
        }
        
        x += width + 2;
    }
}

- (void)clickTopButtonAction:(UIButton *)sender{
    for (NSInteger i = 1000; i < self.views.count + 1000; i ++) {
        UIButton *btn = (UIButton *)[self.buttonView viewWithTag:i];
        btn.layer.borderColor = LineCOLOR.CGColor;
    }
    sender.layer.borderColor = WhiteColor.CGColor;
    self.currentIndex = sender.tag - 1000;
    
    [self.contentView bringSubviewToFront:self.views[self.currentIndex]];
}

- (void)clickAddButtonAction:(UIButton *)sender{
    if (self.views.count > 4) {
        [XHToast showBottomWithText:@"最多只能添加5个~"];
        return;
    }
    
    if (![self checkData]) {
        return;
    }
    
    [self initUserInterface];
    [self initWithTopButtons];
    
}

- (BOOL)checkData{
    YZGEntryPartsView *view = self.views.lastObject;
    if (view.partsName.text.length == 0) {
        [XHToast showBottomWithText:@"请填写配件名称~"];
        return NO;
    }
    if (view.specification.text.length == 0) {
        [XHToast showBottomWithText:@"请填写规格~"];
        return NO;
    }
    if (view.model.text.length == 0) {
        [XHToast showBottomWithText:@"请填写型号~"];
        return NO;
    }
    if (view.brand.text.length == 0) {
        [XHToast showBottomWithText:@"请填写品牌~"];
        return NO;
    }
    if (view.place.text.length == 0) {
        [XHToast showBottomWithText:@"请选择产地~"];
        return NO;
    }
    if (view.production.text.length == 0) {
        [XHToast showBottomWithText:@"请填写厂家~"];
        return NO;
    }
    if (view.company.text.length == 0) {
        [XHToast showBottomWithText:@"请填写供应商~"];
        return NO;
    }
    if (view.count.text.length == 0) {
        [XHToast showBottomWithText:@"请填写数量~"];
        return NO;
    }
    if (view.price.text.length == 0) {
        [XHToast showBottomWithText:@"请填写单价~"];
        return NO;
    }
    if (view.unit.text.length == 0) {
        [XHToast showBottomWithText:@"请选择单位~"];
        return NO;
    }
    if (view.number.text.length == 0) {
        [XHToast showBottomWithText:@"请填写序列号~"];
        return NO;
    }
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
