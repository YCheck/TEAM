//
//  YZGEntryFeeViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/20.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGEntryFeeViewController.h"
#import "YZGEntryFeeView.h"

@interface YZGEntryFeeViewController ()

@property (nonatomic,retain) NSMutableArray *views;
@property (nonatomic,assign) NSInteger currentIndex;//当前选中按钮0 开始

@end

@implementation YZGEntryFeeViewController

- (NSMutableArray *)views{
    if (!_views) {
        _views = [NSMutableArray array];
    }
    return _views;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"录入设备维修费";
    
    WeakSelf
    [self actionCustomRightBtnWithNrlImage:nil htlImage:nil title:@"录入" btnFrame:CGRectMake(0, 0, 44, 44) action:^{
        [weakSelf rightButtonAction];
    }];
    
    self.currentIndex = 0;
    
    if (self.feeDataArray.count == 0) {
        [self initUserInterface];
    }else{
        for (int i = 0; i < self.feeDataArray.count; i ++) {
            YZGEntryFeeView *view = [[YZGEntryFeeView alloc] initWithFrame:self.contentView.bounds];
            view.tag = i + 1;
            [view configureDataForView:self.feeDataArray[i] andImages:self.feeImages[i]];
            
            [self.contentView addSubview:view];
            [self.views addObject:view];
        }
        self.currentIndex = self.views.count - 1;
    }
    [self initWithTopButtons];
}

- (void)rightButtonAction{
    if (![self checkData]) {
        return;
    }
    NSMutableArray *array = [NSMutableArray array];
    NSMutableArray *images = [NSMutableArray array];
    for (YZGEntryFeeView *view in self.views) {
        NSMutableDictionary *dic = [NSMutableDictionary dictionary];
        
        [dic setValue:view.feeName.text forKey:@"feeName"];
        [dic setValue:view.sourceFund.text forKey:@"fundSource"];
        [dic setValue:view.maintenancePrice.text forKey:@"quotePrice"];
        [dic setValue:view.actualPrice.text forKey:@"actualPrice"];
        [dic setValue:view.textView.text forKey:@"remark"];
        
        NSMutableString *imageIds = [NSMutableString stringWithFormat:@""];
        for (int i = 0; i < view.imageIdArray.count; i ++) {
            [imageIds appendString:[NSString stringWithFormat:@"%@",view.imageIdArray[i]]];
            if (i < view.imageIdArray.count - 1) {
                [imageIds appendString:@","];
            }
        }
        [dic setValue:imageIds forKey:@"attachmentId"];
        [array addObject:dic];
        [images addObject:view.addImageView.imageList];
    }
    
    if (_delegate && [_delegate respondsToSelector:@selector(entryFeeData:andImages:)]) {
        [_delegate entryFeeData:array andImages:images];
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)initUserInterface{
    
    YZGEntryFeeView *view = [[YZGEntryFeeView alloc] initWithFrame:self.contentView.bounds];
    view.tag = self.views.count + 1;
    [self.contentView addSubview:view];
    [self.views addObject:view];
    self.currentIndex = self.views.count - 1;
}

- (void)initWithTopButtons{
    [self.buttonView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    NSInteger count = self.views.count + 1;
    NSInteger x = 15,y = 15,width = 50,height = 35;
    for (NSInteger i = 0; i < count; i ++) {
        if (i < count - 1) {
            UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
            button.frame = CGRectMake(x, y, width, height);
            [button setTitle:[NSString stringWithFormat:@"%zi",i + 1] forState:UIControlStateNormal];
            [button setTitleColor:TextCOLOR333 forState:UIControlStateNormal];
            button.titleLabel.font = YCYFont(13);
            button.tag = 1000 + i;
            [button addTarget:self action:@selector(clickTopButtonAction:) forControlEvents:UIControlEventTouchUpInside];
            button.layer.borderWidth = 0.5;
            button.layer.borderColor = LineCOLOR.CGColor;
            button.backgroundColor = WhiteColor;
            [self.buttonView addSubview:button];
            if (self.currentIndex == i) {
                button.layer.borderColor = WhiteColor.CGColor;
            }
        }else{
            UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
            button.frame = CGRectMake(x, y, width, height);
            [button setTitle:@"+ 添加" forState:UIControlStateNormal];
            [button setTitleColor:TextCOLOR333 forState:UIControlStateNormal];
            button.titleLabel.font = YCYFont(13);
            button.tag = 1000 + i;
            [button addTarget:self action:@selector(clickAddButtonAction:) forControlEvents:UIControlEventTouchUpInside];
            button.layer.borderWidth = 0.5;
            button.layer.borderColor = LineCOLOR.CGColor;
            button.backgroundColor = WhiteColor;
            [self.buttonView addSubview:button];
        }
        
        x += width + 2;
    }
}

- (void)clickTopButtonAction:(UIButton *)sender{
    for (NSInteger i = 1000; i < self.views.count + 1000; i ++) {
        UIButton *btn = (UIButton *)[self.buttonView viewWithTag:i];
        btn.layer.borderColor = LineCOLOR.CGColor;
    }
    sender.layer.borderColor = WhiteColor.CGColor;
    self.currentIndex = sender.tag - 1000;
    
    [self.contentView bringSubviewToFront:self.views[self.currentIndex]];
}

- (void)clickAddButtonAction:(UIButton *)sender{
    if (self.views.count > 4) {
        [XHToast showBottomWithText:@"最多只能添加5个~"];
        return;
    }
    
    if (![self checkData]) {
        return;
    }
    
    [self initUserInterface];
    [self initWithTopButtons];
    
}

- (BOOL)checkData{
    YZGEntryFeeView *view = self.views.lastObject;
    if (view.feeName.text.length == 0) {
        [XHToast showBottomWithText:@"请选择费用名称~"];
        return NO;
    }
    if (view.sourceFund.text.length == 0) {
        [XHToast showBottomWithText:@"请选择资金来源~"];
        return NO;
    }
    if (view.maintenancePrice.text.length == 0) {
        [XHToast showBottomWithText:@"请填写维修价格~"];
        return NO;
    }
    if (view.actualPrice.text.length == 0) {
        [XHToast showBottomWithText:@"请填写实际价格~"];
        return NO;
    }
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --------   网络请求------

- (void)getRepairNumberRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:1];
}

- (void)uploadImageRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:2];
}

#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    
    if (manager.requestNumber == 1) {
//        NSString *dicType = @"";
//        if (self.chooseType == 1) {
//            dicType = @"维修级别";
//        }else if (self.chooseType == 5){
//            dicType = @"原因分析";
//        }
//
//        return @{@"url":GetListForDicTypeAPI,@"params":@{@"dicType":dicType}};
    }else if (manager.requestNumber == 2){
        
//        UIImage *image = self.addImageView.imageList[_uploadImageIndex];
//        NSData *data = UIImageJPEGRepresentation(image,0.8);
//        NSString *imgBase64 = [data ycy_base64EncodedString];
//        return @{@"url":UploadImageAPI,@"params":@{@"uploadType":@"报修上传图片",@"base64String":imgBase64}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([manager.response.content[@"success"] integerValue] != 1) {
        [XHToast showCenterWithText:result[@"msg"]];
    }else{
        if(manager.requestNumber == 1){
            [XHToast showBottomWithText:@"报修单已提交~"];
            NSArray *vcs = self.navigationController.viewControllers;
            [self.navigationController popToViewController:vcs[vcs.count - 3] animated:YES];
        }else if(manager.requestNumber == 2){
//            if ([result[@"data"] count] > 0) {
//                NSString *imgId = result[@"data"][0][@"id"];
//                [self.imageIdArray addObject:imgId];
//            }else{
//                [self.imageIdArray addObject:@""];
//            }
//
//            if ((self.uploadImageIndex == self.addImageView.imageList.count - 1) && (self.imageIdArray.count == self.addImageView.imageList.count)) {
//                NSLog(@"一共发布了%li次",self.uploadImageIndex);
//                [self commitRepairRequest];
//            }
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
