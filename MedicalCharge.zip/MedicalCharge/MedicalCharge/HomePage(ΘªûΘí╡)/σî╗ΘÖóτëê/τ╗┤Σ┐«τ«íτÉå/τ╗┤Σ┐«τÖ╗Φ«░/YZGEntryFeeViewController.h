//
//  YZGEntryFeeViewController.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/20.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BaseViewController.h"

@protocol YZGEntryFeeViewControllerDelegate <NSObject>

- (void)entryFeeData:(NSArray *)feeDataArray andImages:(NSArray *)images;

@end

@interface YZGEntryFeeViewController : BaseViewController

@property (nonatomic, weak) id<YZGEntryFeeViewControllerDelegate> delegate;

@property (weak, nonatomic) IBOutlet UIView *buttonView;
@property (weak, nonatomic) IBOutlet UIView *contentView;

@property (nonatomic, retain) NSArray *feeDataArray;
@property (nonatomic, retain) NSArray *feeImages;
@end
