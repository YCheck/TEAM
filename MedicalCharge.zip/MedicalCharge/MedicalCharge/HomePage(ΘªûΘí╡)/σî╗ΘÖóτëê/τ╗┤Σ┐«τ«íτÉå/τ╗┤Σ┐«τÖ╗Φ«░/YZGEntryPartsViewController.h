//
//  YZGEntryPartsViewController.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/20.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BaseViewController.h"
@protocol YZGEntryPartsViewControllerDelegate <NSObject>

- (void)entryPartsData:(NSArray *)partDataArray;

@end
@interface YZGEntryPartsViewController : BaseViewController

@property (nonatomic, weak) id<YZGEntryPartsViewControllerDelegate> delegate;

@property (weak, nonatomic) IBOutlet UIView *buttonView;
@property (weak, nonatomic) IBOutlet UIView *contentView;

@property (nonatomic, retain) NSArray *partDataArray;

@end
