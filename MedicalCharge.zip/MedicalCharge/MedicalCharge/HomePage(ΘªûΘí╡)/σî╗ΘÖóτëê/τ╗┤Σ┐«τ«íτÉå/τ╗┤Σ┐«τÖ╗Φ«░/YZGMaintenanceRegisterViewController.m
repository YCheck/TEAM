//
//  YZGMaintenanceRegisterViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/19.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGMaintenanceRegisterViewController.h"
#import "YZGEntryFeeViewController.h"
#import "YZGEntryPartsViewController.h"
#import "CoreObject+MaintenanceDetails.h"
#import "YCYMakingCardMoneyView.h"
@interface YZGMaintenanceRegisterViewController ()<UITextViewDelegate,AddImageDelegate,CustomPickerDelegate,CustomDatePickerDelegate,UITextFieldDelegate,YCYMakingCardMoneyViewDelegate,UIScrollViewDelegate,YZGEntryFeeViewControllerDelegate,YZGEntryPartsViewControllerDelegate>

@property (nonatomic,retain) NSMutableArray *imageIdArray;
@property (nonatomic,assign) NSInteger uploadImageIndex;//上传的图片下标
@property (nonatomic,assign) NSInteger chooseType;//选择时 记录点击tag
@property (nonatomic,copy) NSString *contentStr;//自定义内容

@property (nonatomic,retain) CoreObject_MaintenanceDetails *detailModel;

@property (nonatomic,retain) NSArray *feeDataList;//费用数据
@property (nonatomic,retain) NSArray *feeImages;//费用数据
@property (nonatomic,retain) NSArray *partDataList;//配件数据
@property (nonatomic,assign) NSInteger maintenanceLevelId;//维修级别id
@property (nonatomic,assign) NSInteger reasonId;//原因分析id


@end

@implementation YZGMaintenanceRegisterViewController

- (NSMutableArray *)imageIdArray{
    if (!_imageIdArray) {
        _imageIdArray = [NSMutableArray array];
    }
    return _imageIdArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"维修登记";
    
    WeakSelf
    [self actionCustomRightBtnWithNrlImage:nil htlImage:nil title:@"保存" btnFrame:CGRectMake(0, 0, 44, 44) action:^{
        [weakSelf rightButtonAction];
    }];
    
    if (ROLE == 2) {
        self.checkButton2.hidden = YES;
    }
 
    self.contentStr = @"";
    self.detailModel = [[CoreObject_MaintenanceDetails alloc] init];
    
    self.contactViewHeight.constant = 0;
    self.contactView.hidden = YES;
    
    self.textView.placeholder = @"请填写实际情况";
    self.textView.scrollEnabled = YES;
    self.textView.userInteractionEnabled = YES;
    self.textView.delegate = self;
    
    self.addImageView.addImageDelegate = self;
    self.addImageView.clipsToBounds = YES;
    [self.addImageView setImageSource:nil];
    
    [self getRepairDetailsRequest];
}

- (void)rightButtonAction{
    if ([self.level.text isEqualToString:@"请选择"]) {
        [XHToast showBottomWithText:@"请选择维修级别~"];
        return;
    }
    if ([self.startTime.text isEqualToString:@"请选择"]) {
        [XHToast showBottomWithText:@"请选择开始时间~"];
        return;
    }
    if ([self.endTime.text isEqualToString:@"请选择"]) {
        [XHToast showBottomWithText:@"请选择结束时间~"];
        return;
    }
    if ([self.reason.text isEqualToString:@"请选择"]) {
        [XHToast showBottomWithText:@"请选择原因~"];
        return;
    }
    if (self.checkUser.text.length == 0) {
        [XHToast showBottomWithText:@"请填写检查人员~"];
        return;
    }
    
    if (ROLE == 1) {
        if (self.checkButton1.selected == NO && self.checkButton2.selected == NO) {
            [XHToast showBottomWithText:@"请勾选通知验收或转院外~"];
            return;
        }
    }else if(ROLE == 2){
        if (self.checkButton1.selected == NO) {
            [XHToast showBottomWithText:@"请勾选通知验收~"];
            return;
        }
    }
    
    if (self.checkButton2.selected == YES) {
        if (self.contact.text.length == 0) {
            [XHToast showBottomWithText:@"请填写院外维修联系人~"];
            return;
        }
        if (self.phone.text.length == 0) {
            [XHToast showBottomWithText:@"请填写联系人电话~"];
            return;
        }
    }
    if (self.addImageView.imageList.count > 0) {
        [self.imageIdArray removeAllObjects];
        for (int i = 0; i < self.addImageView.imageList.count; i ++) {
            self.uploadImageIndex = i;
            [self uploadImageRequest];
        }
    }else{
        [self commitMaintenanceRegisterRequest];
    }
}

- (void)initWithData{
    
    self.feeDataList = @[];
    self.partDataList = @[];
    
    self.companyLabel.text = self.detailModel.hospitalName;
    self.orderNumber.text = self.detailModel.businessNumber;
    self.repairTime.text = self.detailModel.repairTime;
    self.deviceName.text = self.detailModel.name;
    self.department.text = self.detailModel.departmentName;
    self.startTime.text = self.detailModel.maintenanceStartDate;
}

#pragma mark --AddImageDelegate
- (void)monitorImageCountValueChangedForCurrentImages:(NSInteger)imageCount{
    
}

- (void)monitorImageCountValueChangedForCurrentViewHeight:(CGFloat)height{
    self.topViewHeightConstraint.constant = height + 43;
}

#pragma mark -- 通知验收  转院外
- (IBAction)AcceptanceButtonAction:(id)sender {
    UIButton *button = (UIButton *)sender;
    if (self.checkButton1 == button) {
        self.checkButton1.selected  = YES;
        self.checkButton2.selected = NO;
        self.contactViewHeight.constant = 0;
        self.contactView.hidden = YES;
    }else{
        self.checkButton1.selected = NO;
        self.checkButton2.selected = YES;
        if ([self.detailModel.AccountingID integerValue] == 0) {
            self.contactViewHeight.constant = 32;
            self.contactView.hidden = NO;
        }else{
            self.contactViewHeight.constant = 0;
            self.contactView.hidden = YES;
        }
    }
}

#pragma mark -- 选择维修时间 级别等 21 - 26
- (IBAction)chooseButtonAction:(id)sender {
    UIButton *button = (UIButton *)sender;
    self.chooseType = button.tag - 20;
    if (self.chooseType == 1 || self.chooseType == 5) {
        [self getDictionaryDataRequest];
    }else if(self.chooseType == 2 || self.chooseType == 4){
        CustomDatePickerView *datePickerView = [[CustomDatePickerView alloc] initWithTarget:self];
        [datePickerView showView];
    }
}

#pragma mark -- 录入维修费用
- (IBAction)addMaintenancePrice:(id)sender {
    YZGEntryFeeViewController *controller = [[YZGEntryFeeViewController alloc] init];
    controller.delegate = self;
    controller.feeDataArray = self.feeDataList;
    controller.feeImages = self.feeImages;
    [self.navigationController pushViewController:controller animated:YES];
}
#pragma mark -- 录入配件费用
- (IBAction)addPartsPrice:(id)sender {
    YZGEntryPartsViewController *controller = [[YZGEntryPartsViewController alloc] init];
    controller.delegate = self;
    controller.partDataArray = self.partDataList;
    [self.navigationController pushViewController:controller animated:YES];
}

#pragma mark -- YZGEntryFeeViewControllerDelegate,YZGEntryPartsViewControllerDelegate
- (void)entryFeeData:(NSArray *)feeDataArray andImages:(NSArray *)images{
    self.feeDataList = [NSArray arrayWithArray:feeDataArray];
    self.feeImages = [NSArray arrayWithArray:images];
    float price = 0.0;
    for (NSDictionary *dic in feeDataArray) {
        price += [dic[@"actualPrice"] floatValue];
    }
    self.maintenancePrice.text = [NSString stringWithFormat:@"%.2lf",price];
    self.feeCount.text = [NSString stringWithFormat:@"共%zi项",feeDataArray.count];
    
}

- (void)entryPartsData:(NSArray *)partDataArray{
    self.partDataList = [NSArray arrayWithArray:partDataArray];
    float price = 0.0;
    for (NSDictionary *dic in partDataArray) {
        price += [dic[@"price"] floatValue];
    }
    self.partPrice.text = [NSString stringWithFormat:@"%.2lf",price];
    self.partsCount.text = [NSString stringWithFormat:@"共%zi项",partDataArray.count];
}

#pragma mark -- UITextViewDelegate
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    
    if ([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}

- (void)textViewDidChange:(UITextView *)textView{
    //    if (self.textView.text.length > 140) {
    //        self.textView.text = [self.textView.text substringToIndex:140];
    //    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self closeKeyBoard];
    return YES;
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    [self closeKeyBoard];
}

#pragma mark -- 计算工时
- (void)initMaintenanceTime{
    if (![self.endTime.text isEqualToString:@"请选择"]) {
        
        NSTimeInterval repairTime = [TimeTransform timeStringYMDHMSTransformTimeInterval:self.detailModel.repairTime]/1000;
        NSTimeInterval end = [TimeTransform timeStringYMDHMSTransformTimeInterval:self.endTime.text]/1000;
        if (end - [TimeTransform nowTimeInterval]/1000 > 0) {
            [XHToast showBottomWithText:@"结束时间不能大于当前时间~" duration:2];
            self.maintenanceHours.text = @"";
            self.stopHours.text = @"";
            return;
        }
        if (![self.maintenanceTime.text isEqualToString:@"请选择"]) {
            NSTimeInterval start = [TimeTransform timeStringYMDHMSTransformTimeInterval:self.startTime.text]/1000;
            NSInteger minute = (end - start)/60;
            NSInteger hours = (NSInteger)minute/60;
            if (minute%60 > 0) {
                hours ++;
            }
            if (start - end > 0) {
                [XHToast showBottomWithText:@"结束时间不能小于开始时间~" duration:2];
                self.maintenanceHours.text = @"";
                return;
            }
            self.maintenanceHours.text = hours == 0 ? @"1":StringValue(hours);
        }
        
        NSInteger stopMinute = (end - repairTime)/60;
        NSInteger stopHours = (NSInteger)stopMinute/60;
        if (stopMinute%60 > 0) {
            stopHours ++;
        }
        if (repairTime - end > 0) {
            [XHToast showBottomWithText:@"结束时间不能小于报修时间~" duration:2];
            self.stopHours.text = @"";
            return;
        }
        self.stopHours.text = StringValue(stopHours);
    }
}

- (void)showChooseView:(NSArray *)list{
    
    NSMutableArray *array = [NSMutableArray array];
    for (NSDictionary *dic in list) {
        [array addObject:@{@"name":dic[@"dicValue"],@"id":dic[@"id"]}];
    }
    [array addObject:@{@"name":@"自定义",@"id":@"0"}];
    
    CustomPickerView *pickerView = [[CustomPickerView alloc] initWithTarget:self andColumn:1];
    pickerView.itemsArray1 = array;
    [pickerView showView];
}

#pragma mark -- CustomDatePickerDelegate
- (void)datePickerView:(CustomDatePickerView *)pickerView didValueChanged:(NSString *)dateString{
    if (self.chooseType == 2) {
        self.maintenanceTime.text = dateString;
    }else if (self.chooseType == 4){
        self.endTime.text = dateString;
    }
    [self initMaintenanceTime];
}

#pragma mark -- CustomPickerDelegate
- (void)customPickerViewValueChanged:(NSString *)str andIds:(NSArray *)ids andOtherData:(NSDictionary *)info{
    if ([str isEqualToString:@"自定义"]) {
        YCYMakingCardMoneyView *makingView = [[YCYMakingCardMoneyView alloc] initWithTarget:self andContent:@""];
        makingView.userInputEnable = YES;
        makingView.placeHolder = @"请填写";
        if (self.chooseType == 1) {
            makingView.titleString = @"报修级别";
        }else if (self.chooseType == 5){
            makingView.titleString = @"原因分析";
        }
        makingView.sureButtonString = @"确定";
        [makingView showView];
        return;
    }
    if (self.chooseType == 1) {
        self.level.text = str;
        self.maintenanceLevelId = [info[@"id"] integerValue];
    }else if (_chooseType == 5){
        self.reason.text = str;
        self.reasonId = [info[@"id"] integerValue];
    }
}

#pragma mark -- YCYMakingCardMoneyViewDelegate
- (void)ycyMakingCardMoneyView:(NSString *)content andSelectedIndex:(NSInteger)index{
    if (self.chooseType == 1) {
        self.level.text = content;
    }else if (self.chooseType == 5){
        self.reason.text = content;
    }
    self.contentStr = content;
    [self addDictionaryDataRequest];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --------   网络请求------

- (void)getRepairDetailsRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:[CoreObject_MaintenanceDetails class] andIsPersistence:NO andNumber:1];
}

- (void)commitMaintenanceRegisterRequest{
    [CHNetworkingConfig shardInstance].requestType = 1;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:2];
}

- (void)uploadImageRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:3];
}

- (void)getDictionaryDataRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:4];
}

- (void)addDictionaryDataRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:5];
}

#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    
    if (manager.requestNumber == 1) {
        return @{@"url":MaintenanceRegisterAPI,@"params":@{@"guid":self.repairId}};
    }else if (manager.requestNumber == 2) {
        NSMutableString *imageIds = [NSMutableString stringWithFormat:@""];
        for (int i = 0; i < self.imageIdArray.count; i ++) {
            [imageIds appendString:[NSString stringWithFormat:@"%@",self.imageIdArray[i]]];
            if (i < self.imageIdArray.count - 1) {
                [imageIds appendString:@","];
            }
        }
        
        NSInteger noticeStatus = 1;
        if (self.checkButton1.selected) {
            noticeStatus = 3;
        }else if (self.checkButton2.selected){
            noticeStatus = 2;
        }
        
        NSDictionary *param = @{@"gid":self.repairId,@"applyId":self.detailModel.applyId,@"applyGuid":self.detailModel.applyGuid,@"maintenanceLevel":@(self.maintenanceLevelId),@"faultAnalysisId":@(self.reasonId),@"AttachmentId":imageIds,@"testUser":self.checkUser.text,@"processTime":self.maintenanceTime.text,@"maintenanceStartDate":self.startTime.text,@"maintenanceEndDate":self.endTime.text,@"manHour":self.maintenanceHours.text,@"longShutdown":self.stopHours.text,@"maintenanceSituation":self.textView.text,@"maintenancePhone":self.phone.text,@"maintenanceContacts":self.contact.text,@"repairFeeList":self.feeDataList,@"replacingFittingList":self.partDataList,@"noticStatus":@(noticeStatus)};
        
        return @{@"url":SaveMaintenanceRegisterScanAPI,@"params":param};
    }else if (manager.requestNumber == 3){
        UIImage *image = self.addImageView.imageList[_uploadImageIndex];
        NSData *data = UIImageJPEGRepresentation(image,0.8);
        NSString *imgBase64 = [data ycy_base64EncodedString];
        return @{@"url":UploadImageAPI,@"params":@{@"uploadType":@"维修处理上传图片",@"base64String":imgBase64}};
    }else if (manager.requestNumber == 4) {
        NSString *dicType = @"";
        if (self.chooseType == 1) {
            dicType = @"维修级别";
        }else if (self.chooseType == 5){
            dicType = @"原因分析";
        }
        
        return @{@"url":GetListForDicTypeAPI,@"params":@{@"dicType":dicType}};
    }else if (manager.requestNumber == 5) {
        NSString *DicName = @"";
        if (self.chooseType == 1) {
            DicName = @"维修级别";
        }else if (self.chooseType == 5){
            DicName = @"原因分析";
        }
        return @{@"url":AddDictionaryAPI,@"params":@{@"DicName":DicName,@"DicValue":self.contentStr}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([manager.response.content[@"success"] integerValue] != 1) {
        [XHToast showCenterWithText:result[@"msg"]];
    }else{
        if (manager.requestNumber == 1){
            self.detailModel = manager.model;
            [self initWithData];
        }else if(manager.requestNumber == 2){
            [XHToast showCenterWithText:result[@"msg"]];
            [self.navigationController popViewControllerAnimated:YES];
        }else if(manager.requestNumber == 3){
            if ([result[@"data"] count] > 0) {
                NSString *imgId = result[@"data"][0][@"id"];
                [self.imageIdArray addObject:imgId];
            }else{
                [self.imageIdArray addObject:@""];
            }
            
            if ((self.uploadImageIndex == self.addImageView.imageList.count - 1) && (self.imageIdArray.count == self.addImageView.imageList.count)) {
                NSLog(@"一共发布了%li次",self.uploadImageIndex);
                [self commitMaintenanceRegisterRequest];
            }
        }else if (manager.requestNumber == 4){
            [self showChooseView:result[@"data"]];
        }else if (manager.requestNumber == 5){
            
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
