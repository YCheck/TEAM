//
//  YZGEntryPartsView.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/20.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YCYMakingCardMoneyView.h"
@interface YZGEntryPartsView : UIView<UITextFieldDelegate,CustomPickerDelegate,YCYMakingCardMoneyViewDelegate>

@property (strong, nonatomic) IBOutlet UIView *view;


@property (weak, nonatomic) IBOutlet UITextField *partsName;
@property (weak, nonatomic) IBOutlet UITextField *specification;
@property (weak, nonatomic) IBOutlet UITextField *model;
@property (weak, nonatomic) IBOutlet UITextField *brand;
@property (weak, nonatomic) IBOutlet UITextField *place;
@property (nonatomic, assign) NSInteger placeId;
@property (weak, nonatomic) IBOutlet UITextField *production;//厂家
@property (weak, nonatomic) IBOutlet UITextField *company;//供应商
@property (weak, nonatomic) IBOutlet UITextField *count;
@property (weak, nonatomic) IBOutlet UITextField *price;
@property (weak, nonatomic) IBOutlet UITextField *unit;
@property (nonatomic, assign) NSInteger unitId;
@property (weak, nonatomic) IBOutlet UITextField *number;


@property (nonatomic,assign) NSInteger chooseType;//选择时 记录点击tag

- (void)configureDataForView:(NSDictionary *)info;

@end
