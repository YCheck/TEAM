//
//  YZGEntryFeeView.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/20.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AddImageView.h"
#import "YCYMakingCardMoneyView.h"

@interface YZGEntryFeeView : UIView <UITextViewDelegate,AddImageDelegate,UITextFieldDelegate,CustomPickerDelegate,YCYMakingCardMoneyViewDelegate>

@property (strong, nonatomic) IBOutlet UIView *view;

@property (weak, nonatomic) IBOutlet UITextField *feeName;
@property (weak, nonatomic) IBOutlet UITextField *sourceFund;//资金来源
@property (weak, nonatomic) IBOutlet UITextField *maintenancePrice;
@property (weak, nonatomic) IBOutlet UITextField *actualPrice;//实际价格

@property (weak, nonatomic) IBOutlet UITextView *textView;
@property (weak, nonatomic) IBOutlet AddImageView *addImageView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topViewHeightConstraint;


@property (nonatomic,retain) NSMutableArray *imageIdArray;
@property (nonatomic,retain) NSMutableArray *imageArray;
@property (nonatomic,retain) NSArray *currentImages;//当前添加的images
@property (nonatomic,assign) NSInteger uploadImageIndex;//上传的图片下标
@property (nonatomic,assign) NSInteger chooseType;//选择时 记录点击tag

- (void)configureDataForView:(NSDictionary *)info andImages:(NSArray *)images;

@end
