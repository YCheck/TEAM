//
//  YZGEntryPartsView.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/20.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGEntryPartsView.h"

@implementation YZGEntryPartsView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
 
*/
- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [[NSBundle mainBundle] loadNibNamed:@"YZGEntryPartsView" owner:self options:nil];
        self.frame = self.view.frame;
        [self addSubview:self.view];
    }
    return self;
}

- (void)configureDataForView:(NSDictionary *)info{
    
    self.partsName.text = info[@"name"];
    self.count.text = info[@"quantity"];
    self.price.text = info[@"prict"];
    self.unit.text = info[@"unitName"];
    self.unitId = [info[@"unitId"] integerValue];
    self.specification.text = info[@"specification"];
    self.model.text = info[@"model"];
    self.place.text = info[@"placeOriginName"];
    self.placeId = [info[@"placeOrigin"] integerValue];
    self.brand.text = info[@"brand"];
    self.company.text = info[@"supplierName"];
    self.production.text = info[@"manufacturer"];
    self.number.text = info[@"serialNumber"];
}

- (void)showChooseView:(NSArray *)list{
    [self endEditing:YES];
    NSMutableArray *array = [NSMutableArray array];
    for (NSDictionary *dic in list) {
        [array addObject:@{@"name":dic[@"dicValue"],@"id":dic[@"id"]}];
    }
    //    [array addObject:@{@"name":@"自定义",@"id":@"0"}];
    
    CustomPickerView *pickerView = [[CustomPickerView alloc] initWithTarget:self andColumn:1];
    pickerView.itemsArray1 = array;
    [pickerView showView];
}

#pragma mark -- CustomPickerDelegate
- (void)customPickerViewValueChanged:(NSString *)str andIds:(NSArray *)ids andOtherData:(NSDictionary *)info{
    if ([str isEqualToString:@"自定义"]) {
        YCYMakingCardMoneyView *makingView = [[YCYMakingCardMoneyView alloc] initWithTarget:self andContent:@""];
        makingView.userInputEnable = YES;
        makingView.placeHolder = @"请填写";
        if (self.chooseType == 1) {
            makingView.titleString = @"费用名称";
        }else if (self.chooseType == 2){
            makingView.titleString = @"资金来源";
        }
        makingView.sureButtonString = @"确定";
        [makingView showView];
        return;
    }
    if (self.chooseType == 1) {
        self.place.text = str;
        self.placeId = [info[@"id"] integerValue];
    }else if (_chooseType == 2){
        self.unit.text = str;
        self.unitId = [info[@"id"] integerValue];
    }
}

#pragma mark -- YCYMakingCardMoneyViewDelegate
- (void)ycyMakingCardMoneyView:(NSString *)content andSelectedIndex:(NSInteger)index{
    if (self.chooseType == 1) {
        self.place.text = content;
       
    }else if (self.chooseType == 2){
        self.unit.text = content;
    }
    //    self.contentStr = content;
    //    [self addDictionaryDataRequest];
}

#pragma mark --选择产地
- (IBAction)placeChooseAction:(id)sender {
    self.chooseType = 1;
    [self getDictionaryDataRequest];
}

#pragma mark -- 选择单位
- (IBAction)unitChooseAction:(id)sender {
    self.chooseType = 2;
    [self getDictionaryDataRequest];
}

#pragma mark -- UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self endEditing:YES];
    return YES;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self endEditing:YES];
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    [self endEditing:YES];
}

#pragma mark --------   网络请求------

- (void)getDictionaryDataRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:1];
}

- (void)uploadImageRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:2];
}

#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    
    if (manager.requestNumber == 1) {
        NSString *dicType = @"";
        if (self.chooseType == 1) {
            dicType = @"产地";
        }else if (self.chooseType == 2){
            dicType = @"单位";
        }
        
        return @{@"url":GetListForDicTypeAPI,@"params":@{@"dicType":dicType}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    
    NSDictionary *result = manager.response.content;
    if ([manager.response.content[@"success"] integerValue] != 1) {
        [XHToast showCenterWithText:result[@"msg"]];
    }else{
        if(manager.requestNumber == 1){
            [self showChooseView:result[@"data"]];
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [XHToast showCenterWithText:@"网络错误~"];
}

@end
