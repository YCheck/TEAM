//
//  YZGEntryFeeView.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/20.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGEntryFeeView.h"

@implementation YZGEntryFeeView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (NSMutableArray *)imageIdArray{
    if (!_imageIdArray) {
        _imageIdArray = [NSMutableArray array];
    }
    return _imageIdArray;
}

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [[NSBundle mainBundle] loadNibNamed:@"YZGEntryFeeView" owner:self options:nil];
        self.frame = self.view.frame;
        [self addSubview:self.view];
        [self initWithUserInterface];
    }
    return self;
}

- (void)initWithUserInterface{
    self.textView.placeholder = @"请填写实际情况";
    self.textView.scrollEnabled = YES;
    self.textView.userInteractionEnabled = YES;
    self.textView.delegate = self;
    
    self.addImageView.addImageDelegate = self;
    self.addImageView.clipsToBounds = YES;
    [self.addImageView setImageSource:nil];
}

- (void)configureDataForView:(NSDictionary *)info andImages:(NSArray *)images{
    
    self.feeName.text = info[@"feeName"];
    self.sourceFund.text = info[@"fundSource"];
    self.maintenancePrice.text = info[@"quotePrice"];
    self.actualPrice.text = info[@"actualPrice"];
    self.textView.text = info[@"remark"];
    
    NSArray *imgList = [info[@"attachmentId"] componentsSeparatedByString:@","];
    self.imageIdArray  = [NSMutableArray arrayWithArray:imgList];
    if (self.addImageView.imageList.count == 0) {
        [self.addImageView setImageSource:[images mutableCopy]];
    }
}

#pragma mark --AddImageDelegate
- (void)monitorImageCountValueChangedForCurrentImages:(NSInteger)imageCount{
}

- (void)monitorImageCountValueChangedForCurrentViewHeight:(CGFloat)height{
    self.topViewHeightConstraint.constant = height + 43;
}

- (void)addImagesToAddImageView:(AddImageView *)addImageView images:(NSArray *)images{
    self.currentImages = [NSArray arrayWithArray:images];
    for (int i = 0; i < images.count; i ++) {
        self.uploadImageIndex = i;
        [self uploadImageRequest];
    }
}

- (void)deleteImageToAddImageView:(AddImageView *)addImageView currentIndex:(NSInteger)currentIndex{
    [self.imageIdArray removeObjectAtIndex:currentIndex];
}

- (void)showChooseView:(NSArray *)list{
    [self endEditing:YES];
    NSMutableArray *array = [NSMutableArray array];
    for (NSDictionary *dic in list) {
        [array addObject:@{@"name":dic[@"dicValue"],@"id":dic[@"id"]}];
    }
//    [array addObject:@{@"name":@"自定义",@"id":@"0"}];
    
    CustomPickerView *pickerView = [[CustomPickerView alloc] initWithTarget:self andColumn:1];
    pickerView.itemsArray1 = array;
    [pickerView showView];
}

#pragma mark -- CustomPickerDelegate
- (void)customPickerViewValueChanged:(NSString *)str andIds:(NSArray *)ids andOtherData:(NSDictionary *)info{
    if ([str isEqualToString:@"自定义"]) {
        YCYMakingCardMoneyView *makingView = [[YCYMakingCardMoneyView alloc] initWithTarget:self andContent:@""];
        makingView.userInputEnable = YES;
        makingView.placeHolder = @"请填写";
        if (self.chooseType == 1) {
            makingView.titleString = @"费用名称";
        }else if (self.chooseType == 2){
            makingView.titleString = @"资金来源";
        }
        makingView.sureButtonString = @"确定";
        [makingView showView];
        return;
    }
    if (self.chooseType == 1) {
        self.feeName.text = str;
    }else if (_chooseType == 2){
        self.sourceFund.text = str;
    }
}

#pragma mark -- YCYMakingCardMoneyViewDelegate
- (void)ycyMakingCardMoneyView:(NSString *)content andSelectedIndex:(NSInteger)index{
    if (self.chooseType == 1) {
        self.feeName.text = content;
    }else if (self.chooseType == 2){
        self.sourceFund.text = content;
    }
//    self.contentStr = content;
//    [self addDictionaryDataRequest];
}

#pragma mark -- 选择维修费用
- (IBAction)feeNameChooseAction:(id)sender {
    self.chooseType = 1;
    [self getDictionaryDataRequest];
}

#pragma mark -- 选择资金来源
- (IBAction)sourceFundChooseAction:(id)sender {
    self.chooseType = 2;
    [self getDictionaryDataRequest];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self endEditing:YES];
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    [self endEditing:YES];
}

#pragma mark -- UITextViewDelegate
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    
    if ([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}

#pragma mark -- UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self endEditing:YES];
    return YES;
}


#pragma mark --------   网络请求------

- (void)getDictionaryDataRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:1];
}

- (void)uploadImageRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:2];
}

#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    
    if (manager.requestNumber == 1) {
                NSString *dicType = @"";
                if (self.chooseType == 1) {
                    dicType = @"费用名称";
                }else if (self.chooseType == 2){
                    dicType = @"资金来源";
                }
        
                return @{@"url":GetListForDicTypeAPI,@"params":@{@"dicType":dicType}};
    }else if (manager.requestNumber == 2){
        
                UIImage *image = self.currentImages[_uploadImageIndex];
                NSData *data = UIImageJPEGRepresentation(image,0.8);
                NSString *imgBase64 = [data ycy_base64EncodedString];
                return @{@"url":UploadImageAPI,@"params":@{@"uploadType":@"维修费用上传图片",@"base64String":imgBase64}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    
    NSDictionary *result = manager.response.content;
    if ([manager.response.content[@"success"] integerValue] != 1) {
        [XHToast showCenterWithText:result[@"msg"]];
    }else{
        if(manager.requestNumber == 1){
            [self showChooseView:result[@"data"]];
        }else if(manager.requestNumber == 2){
            if ([result[@"data"] count] > 0) {
                NSString *imgId = result[@"data"][0][@"id"];
                [self.imageIdArray addObject:imgId];
//                [self.imageUrlArray addObject:result[@"data"][0][@"fileUrl"]];
            }else{
                [self.imageIdArray addObject:@""];
//                [self.imageUrlArray addObject:@""];
            }
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [XHToast showCenterWithText:@"网络错误~"];
}

@end
