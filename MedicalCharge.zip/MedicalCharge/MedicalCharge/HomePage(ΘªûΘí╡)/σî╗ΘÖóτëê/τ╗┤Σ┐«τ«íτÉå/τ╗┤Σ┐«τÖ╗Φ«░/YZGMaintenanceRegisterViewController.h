//
//  YZGMaintenanceRegisterViewController.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/19.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BaseViewController.h"
#import "AddImageView.h"

@interface YZGMaintenanceRegisterViewController : BaseViewController

@property (weak, nonatomic) IBOutlet UILabel *companyLabel;
@property (weak, nonatomic) IBOutlet UILabel *orderNumber;
@property (weak, nonatomic) IBOutlet UILabel *repairTime;
@property (weak, nonatomic) IBOutlet UILabel *deviceName;
@property (weak, nonatomic) IBOutlet UILabel *department;


@property (weak, nonatomic) IBOutlet UILabel *level;
@property (weak, nonatomic) IBOutlet UILabel *maintenanceTime;
@property (weak, nonatomic) IBOutlet UILabel *startTime;
@property (weak, nonatomic) IBOutlet UILabel *endTime;
@property (weak, nonatomic) IBOutlet UILabel *reason;
@property (weak, nonatomic) IBOutlet UITextField *checkUser;


@property (weak, nonatomic) IBOutlet UILabel *maintenanceHours;
@property (weak, nonatomic) IBOutlet UILabel *stopHours;
@property (weak, nonatomic) IBOutlet UILabel *maintenancePrice;
@property (weak, nonatomic) IBOutlet UILabel *partPrice;
@property (weak, nonatomic) IBOutlet UILabel *feeCount;
@property (weak, nonatomic) IBOutlet UILabel *partsCount;



@property (weak, nonatomic) IBOutlet UIView *contactView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *contactViewHeight;

@property (weak, nonatomic) IBOutlet UITextField *contact;
@property (weak, nonatomic) IBOutlet UITextField *phone;


@property (weak, nonatomic) IBOutlet UIButton *checkButton1;//通知验收
@property (weak, nonatomic) IBOutlet UIButton *checkButton2;//转院外



@property (weak, nonatomic) IBOutlet UITextView *textView;
@property (weak, nonatomic) IBOutlet AddImageView *addImageView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topViewHeightConstraint;

@property (nonatomic, copy) NSString *repairId;//维修id

@property (nonatomic,assign) NSInteger fromView;//1医院端  2 供应商端

@end
