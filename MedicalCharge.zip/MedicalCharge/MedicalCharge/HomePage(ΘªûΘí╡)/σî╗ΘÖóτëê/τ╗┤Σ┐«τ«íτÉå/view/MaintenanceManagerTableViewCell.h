//
//  MaintenanceManagerTableViewCell.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/6.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CoreObject+MaintenanceManagerRoot.h"
@interface MaintenanceManagerTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *content;
@property (weak, nonatomic) IBOutlet UIView *imageContentView;

@property (weak, nonatomic) IBOutlet UIView *attachmentView;//附件视图

@property (nonatomic, retain) CoreObject_MaintenanceManagerRoot *model;

- (void)configureForCell:(CoreObject_MaintenanceManagerRoot *)model;

@end
