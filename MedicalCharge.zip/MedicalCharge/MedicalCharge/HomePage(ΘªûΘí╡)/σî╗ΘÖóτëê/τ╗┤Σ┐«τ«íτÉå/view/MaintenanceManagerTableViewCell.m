//
//  MaintenanceManagerTableViewCell.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/6.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "MaintenanceManagerTableViewCell.h"
#import "CycleScrollViewController.h"
@implementation MaintenanceManagerTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)configureForCell:(CoreObject_MaintenanceManagerRoot *)model{
    _model = model;
    self.content.text = model.faultDescription;
    if (model.imgList.count > 0) {
        [self initImageView:model.imgList];
        self.attachmentView.hidden = NO;
    }else{
        self.attachmentView.hidden = YES;
    }
}

- (void)initImageView:(NSArray *)imgList{
    
    [self.imageContentView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    NSArray *images = imgList;
    NSInteger row = 0,x = 0,y = 0,width = 55,margin = 10;
    NSInteger imageViewWidth = YCYScreen_Width - 105;
    for (int i = 0; i < images.count; i ++) {
        if (imageViewWidth - x - width > 0) {
            if (i > 0) {
                x += width;
            }
        }else{
            x = 0;y += width + margin;
            row ++;
        }
        
        //显示imageview
        UIImageView *imageView = [[UIImageView alloc] init];
        imageView.frame = CGRectMake(x,y, width, width);
        imageView.backgroundColor = LightGrayColor;
        [imageView py_setImageWithURL:YCYURL(imgList[0]) placeholderImage:DefaultImage];
        [self.imageContentView addSubview:imageView];
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = imageView.frame;
        [button addTarget:self action:@selector(clickHeaderImage:) forControlEvents:UIControlEventTouchUpInside];
        button.tag = 10000 + i;
        [self.imageContentView addSubview:button];
        x += margin;
    }
}

- (void)clickHeaderImage:(UIButton *)sender{
    NSInteger index = sender.tag - 10000;
    CycleScrollViewController *controller = [[CycleScrollViewController alloc] initWithMixids:_model.imgList currentIndex:(int)index];
    [[self ycy_viewController] presentViewController:controller animated:YES completion:nil];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
