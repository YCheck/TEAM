//
//  MaintenanceTimeSetTableViewCell.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/7.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "MaintenanceTimeSetTableViewCell.h"

@implementation MaintenanceTimeSetTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    self.registrationButton.layer.borderWidth = 0.5;
    self.registrationButton.layer.borderColor = LineCOLOR.CGColor;
    [self.registrationButton setTitleColor:TextCOLOR999 forState:UIControlStateNormal];
    [self.registrationButton setTitleColor:TextCOLOR333 forState:UIControlStateSelected];
    
    self.timingButton.layer.borderWidth = 0.5;
    self.timingButton.layer.borderColor = LineCOLOR.CGColor;
    [self.timingButton setTitleColor:TextCOLOR999 forState:UIControlStateNormal];
    [self.timingButton setTitleColor:TextCOLOR333 forState:UIControlStateSelected];
}

- (void)configureForCell:(CoreObject_MaintenanceManagerRoot *)model andIndexPath:(NSIndexPath *)indexPath{
    self.timingButton.enabled = model.scanTiming;
    self.registrationButton.enabled = model.checkIn;
    self.timingButton.selected = model.scanTiming;
    self.registrationButton.selected = model.checkIn;
    if (self.registrationButton.enabled == NO) {
        
    }
    
    _indexPath = indexPath;
    
}

- (IBAction)registationButtonAction:(id)sender {
    [self routerEventWithName:ChooseButtonAction dataInfo:@{@"section":@(_indexPath.section),@"row":@(_indexPath.row),@"type":@(2)}];
}

- (IBAction)timingButtonAction:(id)sender {
    [self routerEventWithName:ChooseButtonAction dataInfo:@{@"section":@(_indexPath.section),@"row":@(_indexPath.row),@"type":@(1)}];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
