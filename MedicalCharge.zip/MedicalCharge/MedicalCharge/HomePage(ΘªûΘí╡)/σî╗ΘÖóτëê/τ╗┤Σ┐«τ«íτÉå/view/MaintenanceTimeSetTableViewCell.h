//
//  MaintenanceTimeSetTableViewCell.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/7.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CoreObject+MaintenanceManagerRoot.h"

static NSString *const ChooseButtonAction = @"ChooseButtonAction";
@interface MaintenanceTimeSetTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIButton *registrationButton;
@property (weak, nonatomic) IBOutlet UIButton *timingButton;

@property (nonatomic,retain) NSIndexPath *indexPath;
- (void)configureForCell:(CoreObject_MaintenanceManagerRoot *)model andIndexPath:(NSIndexPath *)indexPath;
@end
