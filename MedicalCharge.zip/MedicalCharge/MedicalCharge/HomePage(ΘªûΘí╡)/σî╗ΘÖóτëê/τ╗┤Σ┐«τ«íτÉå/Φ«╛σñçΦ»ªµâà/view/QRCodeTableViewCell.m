//
//  QRCodeTableViewCell.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/24.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "QRCodeTableViewCell.h"
#import "ScanViewController.h"
@implementation QRCodeTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)configureForCell:(NSString *)qrStr{
    if (self.qrCodeImageView.image == nil) {
        UIImage *image = [ScanViewController createCodeWithString:qrStr size:CGSizeMake(200, 200) CodeFomart:kBarcodeFormatQRCode];
        self.qrCodeImageView.image = image;
    }
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
