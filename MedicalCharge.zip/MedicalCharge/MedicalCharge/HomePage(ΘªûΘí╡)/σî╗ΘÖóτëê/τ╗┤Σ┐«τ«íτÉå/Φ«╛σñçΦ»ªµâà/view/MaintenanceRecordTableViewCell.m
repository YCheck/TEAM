//
//  MaintenanceRecordTableViewCell.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/24.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "MaintenanceRecordTableViewCell.h"

@implementation MaintenanceRecordTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)configureForCell:(CoreObject_maintenanceRecord *)model{
    self.user.text = model.repairUser;
    self.number.text = model.businessNumber;
    self.maintenanceStage.text = model.maintenanceStage;
    self.repairType.text = model.maintenanceType;
    self.departMent.text = model.departmentName;
    self.time.text = model.repairTime;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
