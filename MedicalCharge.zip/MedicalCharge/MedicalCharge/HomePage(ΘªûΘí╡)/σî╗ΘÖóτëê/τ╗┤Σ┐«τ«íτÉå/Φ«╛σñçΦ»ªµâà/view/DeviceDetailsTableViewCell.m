//
//  DeviceDetailsTableViewCell.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/7.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "DeviceDetailsTableViewCell.h"

@implementation DeviceDetailsTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)configureForCell:(NSDictionary *)info{
    self.titleLabel.text = info.allKeys[0];
    self.contentLabel.text = info.allValues[0];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
