//
//  DetailTitlesTableViewCell.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/7.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "DetailTitlesTableViewCell.h"

@implementation DetailTitlesTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.backgroundColor = LineCOLOR;
}

- (void)configureForCell:(NSString *)model{
    self.titleLabel.text = model;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
    
}

@end
