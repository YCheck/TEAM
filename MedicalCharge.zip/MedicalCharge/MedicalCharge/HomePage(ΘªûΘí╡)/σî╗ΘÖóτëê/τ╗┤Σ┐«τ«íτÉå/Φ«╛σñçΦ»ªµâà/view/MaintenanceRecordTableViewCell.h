//
//  MaintenanceRecordTableViewCell.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/24.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CoreObject+maintenanceRecord.h"
@interface MaintenanceRecordTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *user;
@property (weak, nonatomic) IBOutlet UILabel *number;
@property (weak, nonatomic) IBOutlet UILabel *maintenanceStage;
@property (weak, nonatomic) IBOutlet UILabel *repairType;
@property (weak, nonatomic) IBOutlet UILabel *departMent;
@property (weak, nonatomic) IBOutlet UILabel *time;

- (void)configureForCell:(CoreObject_maintenanceRecord *)model;

@end
