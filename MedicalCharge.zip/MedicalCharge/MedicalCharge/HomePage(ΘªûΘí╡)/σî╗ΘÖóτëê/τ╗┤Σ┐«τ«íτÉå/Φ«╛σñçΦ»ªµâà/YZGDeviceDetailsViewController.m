//
//  YZGDeviceDetailsViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/7.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGDeviceDetailsViewController.h"
#import "DetailTitlesTableViewCell.h"
#import "DeviceDetailsTableViewCell.h"
#import "CoreObject+DeviceDetails.h"
#import "CoreObject+maintenanceRecord.h"
#import "MaintenanceRecordTableViewCell.h"
#import "QRCodeTableViewCell.h"
@interface YZGDeviceDetailsViewController ()

@property (nonatomic,retain) NSMutableArray *firstArray;
@property (nonatomic,retain) NSMutableArray *secondArray;
@property (nonatomic,retain) NSMutableArray *recordArray;

@property (nonatomic,assign) NSInteger selectIndex;
@property (nonatomic,assign) NSInteger startIndex;

@property (nonatomic,retain) DetailTitlesTableViewCell *selectCell;
@property (nonatomic,retain) CoreObject_DeviceDetails *detailModel;

@end

@implementation YZGDeviceDetailsViewController

- (NSMutableArray *)recordArray{
    if (!_recordArray) {
        _recordArray = [NSMutableArray array];
    }
    return _recordArray;
}

- (NSMutableArray *)firstArray{
    if (!_firstArray) {
        _firstArray = [NSMutableArray arrayWithArray:@[@"基本信息",@"维修记录",@"二维码"]];
    }
    return _firstArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"设备详情";
    
    self.detailModel = [[CoreObject_DeviceDetails alloc] init];
    [self initTableView];
    [self getDeviceDetailRequest];
}

- (void)initScrollView{
    [self.customScrollView gainImage:self.detailModel.imgList];
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    DetailTitlesTableViewCell *cell = [self.firstTableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
    cell.backgroundColor = WhiteColor;
    self.selectCell = cell;
}

- (void)initWithDataSource1{
    _secondArray = [NSMutableArray arrayWithArray:@[
                                                    @{@"名称":emptyTransform(self.detailModel.name)},
                                                    @{@"编号":emptyTransform(self.detailModel.materialNumber)},
                                                    @{@"规格":emptyTransform(self.detailModel.specification)},
                                                    @{@"型号":emptyTransform(self.detailModel.model)},
                                                    @{@"品牌":emptyTransform(self.detailModel.brand)},
                                                    @{@"生产厂家":emptyTransform(self.detailModel.manufacturer)},
                                                    @{@"使用科室":emptyTransform(self.detailModel.useDepartment)},
                                                    @{@"责任人":emptyTransform(self.detailModel.responsible)},
                                                    @{@"责任人电话":emptyTransform(self.detailModel.responsiblePhone)},
                                                    @{@"使用状态":emptyTransform(self.detailModel.useStatus)},
                                                    @{@"供应商":emptyTransform(self.detailModel.supplierName)},
                                                    @{@"注册证号":emptyTransform(self.detailModel.registrationNumber)}
                                                    ]];
}

- (void)initTableView{
    _startIndex = 1;
    self.secondArray = [NSMutableArray array];
    self.firstTableView.backgroundColor = LineCOLOR;
    self.firstTableView.estimatedRowHeight = 44.0f;
    self.firstTableView.rowHeight = UITableViewAutomaticDimension;
    self.firstTableView.showsVerticalScrollIndicator = NO;
    [self.firstTableView registerNib:[DetailTitlesTableViewCell ycy_nib] forCellReuseIdentifier:[DetailTitlesTableViewCell ycy_className]];
    
    
    self.secondTableView.backgroundColor = WhiteColor;
    self.secondTableView.estimatedRowHeight = 40;
    self.secondTableView.rowHeight = UITableViewAutomaticDimension;
    [self.secondTableView registerNib:[DeviceDetailsTableViewCell ycy_nib] forCellReuseIdentifier:[DeviceDetailsTableViewCell ycy_className]];
    [self.secondTableView registerNib:[MaintenanceRecordTableViewCell ycy_nib] forCellReuseIdentifier:[MaintenanceRecordTableViewCell ycy_className]];
    [self.secondTableView registerNib:[QRCodeTableViewCell ycy_nib] forCellReuseIdentifier:[QRCodeTableViewCell ycy_className]];
    [self initWithTableViewRefreshAnimation];
}

/**
 数据加载动画配置
 */
- (void)initWithTableViewRefreshAnimation{
    
    self.secondTableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(uploadFooter)];
    self.secondTableView.mj_footer.hidden = YES;
}

#pragma mark -- UITableViewDelegate,UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (tableView == _firstTableView) {
        return 1;
    }else{
        if (self.selectIndex == 0) {
            return 1;
        }else if (self.selectIndex == 1){
            return 1;
        }
        return 1;
    }
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (tableView == _firstTableView) {
        return self.firstArray.count;
    }else{
        if (self.selectIndex == 0){
            return self.secondArray.count;
        }else if (self.selectIndex == 1){//维修记录
            return self.recordArray.count;
        }
        return 1;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView == _firstTableView) {
        DetailTitlesTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[DetailTitlesTableViewCell ycy_className] forIndexPath:indexPath];
        
        [cell configureForCell:self.firstArray[indexPath.row]];
        return cell;
    }else{
        if (self.selectIndex == 0) {
            DeviceDetailsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[DeviceDetailsTableViewCell ycy_className] forIndexPath:indexPath];
            [cell configureForCell:self.secondArray[indexPath.row]];
            return cell;
        }else if (self.selectIndex == 1){
            MaintenanceRecordTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[MaintenanceRecordTableViewCell ycy_className] forIndexPath:indexPath];
            [cell configureForCell:self.recordArray[indexPath.row]];
            return cell;
        }else{
            QRCodeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[QRCodeTableViewCell ycy_className] forIndexPath:indexPath];
            [cell configureForCell:[NSString stringWithFormat:@"%@|%@",self.detailModel.hospitalGuid,self.detailModel.materialNumber]];
            return cell;
        }
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView == _firstTableView) {
        self.selectIndex = indexPath.row;
        if (self.selectCell) {
            self.selectCell.backgroundColor = LineCOLOR;
        }
        DetailTitlesTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
        cell.backgroundColor = WhiteColor;
        self.selectCell = cell;
        if (self.selectIndex == 1) {
            if (self.recordArray.count == 0) {
                [self maintenanceRecordRequest];
            }else{
                [self.secondTableView reloadData];
            }
            self.secondTableView.mj_footer.hidden = NO;
        }else{
            [self.secondTableView reloadData];
            self.secondTableView.mj_footer.hidden = YES;
        }
    }
}

//- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
//    if (tableView == _firstTableView) {
//        return 40;
//    }
//    return 75;
//}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (tableView == _firstTableView) {
        return 0.01;
    }
    return 0.01;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    
    return nil;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    
    return nil;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --------   网络请求------
- (void)getDeviceDetailRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:[CoreObject_DeviceDetails class] andIsPersistence:NO andNumber:1];
}

- (void)maintenanceRecordRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:[CoreObject_maintenanceRecord class] andIsPersistence:NO andNumber:2];
}

- (void)uploadFooter{
    _startIndex ++;
    [self maintenanceRecordRequest];
}

#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    if (manager.requestNumber == 1) {
        return @{@"url":DeviceDetailsAPI,@"params":@{@"guid":self.deviceId}};
    }else if (manager.requestNumber == 2) {
        NSString *sort = @"desc";//默认降序
        
        NSDictionary *param1 = @{@"Rules":@[@{@"Field":@"AccountingId",@"Value":self.detailModel.id,@"Operate":@"equal"}],@"Operate":@"and",@"Groups":@[]};
        return @{@"url":DeviceMaintenanceRecordAPI,@"params":@{@"pageIndex":@(_startIndex),@"pageSize":@(ListPageSize),@"sortField":@"Id",@"sortOrder":sort,@"filter_group":param1.ycy_JSONString}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([result isKindOfClass:[NSDictionary class]] && [manager.response.content[@"success"] integerValue] != 1) {
        [XHToast showCenterWithText:result[@"msg"]];
        [self.secondTableView reloadData];
    }else{
        if (manager.requestNumber == 1){
            
            self.detailModel = manager.model;
            [self initScrollView];
            [self initWithDataSource1];
            [self.secondTableView reloadData];
            
        }else if (manager.requestNumber == 2){
            NSArray *array = manager.model;
            
            if (_startIndex == 1) {
                [self.recordArray removeAllObjects];
            }
            if (array.count < ListPageSize) {
                self.secondTableView.mj_footer.state = MJRefreshStateNoMoreData;
            }
            
            [self.recordArray addObjectsFromArray:array];
            [self.secondTableView reloadData];
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
