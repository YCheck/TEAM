//
//  YZGDeviceDetailsViewController.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/7.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BaseViewController.h"
#import "GLUIScrollView.h"
@interface YZGDeviceDetailsViewController : BaseViewController

@property (weak, nonatomic) IBOutlet GLUIScrollView *customScrollView;


@property (weak, nonatomic) IBOutlet UITableView *firstTableView;
@property (weak, nonatomic) IBOutlet UITableView *secondTableView;

@property (nonatomic, copy) NSString *deviceId;//设备id
@end
