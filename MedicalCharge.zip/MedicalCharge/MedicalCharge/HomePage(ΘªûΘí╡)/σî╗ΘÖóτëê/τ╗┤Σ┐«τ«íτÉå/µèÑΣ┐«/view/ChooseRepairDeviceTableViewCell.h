//
//  ChooseRepairDeviceTableViewCell.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/11.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CoreObject+DeviceDynamic.h"

static NSString *const ChooseButtonAction = @"ChooseButtonAction";
@interface ChooseRepairDeviceTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *deviceName;
@property (weak, nonatomic) IBOutlet UILabel *specification;
@property (weak, nonatomic) IBOutlet UILabel *subject;

@property (weak, nonatomic) IBOutlet UILabel *number;
@property (weak, nonatomic) IBOutlet UIButton *selectButton;

@property (nonatomic,retain) NSIndexPath *indexPath;
- (void)configureForCell:(CoreObject_DeviceDynamic *)model andIndexPath:(NSIndexPath *)indexPath;

@end
