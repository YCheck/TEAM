//
//  YZGChooseRepairDevicesViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/11.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGChooseRepairDevicesViewController.h"
#import "CoreObject+DeviceDynamic.h"
#import "ChooseRepairDeviceTableViewCell.h"
#import "YZGDeviceDetailsViewController.h"
#import "YZGRepairDeviceViewController.h"

@interface YZGChooseRepairDevicesViewController ()<YZGSearchViewDelegate>

@property (nonatomic,retain) NSMutableArray *dataSource;
@property (nonatomic,retain) NSMutableArray *selectedSource;
@property (nonatomic,assign) NSInteger startIndex;
@property (nonatomic,retain) ChooseRepairDeviceTableViewCell *selectCell;

@end

@implementation YZGChooseRepairDevicesViewController

- (NSMutableArray *)selectedSource{
    if (!_selectedSource) {
        _selectedSource = [NSMutableArray array];
    }
    return _selectedSource;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"请选择报修设备";
    
    WeakSelf
    [self actionCustomRightBtnWithNrlImage:@"searchimg" htlImage:nil title:nil btnFrame:CGRectMake(0, 0, 44, 44) action:^{
        [weakSelf rightButtonAction];
    }];
    
    self.searchViewHeight.constant = 0;
    self.searchView.hidden = YES;
    self.searchView.delegate = self;
    
    [self initTableView];
    [self getDeviceListRequest];
}

- (void)rightButtonAction{
    [self searchCheckincoming];
}

- (void)searchCheckincoming{
    if (self.searchViewHeight.constant == 0) {
        self.searchViewHeight.constant = 45;
        self.searchView.hidden = NO;
    }else{
        self.searchView.hidden = YES;
        self.searchViewHeight.constant = 0;
    }
}

#pragma mark -- YZGSearchViewDelegate
- (void)yzg_searchView:(YZGSearchView *)searchView searchContent:(NSString *)content andCollation:(NSInteger)sort{
    [self uploadHeader];
}

- (IBAction)repairButtonAction:(id)sender {
    if (self.selectedSource.count == 0) {
        [XHToast showBottomWithText:@"请选择报修设备"];
        return;
    }
    
    YZGRepairDeviceViewController *controller = [[YZGRepairDeviceViewController alloc] init];
    controller.fromView = 1;
    controller.deviceModel = self.selectedSource[0];
    [self.navigationController pushViewController:controller animated:YES];
}


- (void)initTableView{
    _startIndex = 1;
    self.dataSource = [NSMutableArray array];
    
    self.tableView.backgroundColor = LightGrayColor;
    self.tableView.estimatedRowHeight = 120.0f;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    [self.tableView registerNib:[ChooseRepairDeviceTableViewCell ycy_nib] forCellReuseIdentifier:[ChooseRepairDeviceTableViewCell ycy_className]];
    self.tableView.tableFooterView = [UIView new];
    [self initWithTableViewRefreshAnimation];
}

#pragma mark -- UITableViewDataSource,UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.dataSource.count == 0) {
        return 0;
    }
    return 1;
}

//显示多少组
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ChooseRepairDeviceTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[ChooseRepairDeviceTableViewCell ycy_className] forIndexPath:indexPath];
    CoreObject_DeviceDynamic *device = self.dataSource[indexPath.section];
    [cell configureForCell:device andIndexPath:indexPath];
    
    return cell;
}

//单行点击
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    CoreObject_DeviceDynamic *device = self.dataSource[indexPath.section];
    YZGDeviceDetailsViewController *controller = [[YZGDeviceDetailsViewController alloc] init];
    controller.deviceId = device.gid;
    [self.navigationController pushViewController:controller animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 62;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 10;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    return nil;
    
    //    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, YCYScreen_Width, 42)];
    //    header.backgroundColor = [UIColor whiteColor];
    //
    //    return header;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    
    return nil;
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    [self closeKeyBoard];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self closeKeyBoard];
    return YES;
}

- (void)routerEventWithName:(NSString *)eventName dataInfo:(NSDictionary *)dataInfo{
    if ([eventName isEqualToString:ChooseButtonAction]) {
        NSInteger section = [dataInfo[@"section"] integerValue];
        NSInteger row = [dataInfo[@"row"] integerValue];
        BOOL isSelected = [dataInfo[@"isSelected"] boolValue];
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:section];
        ChooseRepairDeviceTableViewCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
        if (self.selectCell && cell != self.selectCell) {
            self.selectCell.selectButton.selected = NO;
        }
        
        self.selectCell = cell;
        
        CoreObject_DeviceDynamic *model = _dataSource[section];
        model.isSelected = isSelected;
        if (self.selectedSource.count > 0) {
            CoreObject_DeviceDynamic *model = self.selectedSource[0];
            model.isSelected = NO;
            [self.selectedSource removeAllObjects];
        }
        [self.selectedSource addObject:model];
    }
}

#pragma mark --------   网络请求------

- (void)getDeviceListRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:[CoreObject_DeviceDynamic class] andIsPersistence:NO andNumber:1];
}

- (void)uploadHeader{
    _startIndex = 1;
    [self.selectedSource removeAllObjects];
    [self getDeviceListRequest];
}

- (void)uploadFooter{
    _startIndex ++;
    [self getDeviceListRequest];
}

#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    if (manager.requestNumber == 1) {
        NSString *sort = @"desc";//默认降序
        if (self.searchView.timeButton.selected) {
            sort = @"asc";
        }
        
        NSString *value1 = @"8";NSString *value2 = @"";
        
        value2 = self.searchView.textField.text;
        
        NSDictionary *param1 = @{@"Rules":@[@{@"Field":@"UseStatus",@"Value":value1,@"Operate":@"notequal"}],@"Groups":@[@{@"Rules":@[@{@"Field":@"materialNumber",@"Value":value2,@"Operate":@"contains"},@{@"Field":@"name",@"Value":value2,@"Operate":@"contains"}],@"Operate":@"or"}],@"Operate":@"and"};
        return @{@"url":DeviceListAPI,@"params":@{@"pageIndex":@(_startIndex),@"pageSize":@(ListPageSize),@"sortField":@"Id",@"sortOrder":sort,@"filter_group":param1.ycy_JSONString}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([result isKindOfClass:[NSDictionary class]] && [manager.response.content[@"success"] integerValue] != 1) {
        if (manager.requestNumber == 1) {
            [self.dataSource removeAllObjects];
            [self.tableView reloadData];
        }
    }else{
        if (manager.requestNumber == 1){
            
            NSArray *array = manager.model;
            
            if (_startIndex == 1) {
                [_dataSource removeAllObjects];
            }
            if (array.count < ListPageSize) {
                self.tableView.mj_footer.state = MJRefreshStateNoMoreData;
            }else{
                [self.tableView.mj_footer endRefreshing];
            }
            
            [self.dataSource addObjectsFromArray:manager.model];
            [self.tableView reloadData];
            
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
