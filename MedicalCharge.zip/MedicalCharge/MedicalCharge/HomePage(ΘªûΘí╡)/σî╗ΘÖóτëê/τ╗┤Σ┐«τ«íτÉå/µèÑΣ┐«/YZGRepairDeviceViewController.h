//
//  YZGRepairDeviceViewController.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/11.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BaseViewController.h"
#import "AddImageView.h"
#import "CoreObject+DeviceDynamic.h"

@interface YZGRepairDeviceViewController : BaseViewController

@property (weak, nonatomic) IBOutlet UILabel *number;
@property (weak, nonatomic) IBOutlet UITextField *deviceName;
@property (weak, nonatomic) IBOutlet UILabel *subject;
@property (weak, nonatomic) IBOutlet UILabel *repairTime;
@property (weak, nonatomic) IBOutlet UIButton *chooseSubject;


@property (weak, nonatomic) IBOutlet UITextView *textView;

@property (weak, nonatomic) IBOutlet AddImageView *addImageView;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topViewHeightConstraint;

@property (nonatomic,retain) CoreObject_DeviceDynamic *deviceModel;//设备模型
@property (nonatomic,assign) NSInteger fromView;//1 固定资产报修 2手动报修

@end
