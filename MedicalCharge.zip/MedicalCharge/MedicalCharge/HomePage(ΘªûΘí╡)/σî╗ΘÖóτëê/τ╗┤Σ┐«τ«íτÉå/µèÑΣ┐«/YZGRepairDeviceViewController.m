//
//  YZGRepairDeviceViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/11.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGRepairDeviceViewController.h"

@interface YZGRepairDeviceViewController ()<UITextViewDelegate,UITextFieldDelegate,AddImageDelegate,CustomPickerDelegate>

@property (nonatomic,retain) NSString *hospitalGuid;//医院guid
@property (nonatomic,retain) NSString *departmentID;//科室id
@property (nonatomic,retain) NSString *equipId;//报修台账id
@property (nonatomic,retain) NSMutableArray *imageIdArray;
@property (nonatomic,assign) NSInteger uploadImageIndex;//上传的图片下标
@property (nonatomic,retain) NSArray *departmentArray;//供选择科室列表

@end

@implementation YZGRepairDeviceViewController

- (NSMutableArray *)imageIdArray{
    if (!_imageIdArray) {
        _imageIdArray = [NSMutableArray array];
    }
    return _imageIdArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = LightGrayColor;
    self.navigationItem.title = @"添加报修单";
    
    WeakSelf
    [self actionCustomRightBtnWithNrlImage:nil htlImage:nil title:@"保存" btnFrame:CGRectMake(0, 0, 44, 44) action:^{
        [weakSelf rightButtonAction];
    }];
    
    self.textView.placeholder = @"请描述大概情况";
    self.textView.scrollEnabled = YES;
    self.textView.userInteractionEnabled = YES;
    self.textView.delegate = self;
    
    self.addImageView.addImageDelegate = self;
    self.addImageView.clipsToBounds = YES;
    [self.addImageView setImageSource:nil];
    
    if (self.fromView == 1) {
        [self initWithUserInterface];
    }
    
    [self getRepairNumberRequest];
}

- (void)rightButtonAction{
    if (self.number.text.length  == 0) {
        [XHToast showBottomWithText:@"数据异常,请重试~"];
        [self getRepairNumberRequest];
        return;
    }
    if ([self.departmentID integerValue] == 0) {
        [XHToast showBottomWithText:@"数据异常,请重试~"];
        [self getRepairNumberRequest];
        return;
    }
    if (self.fromView == 2) {
        if (self.deviceName.text.length == 0) {
            [XHToast showBottomWithText:@"请输入设备名称~"];
            return;
        }
    }
    if (self.addImageView.imageList.count > 0) {
        [self.imageIdArray removeAllObjects];
        for (int i = 0; i < self.addImageView.imageList.count; i ++) {
            self.uploadImageIndex = i;
            [self uploadImageRequest];
        }
        
    }else{
        [self commitRepairRequest];
    }
}

- (void)initWithUserInterface{
    self.deviceName.userInteractionEnabled = NO;
    self.chooseSubject.userInteractionEnabled = NO;
    self.deviceName.text = self.deviceModel.name;
    self.subject.text = self.deviceModel.useDepartment;
    self.hospitalGuid = self.deviceModel.hospitalGuid;
}

- (IBAction)updateSubjectAction:(id)sender {
    
    NSMutableArray *array = [NSMutableArray array];
    for (NSDictionary *dic in self.departmentArray) {
        [array addObject:@{@"name":dic[@"department"],@"id":dic[@"departmentId"]}];
    }
    
    CustomPickerView *customView = [[CustomPickerView alloc] initWithTarget:self andColumn:1];
    customView.itemsArray1 = array;
    customView.titleString = @"选择科室";
    [customView showView];
}

#pragma mark -- CustomPickerDelegate
- (void)customPickerViewValueChanged:(NSString *)str andIds:(NSArray *)ids andOtherData:(NSDictionary *)info{
    self.subject.text = info[@"name"];
    self.departmentID = info[@"id"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --AddImageDelegate
- (void)monitorImageCountValueChangedForCurrentImages:(NSInteger)imageCount{
    
}

- (void)monitorImageCountValueChangedForCurrentViewHeight:(CGFloat)height{
    self.topViewHeightConstraint.constant = height + 43;
}

- (IBAction)inputVoiceAction:(id)sender {
    [XHToast showBottomWithText:@"程序猿哥哥正在努力开发中~"];
}


- (IBAction)playVoiceAction:(id)sender {
    [XHToast showBottomWithText:@"程序猿哥哥正在努力开发中~"];
}


#pragma mark -- UITextViewDelegate
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    if ([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}

#pragma mark -- UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self closeKeyBoard];
    return YES;
}

- (void)textViewDidChange:(UITextView *)textView{
    //    if (self.textView.text.length > 140) {
    //        self.textView.text = [self.textView.text substringToIndex:140];
    //    }
}

#pragma mark --------   网络请求------

- (void)getRepairNumberRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:1];
}

- (void)commitRepairRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:2];
}

- (void)uploadImageRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:3];
}

#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    
    if (manager.requestNumber == 1) {
        NSString *url = @"";NSDictionary *param = @{};
        if (self.fromView == 1) {
            url = DeviceRepairAPI;
            param = @{@"number":self.deviceModel.materialNumber,@"hospitalGuid":self.deviceModel.hospitalGuid};
        }else if (self.fromView == 2){
            url = OperationRepairAPI;
            param = @{};
        }
        
        return @{@"url":url,@"params":param};
    }else if (manager.requestNumber == 2) {
        NSMutableString *imageIds = [NSMutableString stringWithFormat:@""];
        for (int i = 0; i < self.imageIdArray.count; i ++) {
            [imageIds appendString:[NSString stringWithFormat:@"%@",self.imageIdArray[i]]];
            if (i < self.imageIdArray.count - 1) {
                [imageIds appendString:@","];
            }
        }
        return @{@"url":CommitRepairAPI,@"params":@{@"Name":self.deviceName.text,@"HospitalGUID":self.hospitalGuid,@"BusinessNumber":self.number.text,@"DepartmentId":self.departmentID,@"AccountingID":self.equipId,@"AttachmentId":emptyTransform(imageIds),@"FaultDescription":self.textView.text}};
    }else if (manager.requestNumber == 3){
        UIImage *image = self.addImageView.imageList[_uploadImageIndex];
        NSData *data = UIImageJPEGRepresentation(image,0.8);
        NSString *imgBase64 = [data ycy_base64EncodedString];
        return @{@"url":UploadImageAPI,@"params":@{@"uploadType":@"报修上传图片",@"base64String":imgBase64}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([manager.response.content[@"success"] integerValue] != 1) {
        [XHToast showCenterWithText:result[@"msg"]];
    }else{
        if (manager.requestNumber == 1){
            self.number.text = result[@"data"][@"businessNumber"];
            self.repairTime.text = result[@"data"][@"repairTime"];
            
            if (self.fromView == 2) {
                self.departmentArray = [NSArray arrayWithArray:result[@"data"][@"department"]];
                self.hospitalGuid = result[@"data"][@"hospitalGUID"];
                self.equipId = @"0";
            }
            if (self.fromView == 1) {
                self.departmentID = result[@"data"][@"departmentID"];
                self.equipId = result[@"data"][@"equipId"];
            }
            if (self.departmentArray.count > 0){
                NSDictionary *dic = self.departmentArray[0];
                self.subject.text = dic[@"department"];
                self.departmentID = dic[@"departmentId"];
            }
        }else if(manager.requestNumber == 2){
            [XHToast showCenterWithText:result[@"msg"]];
            if (self.fromView == 1) {
                NSArray *vcs = self.navigationController.viewControllers;
                [self.navigationController popToViewController:vcs[vcs.count - 3] animated:YES];
            }else if (self.fromView == 2){
                [self.navigationController popViewControllerAnimated:YES];
            }
        }else if(manager.requestNumber == 3){
            if ([result[@"data"] count] > 0) {
                NSString *imgId = result[@"data"][0][@"id"];
                [self.imageIdArray addObject:imgId];
            }else{
                [self.imageIdArray addObject:@""];
            }
            
            if ((self.uploadImageIndex == self.addImageView.imageList.count - 1) && (self.imageIdArray.count == self.addImageView.imageList.count)) {
                NSLog(@"一共发布了%li次",self.uploadImageIndex);
                [self commitRepairRequest];
            }
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
