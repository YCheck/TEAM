//
//  YZGCheckIncomingViewController.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/5.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BaseViewController.h"

@interface YZGCheckIncomingViewController : BaseViewController

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIView *lineView;

@property (weak, nonatomic) IBOutlet YZGSearchView *searchView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *searchViewHeight;



@end
