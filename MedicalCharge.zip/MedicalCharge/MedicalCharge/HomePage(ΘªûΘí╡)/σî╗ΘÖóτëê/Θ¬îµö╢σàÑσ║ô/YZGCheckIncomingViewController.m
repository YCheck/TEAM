//
//  YZGCheckIncomingViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/5.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGCheckIncomingViewController.h"
#import "CheckIncomingTableViewCell.h"
#import "CoreObject+CheckIncomingRoot.h"
#import "YZGCheckIncomingDetailViewController.h"
#import "ScanViewController.h"
@interface YZGCheckIncomingViewController ()<YZGSearchViewDelegate>

@property (nonatomic,retain) NSMutableArray *dataSource;
@property (nonatomic, retain) NSIndexPath *indexPath;
@property (nonatomic,assign) NSInteger startIndex;
@property (nonatomic,assign) NSInteger type;//选择状态

@end

@implementation YZGCheckIncomingViewController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self getCheckInComingListRequest];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"验收入库";
    [self initNavigationButtons];
    
    self.type = 1;
    self.searchViewHeight.constant = 0;
    self.searchView.hidden = YES;
    self.searchView.delegate = self;
    
    [self initTableView];
}

- (void)initNavigationButtons{
    UIButton *button1  = [UIButton buttonWithType:UIButtonTypeCustom];
    button1.frame = CGRectMake(0, 0, 40, 44);
    [button1 setImage:YCYImage(@"searchimg") forState:UIControlStateNormal];
    [button1 addTarget:self action:@selector(searchCheckincoming) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *item1 = [[UIBarButtonItem alloc] initWithCustomView:button1];
    
    UIButton *button2  = [UIButton buttonWithType:UIButtonTypeCustom];
    button2.frame = CGRectMake(0, 0, 40, 44);
    [button2 setImage:YCYImage(@"qr") forState:UIControlStateNormal];
    [button2 addTarget:self action:@selector(scanButtonAction) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *item2 = [[UIBarButtonItem alloc] initWithCustomView:button2];
    
    self.navigationItem.rightBarButtonItems = @[item2,item1];
    
}

- (void)searchCheckincoming{
    if (self.searchViewHeight.constant == 0) {
        self.searchViewHeight.constant = 45;
        self.searchView.hidden = NO;
    }else{
        self.searchView.hidden = YES;
        self.searchViewHeight.constant = 0;
    }
}

#pragma mark -- YZGSearchViewDelegate
- (void)yzg_searchView:(YZGSearchView *)searchView searchContent:(NSString *)content andCollation:(NSInteger)sort{
    [self uploadHeader];
}

- (void)scanButtonAction{
    ScanViewController *controller = [[ScanViewController alloc] init];
    controller.fromView = 1;
    [self.navigationController pushViewController:controller animated:YES];
}

- (void)initTableView{
    _startIndex = 1;
    self.dataSource = [NSMutableArray array];
    
    self.tableView.backgroundColor = LightGrayColor;
    self.tableView.estimatedRowHeight = 120.0f;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    [self.tableView registerNib:[CheckIncomingTableViewCell ycy_nib] forCellReuseIdentifier:[CheckIncomingTableViewCell ycy_className]];
    [self initWithTableViewRefreshAnimation];
}

#pragma mark -- UITableViewDelegate,UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.dataSource.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    CoreObject_CheckIncomingRoot *model = self.dataSource[section];
    if (model.isShow == NO) {
        return 0;
    }
    return model.detailsList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CheckIncomingTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[CheckIncomingTableViewCell ycy_className] forIndexPath:indexPath];
    
    CoreObject_CheckIncomingRoot *model = self.dataSource[indexPath.section];
    CoreObject_CheckIncoming *checkModel = model.detailsList[indexPath.row];
    [cell configureForCell:checkModel];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    CoreObject_CheckIncomingRoot *model = self.dataSource[indexPath.section];
    CoreObject_CheckIncoming *checkModel = model.detailsList[indexPath.row];
    
    CheckIncomingTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    
    YCYTableChooseView *chooseView = [[YCYTableChooseView alloc] initDataSource:@[
  @{@"title":@"名称",@"content":checkModel.name},
  @{@"title":@"规格",@"content":checkModel.specification},
  @{@"title":@"型号",@"content":checkModel.model},
  @{@"title":@"包装",@"content":checkModel.packing},
  @{@"title":@"价格",@"content":checkModel.price},
  @{@"title":@"批号",@"content":checkModel.batchNumber},
  @{@"title":@"有效期",@"content":[TimeTransform timeSubstringYMD:checkModel.valid]},
  @{@"title":@"数量",@"content":checkModel.quantity},
  @{@"title":@"厂家",@"content":emptyTransform(checkModel.manufacturer)}
  ] andRelativeView:cell];
    [chooseView showInView];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 36;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 100;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 30;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    CoreObject_CheckIncomingRoot *model = self.dataSource[section];
    
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, YCYScreen_Width, 100)];
    headerView.backgroundColor = LightGrayColor;
    
    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 15, YCYScreen_Width, 85)];
    header.backgroundColor = [UIColor whiteColor];
    [headerView addSubview:header];
    
    UILabel *label = [[UILabel alloc] init];
    label.frame = CGRectMake(15, 12, 70, 15);
    label.font = YCYFont(13);
    label.textColor = TextCOLOR333;
    label.text = @"订单号：";
    [header addSubview:label];
    
    UILabel *order = [[UILabel alloc] init];
    order.frame = CGRectMake(CGRectGetMaxX(label.frame) + 15, 12, 180, 15);
    order.font = YCYFont(13);
    order.textColor = TextCOLOR333;
    order.text = model.businessNumber;
    [header addSubview:order];
    
    UILabel *timeTitle = [[UILabel alloc] init];
    timeTitle.frame = CGRectMake(15, CGRectGetMaxY(label.frame) + 12, 70, 15);
    timeTitle.font = YCYFont(13);
    timeTitle.textColor = TextCOLOR333;
    timeTitle.text = @"时间：";
    [header addSubview:timeTitle];
    
    UILabel *time = [[UILabel alloc] init];
    time.frame = CGRectMake(CGRectGetMaxX(timeTitle.frame) + 15, CGRectGetMaxY(label.frame) + 12, 180, 15);
    time.font = YCYFont(13);
    time.textColor = TextCOLOR333;
    time.text = [TimeTransform timeSubstringYMD:model.orderTime];
    [header addSubview:time];
    
    UILabel *productTitle = [[UILabel alloc] init];
    productTitle.frame = CGRectMake(15, CGRectGetMaxY(timeTitle.frame) + 12, 70, 15);
    productTitle.font = YCYFont(13);
    productTitle.textColor = TextCOLOR333;
    productTitle.text = @"供应商：";
    [header addSubview:productTitle];
    
    UILabel *product = [[UILabel alloc] init];
    product.frame = CGRectMake(CGRectGetMaxX(productTitle.frame) + 15, CGRectGetMaxY(timeTitle.frame) + 12, YCYScreen_Width - 100, 15);
    product.font = YCYFont(13);
    product.textColor = TextCOLOR333;
    product.text = model.supplierName;
    [header addSubview:product];
    
    UILabel *orderStatus = [[UILabel alloc] init];
    orderStatus.frame = CGRectMake(YCYScreen_Width - 100, 12, 85, 15);
    orderStatus.font = YCYFont(13);
    orderStatus.textColor = YCYHexColor(model.orderStageColor);
    orderStatus.textAlignment = NSTextAlignmentRight;
    orderStatus.text = model.orderStage;
    [header addSubview:orderStatus];
    
    UIButton *clickHeaderButton = [UIButton buttonWithType:UIButtonTypeCustom];
    clickHeaderButton.frame = header.bounds;
    clickHeaderButton.backgroundColor = [UIColor clearColor];
    clickHeaderButton.tag = section + 100;
    [clickHeaderButton addTarget:self action:@selector(lookAtOrderDetail:) forControlEvents:UIControlEventTouchUpInside];
    [header addSubview:clickHeaderButton];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(YCYScreen_Width - 80, CGRectGetMaxY(orderStatus.frame) + 8, 65, 24);
    button.backgroundColor = [UIColor whiteColor];
    [button setTitle:@"验收入库" forState:UIControlStateNormal];
    [button setTitleColor:TextCOLOR333 forState:UIControlStateNormal];
    button.tag = section + 10000;
    [button addTarget:self action:@selector(checkListOrder:) forControlEvents:UIControlEventTouchUpInside];
    button.titleLabel.font = YCYFont(13);
    button.layer.borderWidth = 0.5;
    button.hidden = YES;
    button.layer.borderColor = TextCOLOR666.CGColor;
    [header addSubview:button];
    if (self.type == 1) {
        if ([model.orderStage isEqualToString:@"已处理"] || [model.orderStage isEqualToString:@"部分验收"]) {
            button.hidden = NO;
        }
    }
    
    return headerView;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    
    CoreObject_CheckIncomingRoot *model = self.dataSource[section];
    
    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, YCYScreen_Width, 41)];
    header.backgroundColor = [UIColor clearColor];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(0, 0, YCYScreen_Width, 30);
    button.backgroundColor = [UIColor whiteColor];
    [button setTitle:@"" forState:UIControlStateNormal];
    if (model.isShow) {
        [button setImage:YCYImage(@"keepimg") forState:UIControlStateNormal];
    }else{
        [button setImage:YCYImage(@"spreadoutimg") forState:UIControlStateNormal];
    }
    button.tag = section + 20000;
    button.selected = NO;
    [button addTarget:self action:@selector(moreBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [header addSubview:button];
    
    return header;
    
}

- (void)lookAtOrderDetail:(UIButton *)sender{
    NSInteger index = sender.tag - 100;
    
    CoreObject_CheckIncomingRoot *model = self.dataSource[index];
    
    YZGCheckIncomingDetailViewController *controller = [[YZGCheckIncomingDetailViewController alloc] init];
    controller.orderId = model.gid;
    controller.fromView = 1;
    [self.navigationController pushViewController:controller animated:YES];
}

- (void)checkListOrder:(UIButton *)sender{
    NSInteger index = sender.tag - 10000;
    CoreObject_CheckIncomingRoot *model = self.dataSource[index];
    YZGCheckIncomingDetailViewController *controller = [[YZGCheckIncomingDetailViewController alloc] init];
    controller.orderId = model.gid;
    controller.fromView = 2;
    [self.navigationController pushViewController:controller animated:YES];
}

#pragma mark -- 点击查看更多
- (void)moreBtnAction:(UIButton *)sender{
    sender.selected = !sender.selected;
    
    CoreObject_CheckIncomingRoot *model = self.dataSource[sender.tag - 20000];
    if (model.isShow) {
        
    }else{
        for (CoreObject_CheckIncomingRoot *model in self.dataSource) {
            model.isShow = NO;
        }
    }
    model.isShow = !model.isShow;
    
    //    NSIndexSet *set = [NSIndexSet indexSetWithIndex:sender.tag];
    //    [self.tableView reloadSections:set withRowAnimation:UITableViewRowAnimationAutomatic];
    
    [self.tableView reloadData];
}

- (void)routerEventWithName:(NSString *)eventName dataInfo:(NSDictionary *)dataInfo{
//    if ([ApplyMaintenanceAction isEqualToString:eventName]) {
//        NSInteger section = [dataInfo[@"section"] integerValue];
//        NSInteger row = [dataInfo[@"row"] integerValue];
//
//    }
}

#pragma mark -- 顶部按钮切换 11 12
- (IBAction)topButtonAction:(id)sender {
    
    UIButton *button = (UIButton *)sender;
    self.lineView.center = CGPointMake(button.center.x, self.lineView.center.y);
    self.type = button.tag - 10;
    
    [self uploadHeader];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --------   网络请求------

- (void)getCheckInComingListRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:[CoreObject_CheckIncomingRoot class] andIsPersistence:NO andNumber:1];
}

- (void)uploadHeader{
    _startIndex = 1;
    [self getCheckInComingListRequest];
}

- (void)uploadFooter{
    _startIndex ++;
    [self getCheckInComingListRequest];
}

#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    if (manager.requestNumber == 1) {
        NSString *sort = @"desc";//默认降序
        if (self.searchView.timeButton.selected) {
            sort = @"asc";
        }
        
        NSString *value1 = @"1";NSString *value2 = @"";
        if (self.type == 2) {
            value1 = @"3";
        }
        value2 = self.searchView.textField.text;
        
        NSDictionary *param1 = @{@"Rules":@[@{@"Field":@"OrderStage",@"Value":value1,@"Operate":@"equal"},@{@"Field":@"businessNumber",@"Value":value2,@"Operate":@"contains"}],@"Operate":@"and"};
        return @{@"url":CheckInComingListAPI,@"params":@{@"pageIndex":@(_startIndex),@"pageSize":@(ListPageSize),@"sortField":@"Id",@"sortOrder":sort,@"filter_group":param1.ycy_JSONString}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([result isKindOfClass:[NSDictionary class]] && [manager.response.content[@"success"] integerValue] != 1) {
        if (manager.requestNumber == 1) {
            [self.dataSource removeAllObjects];
            [self.tableView reloadData];
        }
    }else{
        if (manager.requestNumber == 1){
            
            NSArray *array = manager.model;
            
            if (_startIndex == 1) {
                [_dataSource removeAllObjects];
            }
            if (array.count < ListPageSize) {
                self.tableView.mj_footer.state = MJRefreshStateNoMoreData;
            }else{
                [self.tableView.mj_footer endRefreshing];
            }
            
            [self.dataSource addObjectsFromArray:manager.model];
            [self.tableView reloadData];
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
