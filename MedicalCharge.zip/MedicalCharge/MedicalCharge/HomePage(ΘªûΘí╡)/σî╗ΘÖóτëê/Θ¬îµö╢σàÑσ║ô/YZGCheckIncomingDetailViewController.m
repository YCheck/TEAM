//
//  YZGCheckIncomingDetailViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/5.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGCheckIncomingDetailViewController.h"
#import "CheckDetailTableViewCell.h"
#import "CoreObject+CheckIncomingRoot.h"
@interface YZGCheckIncomingDetailViewController ()

@property (nonatomic, retain) NSMutableArray *dataSource;
@property (nonatomic, retain) NSIndexPath *indexPath;
@property (nonatomic, retain) CoreObject_CheckIncomingRoot *detailModel;
@property (nonatomic, retain) NSMutableArray *checkArray;

@end

@implementation YZGCheckIncomingDetailViewController

- (NSMutableArray *)checkArray{
    if (!_checkArray) {
        _checkArray = [NSMutableArray array];
    }
    return _checkArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    if (ROLE == 1) {
        if (self.fromView == 1) {
            self.navigationItem.title = @"订单详情";
        }else if(self.fromView == 2){
            self.navigationItem.title = @"验收入库";
        }
        
        [self.bottomButton setTitle:@"验收订单" forState:UIControlStateNormal];
    }else if (ROLE == 2){
        if (self.fromView == 1) {
            self.navigationItem.title = @"订单详情";
        }else if(self.fromView == 2){
            self.navigationItem.title = @"订单录入";
        }
        
        [self.bottomButton setTitle:@"录入订单" forState:UIControlStateNormal];
    }
    
    if (self.fromView == 1) {
        self.bottomViewHeight.constant = 0;
        self.bottomView.hidden = YES;
    }
    
    self.detailModel = [[CoreObject_CheckIncomingRoot alloc] init];
    [self initTableView];
    [self getCheckOrderDetailRequest];
}

- (void)initTableView{
    
    self.dataSource = [NSMutableArray array];
    
    self.tableView.backgroundColor = LightGrayColor;
    self.tableView.estimatedRowHeight = 80.0f;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    [self.tableView registerNib:[CheckDetailTableViewCell ycy_nib] forCellReuseIdentifier:[CheckDetailTableViewCell ycy_className]];
    
    self.tableView.tableHeaderView = self.headerView;
}

- (void)setHeaderViewData{
    if (ROLE == 1) {
        self.hospitalName.text = self.detailModel.supplierName;
    }else if (ROLE == 2){
        self.hospitalName.text = self.detailModel.hospitalName;
    }
    
    self.department.text = self.detailModel.departmentName;
    self.time.text = [TimeTransform timeSubstringYMD:self.detailModel.orderTime];
    self.orderNo.text = self.detailModel.businessNumber;
    self.price.text = YCYAppendString(@"¥", self.detailModel.totalAmount);
}

#pragma mark -- 验收订单
- (IBAction)checkOrderButtonAction:(id)sender {
    [self.checkArray removeAllObjects];
    for (int i = 0; i < self.dataSource.count; i ++) {
        NSMutableDictionary *dic = [NSMutableDictionary dictionary];
        CoreObject_CheckIncoming *checkModel = self.dataSource[i];
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:i];
        CheckDetailTableViewCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
        if (!cell) {
            NSString*cellID = [NSString stringWithFormat:@"checkTable%zd%zd",indexPath.section,indexPath.row];
            cell = [self.tableView dequeueReusableCellWithIdentifier:cellID forIndexPath:indexPath];
        }
        [dic setValue:self.orderId forKey:@"orderGuid"];
        [dic setValue:checkModel.gid forKey:@"guid"];
        if (ROLE == 1) {
            [dic setValue:cell.waitCheckCount.text forKey:@"acceptanceQuantity"];
        }else if (ROLE == 2){
            [dic setValue:cell.count.text forKey:@"quantity"];
            [dic setValue:cell.batchNumber.text forKey:@"batchNumber"];
            [dic setValue:cell.time.titleLabel.text forKey:@"valid"];
        }
        
        [self.checkArray addObject:dic];
    }
    [self commitOrderRequest];
}

#pragma mark -- UITableViewDelegate,UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.dataSource.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (self.dataSource.count == 0){
        return 0;
    }
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSString*cellID = [NSString stringWithFormat:@"checkTable%zd%zd",indexPath.section,indexPath.row];
    CheckDetailTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        
        cell = (CheckDetailTableViewCell *)[[[NSBundle mainBundle] loadNibNamed:[CheckDetailTableViewCell ycy_className] owner:nil options:nil] lastObject];
        
        //因为reuseIdentifier属性是readonly的，使用kvc赋值
        [cell setValue:cellID forKey:@"reuseIdentifier"];
        [cell configureForCell:self.dataSource[indexPath.section] fromView:self.fromView];
        if (ROLE == 1) {
            cell.count.userInteractionEnabled = NO;
            cell.batchNumber.userInteractionEnabled = NO;
            cell.time.userInteractionEnabled = NO;
            if (self.fromView == 2){
                cell.waitCheckCount.layer.borderWidth = 0.5;
                cell.waitCheckCount.layer.borderColor = LineCOLOR.CGColor;
            }
        }else if (ROLE == 2){
            
            cell.count.userInteractionEnabled = YES;
            cell.batchNumber.userInteractionEnabled = YES;
            cell.time.userInteractionEnabled = YES;
            if (self.fromView == 2){
                cell.waitCheckCount.userInteractionEnabled = NO;
                cell.count.layer.borderWidth = 0.5;
                cell.count.layer.borderColor = LineCOLOR.CGColor;
                cell.batchNumber.layer.borderWidth = 0.5;
                cell.batchNumber.layer.borderColor = LineCOLOR.CGColor;
            }
        }
        
        if (self.fromView == 1) {
            cell.count.userInteractionEnabled = NO;
            cell.waitCheckCount.userInteractionEnabled = NO;
            cell.batchNumber.placeholder = @"";
            cell.batchNumber.userInteractionEnabled = NO;
            cell.time.userInteractionEnabled = NO;
        }
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 100;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return 40;
    }
    return 10;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
//    NSInteger height = 10;
//    if (section == 0) {
//        height = 40;
//    }
    
    if (section == 0) {
        UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, YCYScreen_Width, 40)];
        header.backgroundColor = LightGrayColor;
        
        UILabel *label = [[UILabel alloc] init];
        label.frame = CGRectMake(15, 11, 70, 18);
        label.font = YCYFont(15);
        label.textColor = TextCOLOR333;
        label.text = @"订单详情";
        [header addSubview:label];
        return header;
    }
    return nil;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    
    return nil;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --------   网络请求------
- (void)getCheckOrderDetailRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:[CoreObject_CheckIncomingRoot class] andIsPersistence:NO andNumber:1];
}

- (void)commitOrderRequest{
    [CHNetworkingConfig shardInstance].requestType = 1;
    
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:2];
}

#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    if (manager.requestNumber == 1) {
        return @{@"url":CheckOrderDetailsAPI,@"params":@{@"guid":self.orderId}};
    }else if (manager.requestNumber == 2) {
//        NSData *data=[NSJSONSerialization dataWithJSONObject:self.checkArray options:NSJSONWritingPrettyPrinted error:nil];
//        NSString *jsonStr=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSString *url = @"";
        if (ROLE == 1) {
            url = CommitOrderAPI;
        }else if (ROLE == 2){
            url = AddOrderMessageAPI;
        }
        return @{@"url":url,@"params":self.checkArray};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([result isKindOfClass:[NSDictionary class]] && [manager.response.content[@"success"] integerValue] != 1) {
        [XHToast showCenterWithText:result[@"msg"] duration:3];
        [self getCheckOrderDetailRequest];
            
    }else{
        if (manager.requestNumber == 1){
            
            self.detailModel = manager.model;
            
            [self.dataSource removeAllObjects];
            if (self.fromView == 1) {
                [self.dataSource addObjectsFromArray:self.detailModel.detailsList];
            }else if (self.fromView == 2){
                if (ROLE == 1) {
                    for (CoreObject_CheckIncoming *checkModel in self.detailModel.detailsList) {
                        if ([checkModel.noAcceptanceQuantity integerValue] != 0) {
                            [self.dataSource addObject:checkModel];
                        }
                    }
                }else if (ROLE == 2){
                    [self.dataSource addObjectsFromArray:self.detailModel.detailsList];
                }
            }
            
            [self setHeaderViewData];
            [self.tableView reloadData];
            if (self.dataSource.count > 0 && self.fromView == 2) {
                [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:self.dataSource.count - 1] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
            }
            
        }else if (manager.requestNumber == 2){
            [self.navigationController popViewControllerAnimated:YES];
            [XHToast showBottomWithText:@"验收成功~"];
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
