//
//  CheckIncomingTableViewCell.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/5.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "CheckIncomingTableViewCell.h"

@implementation CheckIncomingTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)configureForCell:(CoreObject_CheckIncoming *)model{
    self.name.text = model.name;
    self.specification.text = model.specification;
    self.count.text = [NSString stringWithFormat:@"%@%@",model.quantity,model.unit];
    self.price.text = model.price;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
