//
//  CheckDetailTableViewCell.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/5.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "CheckDetailTableViewCell.h"

@implementation CheckDetailTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    self.waitCheckCount.delegate = self;
    self.batchNumber.delegate = self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self endEditing:YES];
    return YES;
}

- (void)configureForCell:(CoreObject_CheckIncoming *)model fromView:(NSInteger)fromView{
    self.name.text = model.name;
    
    self.specification.text = model.specification;
    self.price.text = model.price;
    if (fromView == 1) {
        self.count.text = [NSString stringWithFormat:@"%@/%@",model.quantity,model.unit];
        self.waitCheckCount.text = model.acceptanceQuantity;
        self.waitCheckTitle.text = @"已验收数量:";
    }else{
        self.count.text = model.quantity;
        self.waitCheckCount.text = model.noAcceptanceQuantity;
        self.waitCheckTitle.text = @"待验收数量:";
    }
    
//    if ([model.acceptanceQuantity integerValue] > 0) {
//        self.checkedTitle.hidden = NO;
//        self.checkedCount.hidden = NO;
//        self.checkedCount.text = model.acceptanceQuantity;
//    }else{
//        self.checkedTitle.hidden = YES;
//        self.checkedCount.hidden = YES;
//    }
    self.batchNumber.text = model.batchNumber;
    [self.time setTitle:model.valid forState:UIControlStateNormal];
}

- (IBAction)timeButtonAction:(id)sender {
    [self endEditing:YES];
    CustomDatePickerView *pickerView = [[CustomDatePickerView alloc] initWithTarget:self];
    [pickerView showView];
}

- (void)datePickerView:(CustomDatePickerView *)pickerView didValueChanged:(NSString *)dateString{
    [self.time setTitle:[TimeTransform timeSubstringYMD:dateString] forState:UIControlStateNormal];
}

@end
