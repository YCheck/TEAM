//
//  CheckIncomingTableViewCell.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/5.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CoreObject+CheckIncoming.h"
static NSString *const LookDetailButtonAction = @"LookDetailButtonAction";
@interface CheckIncomingTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *specification;
@property (weak, nonatomic) IBOutlet UILabel *count;
@property (weak, nonatomic) IBOutlet UILabel *price;


- (void)configureForCell:(CoreObject_CheckIncoming *)model;

@end
