//
//  CheckDetailTableViewCell.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/5.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CoreObject+CheckIncoming.h"

static NSString *const UpdateTimeButtonAction = @"UpdateTimeButtonAction";

@interface CheckDetailTableViewCell : UITableViewCell<UITextFieldDelegate,CustomDatePickerDelegate>

@property (weak, nonatomic) IBOutlet UILabel *name;

@property (weak, nonatomic) IBOutlet UILabel *sendCount;
@property (weak, nonatomic) IBOutlet UITextField *count;
@property (weak, nonatomic) IBOutlet UILabel *specification;
@property (weak, nonatomic) IBOutlet UILabel *price;

@property (weak, nonatomic) IBOutlet UILabel *waitCheckTitle;
@property (weak, nonatomic) IBOutlet UITextField *waitCheckCount;

@property (weak, nonatomic) IBOutlet UITextField *batchNumber;
@property (weak, nonatomic) IBOutlet UIButton *time;

- (void)configureForCell:(CoreObject_CheckIncoming *)model fromView:(NSInteger )fromView;

@end
