//
//  YZGReasonDetailsViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/21.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGReasonDetailsViewController.h"
#import "ReasonListTableViewCell.h"
#import "CoreObject+RecordList.h"
@interface YZGReasonDetailsViewController ()
@property (nonatomic,retain) NSMutableArray *dataSource;
@end

@implementation YZGReasonDetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"查看更换零部件";
    
    [self initTableView];
    [self getRecordListRequest];
}

- (void)initTableView{
    self.dataSource = [NSMutableArray array];
    
    self.tableView.backgroundColor = LightGrayColor;
    self.tableView.estimatedRowHeight = 120.0f;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    [self.tableView registerNib:[ReasonListTableViewCell ycy_nib] forCellReuseIdentifier:[ReasonListTableViewCell ycy_className]];
    self.tableView.tableFooterView = [UIView new];
//    [self initWithTableViewRefreshAnimation];
}

#pragma mark -- UITableViewDataSource,UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.dataSource.count == 0) {
        return 0;
    }
    return 1;
}

//显示多少组
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ReasonListTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[ReasonListTableViewCell ycy_className] forIndexPath:indexPath];
    CoreObject_RecordList *model = self.dataSource[indexPath.section];
    [cell configureForCell:model];
    return cell;
}

//单行点击
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}

//- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
//    return 62;
//}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 10;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    return nil;
    
    //    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, YCYScreen_Width, 42)];
    //    header.backgroundColor = [UIColor whiteColor];
    //
    //    return header;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    
    return nil;
}

#pragma mark --------   网络请求------

- (void)getRecordListRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:[CoreObject_RecordList class] andIsPersistence:NO andNumber:1];
}


#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    if (manager.requestNumber == 1) {
        return @{@"url":PartsListAPI,@"params":@{@"hospitalGuid":self.hospitalGuid,@"applyId":self.applyId}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([result isKindOfClass:[NSDictionary class]] && [manager.response.content[@"success"] integerValue] != 1) {
        if (manager.requestNumber == 1) {
            [self.dataSource removeAllObjects];
            [self.tableView reloadData];
        }
    }else{
        if (manager.requestNumber == 1){
            
            NSArray *array = manager.model;
            
            [_dataSource removeAllObjects];
            [self.dataSource addObjectsFromArray:manager.model];
            [self.tableView reloadData];
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
