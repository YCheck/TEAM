//
//  YZGCommentView.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/21.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YZGCommentView : UIView

@property (strong, nonatomic) IBOutlet UIView *view;


@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *type;
@property (weak, nonatomic) IBOutlet UILabel *score;

@property (nonatomic,assign) NSInteger commentScore;//评论分数

@property (nonatomic,retain) NSDictionary *dataInfo;//数据源

@end
