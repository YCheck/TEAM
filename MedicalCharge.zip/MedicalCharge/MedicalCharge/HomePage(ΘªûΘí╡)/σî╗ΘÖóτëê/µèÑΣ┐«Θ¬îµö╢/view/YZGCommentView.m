//
//  YZGCommentView.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/21.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGCommentView.h"

@implementation YZGCommentView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        [[NSBundle mainBundle] loadNibNamed:@"YZGCommentView" owner:self options:nil];
        
        self.view.frame = CGRectMake(0, 0, frame.size.width, frame.size.height);
        self.frame = frame;
        [self addSubview:self.view];
    }
    return self;
}

- (void)setDataInfo:(NSDictionary *)dataInfo{
    _dataInfo = dataInfo;
    self.name.text = dataInfo[@"maintenanceEngineer"];
    self.type.text = dataInfo[@"maintenance"];
}

//51-55
- (IBAction)clickCommentScoreAction:(id)sender {
    UIButton *button = (UIButton *)sender;
    for (int i = 51; i < button.tag + 1; i ++) {
        UIButton *btn = (UIButton *)[self.view viewWithTag:i];
        btn.selected = YES;
    }
    for (NSInteger j = button.tag + 1; j < 56; j ++) {
        UIButton *btn = (UIButton *)[self.view viewWithTag:j];
        btn.selected = NO;
    }
    self.commentScore = button.tag - 50;
    self.score.text = [NSString stringWithFormat:@"%zi分",self.commentScore];
}

@end
