//
//  FeeListTableViewCell.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/21.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CoreObject+RecordList.h"
@interface FeeListTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *money1;
@property (weak, nonatomic) IBOutlet UILabel *money2;
@property (weak, nonatomic) IBOutlet UILabel *sourceFound;


- (void)configureForCell:(CoreObject_RecordList *)model;
@end
