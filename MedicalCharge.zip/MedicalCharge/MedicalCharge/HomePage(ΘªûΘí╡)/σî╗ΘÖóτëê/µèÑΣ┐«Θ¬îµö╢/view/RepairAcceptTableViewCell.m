//
//  RepairAcceptTableViewCell.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/8.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "RepairAcceptTableViewCell.h"

@implementation RepairAcceptTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
