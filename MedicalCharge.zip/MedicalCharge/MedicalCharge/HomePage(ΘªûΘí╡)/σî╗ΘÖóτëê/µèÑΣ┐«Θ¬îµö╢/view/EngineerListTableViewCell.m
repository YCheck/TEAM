//
//  EngineerListTableViewCell.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/21.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "EngineerListTableViewCell.h"

@implementation EngineerListTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)configureForCell:(CoreObject_RecordList *)model{
    self.name.text = model.maintenanceEngineer;
    self.time.text = [NSString stringWithFormat:@"%@到%@",model.maintenanceStartDate,model.maintenanceEndDate];
//    self.startTime.text = model.maintenanceStartDate;
//    self.endTime.text = model.maintenanceEndDate;
    self.hours.text = model.manHour;
    self.stopTime.text = model.longShutdown;
    self.remark.text = model.maintenanceSituation;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
