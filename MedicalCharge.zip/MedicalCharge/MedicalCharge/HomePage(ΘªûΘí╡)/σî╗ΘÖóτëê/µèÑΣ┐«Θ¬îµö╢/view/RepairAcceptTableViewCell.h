//
//  RepairAcceptTableViewCell.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/8.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RepairAcceptTableViewCell : UITableViewCell

@end
