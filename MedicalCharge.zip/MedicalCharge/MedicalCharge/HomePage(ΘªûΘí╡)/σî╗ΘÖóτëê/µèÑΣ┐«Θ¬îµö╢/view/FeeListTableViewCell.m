//
//  FeeListTableViewCell.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/21.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "FeeListTableViewCell.h"

@implementation FeeListTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)configureForCell:(CoreObject_RecordList *)model{
    self.name.text = model.feeName;
    self.money1.text = model.quotePrice;
    self.money2.text = model.actualPrice;
    self.sourceFound.text = model.fundSource;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
