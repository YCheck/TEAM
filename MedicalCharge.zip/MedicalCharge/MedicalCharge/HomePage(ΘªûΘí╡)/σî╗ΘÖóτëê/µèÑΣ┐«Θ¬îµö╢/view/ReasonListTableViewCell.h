//
//  ReasonListTableViewCell.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/21.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CoreObject+RecordList.h"
@interface ReasonListTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *type;
@property (weak, nonatomic) IBOutlet UILabel *money;

- (void)configureForCell:(CoreObject_RecordList *)model;

@end
