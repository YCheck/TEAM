//
//  YZGAcceptanceViewController.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/8.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BaseViewController.h"
#import "AddImageView.h"

@interface YZGAcceptanceViewController : BaseViewController

@property (weak, nonatomic) IBOutlet UILabel *number;
@property (weak, nonatomic) IBOutlet UILabel *deviceName;
@property (weak, nonatomic) IBOutlet UILabel *company;
@property (weak, nonatomic) IBOutlet UILabel *department;
@property (weak, nonatomic) IBOutlet UILabel *repairTime;


@property (weak, nonatomic) IBOutlet UILabel *checkUser;
@property (weak, nonatomic) IBOutlet UILabel *startTime;
@property (weak, nonatomic) IBOutlet UILabel *endTime;
@property (weak, nonatomic) IBOutlet UILabel *reason;
@property (weak, nonatomic) IBOutlet UILabel *maintenanceHours;
@property (weak, nonatomic) IBOutlet UILabel *stopHours;
@property (weak, nonatomic) IBOutlet UILabel *totalPrice;


@property (weak, nonatomic) IBOutlet UIButton *notThroughButton;
@property (weak, nonatomic) IBOutlet UIButton *throughButton;

@property (weak, nonatomic) IBOutlet UITextView *textView;

@property (weak, nonatomic) IBOutlet AddImageView *addImageView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topViewHeightConstraint;


@property (weak, nonatomic) IBOutlet UIView *commentView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *commentViewHeight;

@property (nonatomic, copy) NSString *repairId;//维修单id

@end
