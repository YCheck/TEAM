//
//  YZGRepairAcceptViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/8.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGRepairAcceptViewController.h"
#import "ScanViewController.h"
#import "RepairAcceptTableViewCell.h"
#import "CoreObject+RepairAcceptRoot.h"
#import "YZGAcceptanceViewController.h"
#import "YZGMaintenanceDetailsViewController.h"
@interface YZGRepairAcceptViewController ()<YZGSearchViewDelegate>

@property (nonatomic,retain) NSMutableArray *dataSource;
@property (nonatomic, retain) NSIndexPath *indexPath;
@property (nonatomic,assign) NSInteger startIndex;
@property (nonatomic,assign) NSInteger type;//选择状态

@end

@implementation YZGRepairAcceptViewController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self getRepairOrderListRequest];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"维修验收";
    [self initNavigationButtons];
    
    self.type = 1;
    self.searchViewHeight.constant = 0;
    self.searchView.hidden = YES;
    self.searchView.delegate = self;
    [self initTableView];
}

- (void)initNavigationButtons{
    UIButton *button1  = [UIButton buttonWithType:UIButtonTypeCustom];
    button1.frame = CGRectMake(0, 0, 40, 44);
    [button1 setImage:YCYImage(@"searchimg") forState:UIControlStateNormal];
    [button1 addTarget:self action:@selector(searchCheckincoming) forControlEvents:UIControlEventTouchUpInside];

    UIBarButtonItem *item1 = [[UIBarButtonItem alloc] initWithCustomView:button1];
    
    UIButton *button2  = [UIButton buttonWithType:UIButtonTypeCustom];
    button2.frame = CGRectMake(0, 0, 40, 44);
    [button2 setImage:YCYImage(@"qr") forState:UIControlStateNormal];
    [button2 addTarget:self action:@selector(scanButtonAction) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *item2 = [[UIBarButtonItem alloc] initWithCustomView:button2];
    
    self.navigationItem.rightBarButtonItems = @[item2,item1];
    
}

- (void)searchCheckincoming{
    if (self.searchViewHeight.constant == 0) {
        self.searchViewHeight.constant = 45;
        self.searchView.hidden = NO;
    }else{
        self.searchView.hidden = YES;
        self.searchViewHeight.constant = 0;
    }
}

- (void)scanButtonAction{
    ScanViewController *controller = [[ScanViewController alloc] init];
    controller.fromView = 4;
    [self.navigationController pushViewController:controller animated:YES];
}

#pragma mark -- YZGSearchViewDelegate
- (void)yzg_searchView:(YZGSearchView *)searchView searchContent:(NSString *)content andCollation:(NSInteger)sort{
    [self uploadHeader];
}

- (void)initTableView{
    _startIndex = 1;
    self.dataSource = [NSMutableArray array];
    
    self.tableView.backgroundColor = LightGrayColor;
    self.tableView.estimatedRowHeight = 120.0f;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    [self.tableView registerNib:[RepairAcceptTableViewCell ycy_nib] forCellReuseIdentifier:[RepairAcceptTableViewCell ycy_className]];
    [self initWithTableViewRefreshAnimation];
}

#pragma mark -- UITableViewDelegate,UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.dataSource.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    CoreObject_RepairAcceptRoot *model = self.dataSource[section];
    if (model.isShow == NO) {
        return 0;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    RepairAcceptTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[RepairAcceptTableViewCell ycy_className] forIndexPath:indexPath];
    //    [cell configureForCell:self.personModel];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 94;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 126;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    CoreObject_RepairAcceptRoot *model = self.dataSource[section];
    
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, YCYScreen_Width, 126)];
    headerView.backgroundColor = LightGrayColor;
    
    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 15, YCYScreen_Width, 111)];
    header.backgroundColor = [UIColor whiteColor];
    [headerView addSubview:header];
    
    UILabel *label = [[UILabel alloc] init];
    label.frame = CGRectMake(15, 12, 70, 15);
    label.font = YCYFont(13);
    label.textColor = TextCOLOR333;
    label.text = @"维修单号";
    [header addSubview:label];
    
    UILabel *order = [[UILabel alloc] init];
    order.frame = CGRectMake(CGRectGetMaxX(label.frame) + 15, 10, 180, 15);
    order.font = YCYFont(13);
    order.textColor = TextCOLOR333;
    order.text = model.businessNumber;
    [header addSubview:order];
    
    UILabel *deviceTitle = [[UILabel alloc] init];
    deviceTitle.frame = CGRectMake(15, CGRectGetMaxY(label.frame) + 10, 70, 15);
    deviceTitle.font = YCYFont(13);
    deviceTitle.textColor = TextCOLOR333;
    deviceTitle.text = @"设备名称";
    [header addSubview:deviceTitle];
    
    UILabel *device = [[UILabel alloc] init];
    device.frame = CGRectMake(CGRectGetMaxX(deviceTitle.frame) + 15, CGRectGetMaxY(label.frame) + 10, 180, 15);
    device.font = YCYFont(13);
    device.textColor = TextCOLOR333;
    device.text = model.name;
    [header addSubview:device];
    
    UILabel *subjectTitle = [[UILabel alloc] init];
    subjectTitle.frame = CGRectMake(15, CGRectGetMaxY(deviceTitle.frame) + 10, 70, 15);
    subjectTitle.font = YCYFont(13);
    subjectTitle.textColor = TextCOLOR333;
    subjectTitle.text = @"报修科室";
    [header addSubview:subjectTitle];
    
    UILabel *subject = [[UILabel alloc] init];
    subject.frame = CGRectMake(CGRectGetMaxX(subjectTitle.frame) + 15, CGRectGetMaxY(deviceTitle.frame) + 10, 180, 15);
    subject.font = YCYFont(13);
    subject.textColor = TextCOLOR333;
    subject.text = model.departmentName;
    [header addSubview:subject];
    
    UILabel *timeTitle = [[UILabel alloc] init];
    timeTitle.frame = CGRectMake(15, CGRectGetMaxY(subjectTitle.frame) + 10, 70, 15);
    timeTitle.font = YCYFont(13);
    timeTitle.textColor = TextCOLOR333;
    timeTitle.text = @"时间：";
    [header addSubview:timeTitle];
    
    UILabel *time = [[UILabel alloc] init];
    time.frame = CGRectMake(CGRectGetMaxX(timeTitle.frame) + 15, CGRectGetMaxY(subjectTitle.frame) + 10, 180, 15);
    time.font = YCYFont(13);
    time.textColor = TextCOLOR333;
    time.text = model.repairTime;
    [header addSubview:time];
    
    UILabel *orderStatus = [[UILabel alloc] init];
    orderStatus.frame = CGRectMake(YCYScreen_Width - 110, 12, 95, 15);
    orderStatus.font = YCYFont(13);
    orderStatus.textColor = RedCOLOR;
    orderStatus.backgroundColor = [UIColor clearColor];
    orderStatus.textAlignment = NSTextAlignmentRight;
    orderStatus.text = model.maintenanceStage;
    [header addSubview:orderStatus];
    
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = header.bounds;
    button.backgroundColor = [UIColor clearColor];
    [button setTitle:@"" forState:UIControlStateNormal];
    [button setTitleColor:WhiteColor forState:UIControlStateNormal];
    button.tag = section + 10000;
    [button addTarget:self action:@selector(lookAtOrderDetail:) forControlEvents:UIControlEventTouchUpInside];
    button.titleLabel.font = YCYFont(13);
    [header addSubview:button];
    
    UIButton *accepting = [UIButton buttonWithType:UIButtonTypeCustom];
    accepting.frame = CGRectMake(YCYScreen_Width - 90, CGRectGetMaxY(orderStatus.frame) + 30, 75, 24);
    accepting.backgroundColor = MainCOLOR;
    [accepting setTitle:@"验收" forState:UIControlStateNormal];
    [accepting setTitleColor:WhiteColor forState:UIControlStateNormal];
    accepting.tag = section + 30000;
    [accepting addTarget:self action:@selector(acceptButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    accepting.titleLabel.font = YCYFont(13);
    accepting.hidden = YES;
    [header addSubview:accepting];
    if ([model.maintenanceStage isEqualToString:@"已维修待验收"] && self.type == 1) {
        accepting.hidden = NO;
    }
    
    return headerView;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    
//    CoreObject_RepairAcceptRoot *model = self.dataSource[section];
//
//    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, YCYScreen_Width, 41)];
//    header.backgroundColor = [UIColor clearColor];
//
//    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
//    button.frame = CGRectMake(0, 0, YCYScreen_Width, 30);
//    button.backgroundColor = [UIColor whiteColor];
//    [button setTitle:@"" forState:UIControlStateNormal];
//    if (model.isShow) {
//        [button setImage:YCYImage(@"keepimg") forState:UIControlStateNormal];
//    }else{
//        [button setImage:YCYImage(@"spreadoutimg") forState:UIControlStateNormal];
//    }
//    button.tag = section + 20000;
//    button.selected = NO;
//    [button addTarget:self action:@selector(moreBtnAction:) forControlEvents:UIControlEventTouchUpInside];
//    [header addSubview:button];
    
    return nil;
    
}

- (void)lookAtOrderDetail:(UIButton *)sender{
    NSInteger index = sender.tag - 10000;
    CoreObject_RepairAcceptRoot *model = self.dataSource[index];
    
    YZGMaintenanceDetailsViewController *controller = [[YZGMaintenanceDetailsViewController alloc] init];
    controller.repairId = model.gid;
    [self.navigationController pushViewController:controller animated:YES];
}

- (void)acceptButtonAction:(UIButton *)sender{
    NSInteger index = sender.tag - 30000;
    
    CoreObject_RepairAcceptRoot *model = self.dataSource[index];
    YZGAcceptanceViewController *controller = [[YZGAcceptanceViewController alloc] init];
    controller.repairId = model.gid;
    [self.navigationController pushViewController:controller animated:YES];
}

#pragma mark -- 点击查看更多
- (void)moreBtnAction:(UIButton *)sender{
    sender.selected = !sender.selected;
    
    CoreObject_RepairAcceptRoot *model = self.dataSource[sender.tag - 20000];
    if (model.isShow) {
        
    }else{
        for (CoreObject_RepairAcceptRoot *model in self.dataSource) {
            model.isShow = NO;
        }
    }
    model.isShow = !model.isShow;
    
    [self.tableView reloadData];
}

- (void)routerEventWithName:(NSString *)eventName dataInfo:(NSDictionary *)dataInfo{
    //    if ([ApplyMaintenanceAction isEqualToString:eventName]) {
    //        NSInteger section = [dataInfo[@"section"] integerValue];
    //        NSInteger row = [dataInfo[@"row"] integerValue];
    //
    //    }
}

#pragma mark -- 顶部按钮切换 11 12
- (IBAction)topButtonAction:(id)sender {
    
    UIButton *button = (UIButton *)sender;
    self.lineView.center = CGPointMake(button.center.x, self.lineView.center.y);
    
    self.type = button.tag - 10;
    [self uploadHeader];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --------   网络请求------

- (void)getRepairOrderListRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:[CoreObject_RepairAcceptRoot class] andIsPersistence:NO andNumber:1];
}


- (void)uploadHeader{
    _startIndex = 1;
    [self getRepairOrderListRequest];
}

- (void)uploadFooter{
    _startIndex ++;
    [self getRepairOrderListRequest];
}

#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    if (manager.requestNumber == 1) {
        NSString *sort = @"desc";//默认降序
        if (self.searchView.timeButton.selected) {
            sort = @"asc";
        }
        
        NSString *value1 = @"0";NSString *value2 = @"";
        if (self.type == 1) {//状态
            value1 = @"9";
        }else if (self.type == 2){
            value1 = @"16";
        }
        value2 = self.searchView.textField.text;
        
        NSDictionary *param1 = @{@"Rules":@[@{@"Field":@"maintenanceStage",@"Value":value1,@"Operate":@"equal"}],@"Groups":@[@{@"Rules":@[@{@"Field":@"businessNumber",@"Value":value2,@"Operate":@"contains"}],@"Operate":@"or"}],@"Operate":@"and"};
        return @{@"url":RepairOrderListAPI,@"params":@{@"pageIndex":@(_startIndex),@"pageSize":@(ListPageSize),@"sortField":@"Id",@"sortOrder":sort,@"filter_group":param1.ycy_JSONString}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([result isKindOfClass:[NSDictionary class]] && [manager.response.content[@"success"] integerValue] != 1) {
        if (manager.requestNumber == 1) {
            [self.dataSource removeAllObjects];
            [self.tableView reloadData];
        }
    }else{
        if (manager.requestNumber == 1){
            
            NSArray *array = manager.model;
            
            if (_startIndex == 1) {
                [_dataSource removeAllObjects];
            }
            if (array.count < ListPageSize) {
                self.tableView.mj_footer.state = MJRefreshStateNoMoreData;
            }else{
                [self.tableView.mj_footer endRefreshing];
            }
            
            [self.dataSource addObjectsFromArray:manager.model];
            [self.tableView reloadData];
        }else if (manager.requestNumber == 2){
            
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
