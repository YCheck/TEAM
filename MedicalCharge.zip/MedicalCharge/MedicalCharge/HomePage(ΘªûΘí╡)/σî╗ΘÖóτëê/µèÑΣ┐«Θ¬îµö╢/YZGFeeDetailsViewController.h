//
//  YZGFeeDetailsViewController.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/21.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BaseViewController.h"

@interface YZGFeeDetailsViewController : BaseViewController

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic, copy) NSString *hospitalGuid;
@property (nonatomic, copy) NSString *applyId;

@end
