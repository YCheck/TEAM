//
//  YZGAcceptanceViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/8.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGAcceptanceViewController.h"
#import "YZGMaintenanceDetailsViewController.h"
#import "CoreObject+MaintenanceDetails.h"
#import "YZGCommentView.h"
#import "YZGEngineerListViewController.h"
#import "YZGReasonDetailsViewController.h"
#import "YZGFeeDetailsViewController.h"

@interface YZGAcceptanceViewController ()<UITextViewDelegate,AddImageDelegate>

@property (nonatomic,retain) NSMutableArray *imageIdArray;
@property (nonatomic,assign) NSInteger uploadImageIndex;//上传的图片下标
@property (nonatomic,retain) CoreObject_MaintenanceDetails *detailModel;
@property (nonatomic,retain) NSMutableArray *views;

@end

@implementation YZGAcceptanceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"维修单";
    
    self.textView.placeholder = @"请填写实际情况";
    self.textView.scrollEnabled = YES;
    self.textView.userInteractionEnabled = YES;
    self.textView.delegate = self;
    
    self.addImageView.addImageDelegate = self;
    self.addImageView.clipsToBounds = YES;
    [self.addImageView setImageSource:nil];
    
    self.detailModel = [[CoreObject_MaintenanceDetails alloc] init];
    [self getAcceptOrderDetailsRequest];
}

- (void)initWithData{
    
    
    self.number.text = self.detailModel.businessNumber;
    self.company.text = self.detailModel.hospitalName;
    self.repairTime.text = self.detailModel.repairTime;
    self.deviceName.text = self.detailModel.name;
    self.department.text = self.detailModel.departmentName;
    
    self.checkUser.text = self.detailModel.engineerName;
    self.startTime.text = self.detailModel.maintenanceStartDate;
    self.endTime.text = self.detailModel.maintenanceEndDate;
    self.reason.text = self.detailModel.faultAnalysis;
    self.maintenanceHours.text = self.detailModel.manHour;
    self.stopHours.text = self.detailModel.longShutdown;
    self.totalPrice.text = YCYAppendString(@"¥", self.detailModel.totalRepairPrice);
    
    self.views = [NSMutableArray array];
    for (NSInteger i = 0; i < self.detailModel.maintenanceEngineer.count; i ++) {
        YZGCommentView *view = [[YZGCommentView alloc] initWithFrame:CGRectMake(0, i * 38, YCYScreen_Width - 30, 36)];
        view.backgroundColor = [UIColor lightGrayColor];
        [view setDataInfo:self.detailModel.maintenanceEngineer[i]];
        view.tag = 101;
        [self.commentView addSubview:view];
        [self.views addObject:view];
    }
    self.commentViewHeight.constant = self.detailModel.maintenanceEngineer.count * 38 + 40;
}

- (IBAction)sureButtonAction:(id)sender {
    
    if (self.notThroughButton.selected == NO && self.throughButton.selected == NO) {
        [XHToast showBottomWithText:@"请选择是否通过验收~"];
        return;
    }
    
    for (YZGCommentView *view in self.views) {
        if (view.commentScore == 0) {
            [XHToast showBottomWithText:@"请对工程师评价"];
            return;
        }
    }
    
    if (self.addImageView.imageList.count > 0) {
        self.imageIdArray = [NSMutableArray array];
        for (NSInteger i = 0; i < self.addImageView.imageList.count; i ++) {
            self.uploadImageIndex = i;
            [self uploadImageRequest];
        }
    }else{
        [self commitAcceptRequest];
    }
}


#pragma mark --AddImageDelegate
- (void)monitorImageCountValueChangedForCurrentImages:(NSInteger)imageCount{
    
}

- (void)monitorImageCountValueChangedForCurrentViewHeight:(CGFloat)height{
    self.topViewHeightConstraint.constant = height + 43;
}

#pragma mark -- 通过 未通过
- (IBAction)AcceptanceButtonAction:(id)sender {
    UIButton *button = (UIButton *)sender;
    if (self.notThroughButton == button) {
        self.notThroughButton.selected  = YES;
        self.throughButton.selected = NO;
    }else{
        self.notThroughButton.selected = NO;
        self.throughButton.selected = YES;
    }
}


#pragma mark -- 查看明细  21 22 23
- (IBAction)lookAtDetails:(id)sender {
    UIButton *button = (UIButton *)sender;
    
    if (button.tag == 21) {
        YZGEngineerListViewController *controller = [[YZGEngineerListViewController alloc] init];
        controller.hospitalGuid = self.detailModel.hospitalGUID;
        controller.applyId = self.detailModel.applyId;
        [self.navigationController pushViewController:controller animated:YES];
    }else if (button.tag == 22) {
        YZGReasonDetailsViewController *controller = [[YZGReasonDetailsViewController alloc] init];
        controller.hospitalGuid = self.detailModel.hospitalGUID;
        controller.applyId = self.detailModel.applyId;
        [self.navigationController pushViewController:controller animated:YES];
    }else if (button.tag == 23) {
        YZGFeeDetailsViewController *controller = [[YZGFeeDetailsViewController alloc] init];
        controller.hospitalGuid = self.detailModel.hospitalGUID;
        controller.applyId = self.detailModel.applyId;
        [self.navigationController pushViewController:controller animated:YES];
    }
    
    
}


#pragma mark -- UITextViewDelegate
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    
    if ([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}


- (void)textViewDidChange:(UITextView *)textView{
//    if (self.textView.text.length > 140) {
//        self.textView.text = [self.textView.text substringToIndex:140];
//    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --------   网络请求------

- (void)getAcceptOrderDetailsRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:[CoreObject_MaintenanceDetails class] andIsPersistence:NO andNumber:1];
}

- (void)commitAcceptRequest{
    [CHNetworkingConfig shardInstance].requestType = 1;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:2];
}

- (void)uploadImageRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:3];
}


#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    
    if (manager.requestNumber == 1) {
        return @{@"url":AcceptOrderDetailAPI,@"params":@{@"guid":self.repairId}};
    }else if (manager.requestNumber == 2) {
        NSMutableString *imageIds = [NSMutableString stringWithFormat:@""];
        for (int i = 0; i < self.imageIdArray.count; i ++) {
            [imageIds appendString:[NSString stringWithFormat:@"%@",self.imageIdArray[i]]];
            if (i < self.imageIdArray.count - 1) {
                [imageIds appendString:@","];
            }
        }
        
        NSInteger noticeStatus = 1;
        if (self.notThroughButton.selected) {
            noticeStatus = 2;
        }else if (self.throughButton.selected){
            noticeStatus = 4;
        }
        NSMutableArray *array = [NSMutableArray array];
        for (int i = 0;i< self.detailModel.maintenanceEngineer.count;i ++) {
            
            NSDictionary *user = self.detailModel.maintenanceEngineer[i];
            YZGCommentView *view = self.views[i];
            NSDictionary *param = @{@"hospitalGuid":self.detailModel.hospitalGUID,@"applyId":self.detailModel.applyId,@"applyGuid":self.detailModel.applyGuid,@"hospitalId":self.detailModel.hospitalId,@"processId":user[@"processID"],@"businessNumber":self.detailModel.businessNumber,@"engineerName":emptyTransform(user[@"maintenanceEngineer"]),@"engineerId":user[@"maintenanceEngineerId"],@"maintenanceType":emptyTransform(user[@"maintenanceType"]),@"serviceEvaluation":@(view.commentScore),@"evaluationComment":self.textView.text,@"departmentId":self.detailModel.departmentID,@"attachmentId":imageIds,@"acceptanceStatus":@(noticeStatus)};
            [array addObject:param];
        }
        
        return @{@"url":RepairAcceptAPI,@"params":array};
    }else if (manager.requestNumber == 3){
        UIImage *image = self.addImageView.imageList[_uploadImageIndex];
        NSData *data = UIImageJPEGRepresentation(image,0.8);
        NSString *imgBase64 = [data ycy_base64EncodedString];
        return @{@"url":UploadImageAPI,@"params":@{@"uploadType":@"维修处理上传图片",@"base64String":imgBase64}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([manager.response.content[@"success"] integerValue] != 1) {
        [XHToast showCenterWithText:result[@"msg"]];
    }else{
        if (manager.requestNumber == 1){
            self.detailModel = manager.model;
            [self initWithData];
        }else if(manager.requestNumber == 2){
            [XHToast showBottomWithText:result[@"msg"] duration:2];
            [self.navigationController popViewControllerAnimated:YES];
        }else if(manager.requestNumber == 3){
            if ([result[@"data"] count] > 0) {
                NSString *imgId = result[@"data"][0][@"id"];
                [self.imageIdArray addObject:imgId];
            }else{
                [self.imageIdArray addObject:@""];
            }
            
            if (self.imageIdArray.count == self.addImageView.imageList.count) {
                NSLog(@"一共发布了%li次",self.imageIdArray.count);
                [self commitAcceptRequest];
            }
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
