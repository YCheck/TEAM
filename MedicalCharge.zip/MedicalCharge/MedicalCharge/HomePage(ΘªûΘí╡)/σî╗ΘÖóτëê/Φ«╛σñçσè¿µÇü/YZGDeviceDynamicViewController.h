//
//  YZGDeviceDynamicViewController.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/9.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BaseViewController.h"

@interface YZGDeviceDynamicViewController : BaseViewController

@property (weak, nonatomic) IBOutlet YZGSearchView *searchView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *searchViewHeight;

@property (weak, nonatomic) IBOutlet UITableView *tableView;


@end
