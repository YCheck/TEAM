//
//  DeviceDynamicTableViewCell.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/9.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "DeviceDynamicTableViewCell.h"

@implementation DeviceDynamicTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
//    self.detailsButton.layer.borderWidth = 0.5;
//    self.detailsButton.layer.borderColor = TextCOLOR666.CGColor;
}

- (void)configureForCell:(CoreObject_DeviceDynamic *)model andIndexPath:(NSIndexPath *)indexPath{
    _indexPath = indexPath;
    self.selectButton.selected = model.isSelected;
    
    self.number.text = model.materialNumber;
    self.deviceName.text = model.name;
    self.specification.text = model.specification;
    self.status.text = model.useStatus;
}

- (IBAction)chooseButtonAction:(id)sender {
    
    UIButton *button = (UIButton *)sender;
    button.selected = !button.selected;
    [self routerEventWithName:ChooseButtonAction dataInfo:@{@"section":@(_indexPath.section),@"row":@(_indexPath.row),@"isSelected":@(button.selected)}];
}

- (IBAction)lookDetailAction:(id)sender {
    [self routerEventWithName:LookDetailButtonAction dataInfo:@{@"section":@(_indexPath.section),@"row":@(_indexPath.row)}];
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
