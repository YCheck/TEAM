//
//  DeviceDynamicTableViewCell.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/9.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CoreObject+DeviceDynamic.h"

static NSString *const LookDetailButtonAction = @"LookDetailButtonAction";
static NSString *const ChooseButtonAction = @"ChooseButtonAction";

@interface DeviceDynamicTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIButton *selectButton;

@property (weak, nonatomic) IBOutlet UILabel *number;
@property (weak, nonatomic) IBOutlet UILabel *deviceName;
@property (weak, nonatomic) IBOutlet UILabel *specification;
@property (weak, nonatomic) IBOutlet UILabel *status;
@property (weak, nonatomic) IBOutlet UIButton *detailsButton;

@property (nonatomic,retain) NSIndexPath *indexPath;
- (void)configureForCell:(CoreObject_DeviceDynamic *)model andIndexPath:(NSIndexPath *)indexPath;

@end
