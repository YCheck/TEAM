//
//  YZGDeviceDynamicViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/9.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGDeviceDynamicViewController.h"
#import "ScanViewController.h"
#import "DeviceDynamicTableViewCell.h"
#import "CoreObject+DeviceDynamic.h"
#import "YZGDeviceDetailsViewController.h"

@interface YZGDeviceDynamicViewController ()<YCYActionSheetDelegate,YZGSearchViewDelegate>

@property (nonatomic,retain) NSMutableArray *dataSource;
@property (nonatomic,retain) NSMutableArray *selectedSource;
@property (nonatomic,assign) NSInteger startIndex;
@property (nonatomic,retain) NSString *deviceStatus;//设备状态

@end

@implementation YZGDeviceDynamicViewController

- (NSMutableArray *)selectedSource{
    if (!_selectedSource) {
        _selectedSource = [NSMutableArray array];
    }
    return _selectedSource;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"门诊科设备汇总";
    [self initNavigationButtons];
    
    self.searchViewHeight.constant = 0;
    self.searchView.hidden = YES;
    self.searchView.delegate = self;
    
    [self initTableView];
    [self getDeviceListRequest];
}

- (void)initNavigationButtons{
    UIButton *button0  = [UIButton buttonWithType:UIButtonTypeCustom];
    button0.frame = CGRectMake(0, 0, 30, 44);
    [button0 setImage:YCYImage(@"search") forState:UIControlStateNormal];
    [button0 addTarget:self action:@selector(searchCheckincoming) forControlEvents:UIControlEventTouchUpInside];
    button0.imageEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);
    
    UIBarButtonItem *item0 = [[UIBarButtonItem alloc] initWithCustomView:button0];
    
    UIButton *button1  = [UIButton buttonWithType:UIButtonTypeCustom];
    button1.frame = CGRectMake(0, 0, 30, 44);
    [button1 setImage:YCYImage(@"editBtn") forState:UIControlStateNormal];
    [button1 addTarget:self action:@selector(editMaintenanceStatus) forControlEvents:UIControlEventTouchUpInside];
    button1.imageEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);
    
    UIBarButtonItem *item1 = [[UIBarButtonItem alloc] initWithCustomView:button1];
    
    UIButton *button2  = [UIButton buttonWithType:UIButtonTypeCustom];
    button2.frame = CGRectMake(0, 0, 40, 44);
    [button2 setImage:YCYImage(@"qr") forState:UIControlStateNormal];
    [button2 addTarget:self action:@selector(scanButtonAction) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *item2 = [[UIBarButtonItem alloc] initWithCustomView:button2];
    
    self.navigationItem.rightBarButtonItems = @[item2,item1,item0];
    
}

- (void)searchCheckincoming{
    if (self.searchViewHeight.constant == 0) {
        self.searchViewHeight.constant = 45;
        self.searchView.hidden = NO;
    }else{
        self.searchView.hidden = YES;
        self.searchViewHeight.constant = 0;
    }
}

#pragma mark -- YZGSearchViewDelegate
- (void)yzg_searchView:(YZGSearchView *)searchView searchContent:(NSString *)content andCollation:(NSInteger)sort{
    [self uploadHeader];
}

- (void)editMaintenanceStatus{
    YCYActionSheet *actionSheet = [[YCYActionSheet alloc] initWithTarget:self andTitles:@[@"在用设备",@"闲置设备",@"停用设备"]];
    [actionSheet showView];
    
}

- (void)ycyActionSheet:(YCYActionSheet *)actionSheet andSelectedIndex:(NSInteger)selectIndex{
    NSArray *array = @[@"在用设备",@"闲置设备",@"停用设备"];
    self.deviceStatus = array[selectIndex];
    [self updateDeviceStatusRequest];
}

- (void)scanButtonAction{
    [XHToast showBottomWithText:@"程序猿哥哥正在努力开发中~"];
//    ScanViewController *controller = [[ScanViewController alloc] init];
//    [self.navigationController pushViewController:controller animated:YES];
}

- (void)initTableView{
    _startIndex = 1;
    self.dataSource = [NSMutableArray array];
    
    self.tableView.backgroundColor = LightGrayColor;
    self.tableView.estimatedRowHeight = 120.0f;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    [self.tableView registerNib:[DeviceDynamicTableViewCell ycy_nib] forCellReuseIdentifier:[DeviceDynamicTableViewCell ycy_className]];
    self.tableView.tableFooterView = [UIView new];
    [self initWithTableViewRefreshAnimation];
}

#pragma mark -- UITableViewDataSource,UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.dataSource.count == 0) {
        return 0;
    }
    return 1;
}

//显示多少组
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    DeviceDynamicTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[DeviceDynamicTableViewCell ycy_className] forIndexPath:indexPath];
    CoreObject_DeviceDynamic *device = self.dataSource[indexPath.section];
    [cell configureForCell:device andIndexPath:indexPath];
    
    return cell;
}

//单行点击
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    CoreObject_DeviceDynamic *device = self.dataSource[indexPath.section];
    YZGDeviceDetailsViewController *controller = [[YZGDeviceDetailsViewController alloc] init];
    controller.deviceId = device.gid;
    [self.navigationController pushViewController:controller animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 108;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 10;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    return nil;
    
//    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, YCYScreen_Width, 42)];
//    header.backgroundColor = [UIColor whiteColor];
//    
//    return header;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    
    return nil;
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    [self closeKeyBoard];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self closeKeyBoard];
    return YES;
}

- (void)routerEventWithName:(NSString *)eventName dataInfo:(NSDictionary *)dataInfo{
    if ([eventName isEqualToString:ChooseButtonAction]) {
        NSInteger section = [dataInfo[@"section"] integerValue];
//        NSInteger row = [dataInfo[@"row"] integerValue];
        BOOL isSelected = [dataInfo[@"isSelected"] boolValue];
        
        CoreObject_DeviceDynamic *model = _dataSource[section];
        model.isSelected = isSelected;
        
        if (isSelected == YES) {
            [self.selectedSource addObject:model];
        }else{
            [self.selectedSource removeObject:model];
        }
    }else if ([eventName isEqualToString:LookDetailButtonAction]) {
        
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --------   网络请求------

- (void)getDeviceListRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:[CoreObject_DeviceDynamic class] andIsPersistence:NO andNumber:1];
}

- (void)updateDeviceStatusRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:2];
}

- (void)uploadHeader{
    _startIndex = 1;
    [self.selectedSource removeAllObjects];
    [self getDeviceListRequest];
}

- (void)uploadFooter{
    _startIndex ++;
    [self getDeviceListRequest];
}

#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    if (manager.requestNumber == 1) {
        NSString *sort = @"desc";//默认降序
        if (self.searchView.timeButton.selected) {
            sort = @"asc";
        }

        NSString *value2 = @"";
        
        value2 = self.searchView.textField.text;
        
        NSDictionary *param1 = @{@"Groups":@[@{@"Rules":@[@{@"Field":@"materialNumber",@"Value":value2,@"Operate":@"contains"},@{@"Field":@"name",@"Value":value2,@"Operate":@"contains"}],@"Operate":@"or"}],@"Operate":@"and"};
        return @{@"url":DeviceDynamicListAPI,@"params":@{@"pageIndex":@(_startIndex),@"pageSize":@(ListPageSize),@"sortField":@"Id",@"sortOrder":sort,@"filter_group":param1.ycy_JSONString}};
    }else if (manager.requestNumber == 2){
        NSMutableArray *array = [NSMutableArray array];
        for (CoreObject_DeviceDynamic *model in self.selectedSource) {
            [array addObject:model.gid];
        }
        return @{@"url":UpdateDeviceStatusAPI,@"params":@{@"useStatus":self.deviceStatus,@"guids":array}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([result isKindOfClass:[NSDictionary class]] && [manager.response.content[@"success"] integerValue] != 1) {
        [XHToast showBottomWithText:result[@"msg"] duration:2];
    }else{
        if (manager.requestNumber == 1){
            
            NSArray *array = manager.model;
            
            if (_startIndex == 1) {
                [_dataSource removeAllObjects];
            }
            if (array.count < ListPageSize) {
                self.tableView.mj_footer.state = MJRefreshStateNoMoreData;
            }else{
                [self.tableView.mj_footer endRefreshing];
            }
            
            [self.dataSource addObjectsFromArray:manager.model];
            [self.tableView reloadData];
            
        }else if (manager.requestNumber == 2){
            [XHToast showBottomWithText:result[@"msg"] duration:2];
            [self uploadHeader];
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
