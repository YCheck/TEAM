//
//  HospitalHeaderView.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/2.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
static NSString *const ChooseButtonAction = @"ChooseButtonAction";
static NSString *const ClickNoticeAction = @"ClickNoticeAction";

@interface HospitalHeaderView : UICollectionReusableView

@property (weak, nonatomic) IBOutlet UIButton *headerButton;
@property (weak, nonatomic) IBOutlet UILabel *hospitalName;
@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *subject;
@property (weak, nonatomic) IBOutlet UILabel *workNumber;

@property (weak, nonatomic) IBOutlet UILabel *waitOrder;
@property (weak, nonatomic) IBOutlet UILabel *myRepair;
@property (weak, nonatomic) IBOutlet UILabel *myApprove;

@property (weak, nonatomic) IBOutlet UILabel *noticeLabel;


- (void)configureForHeaderView:(NSDictionary *)info;

@end
