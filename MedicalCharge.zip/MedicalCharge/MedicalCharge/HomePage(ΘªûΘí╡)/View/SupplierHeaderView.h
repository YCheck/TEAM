//
//  SupplierHeaderView.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/2.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
static NSString *const ChooseButtonsAction = @"ChooseButtonsAction";

@interface SupplierHeaderView : UICollectionReusableView

@property (weak, nonatomic) IBOutlet UIButton *headerButton;
@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *subject;
@property (weak, nonatomic) IBOutlet UILabel *company;


@property (weak, nonatomic) IBOutlet UILabel *orderNumber;
@property (weak, nonatomic) IBOutlet UILabel *repairNumber;


- (void)configureForHeaderView:(NSDictionary *)info;

@end
