//
//  HospitalHeaderView.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/2.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "HospitalHeaderView.h"

@implementation HospitalHeaderView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (void)configureForHeaderView:(NSDictionary *)info{
    [self.headerButton sd_setImageWithURL:YCYURL(HeaderPath) forState:UIControlStateNormal placeholderImage:HeaderDefaultImage];
    self.headerButton.layer.cornerRadius = 38;
    self.headerButton.clipsToBounds = YES;
//    [self.headerButton.imageView py_setImageWithURL:YCYURL(HeaderPath) placeholderImage:HeaderDefaultImage];
    
    self.hospitalName.text = Company;
    self.name.text = RealName;
    self.subject.text = DepartmentName;
    self.workNumber.text = LoginName;
    
    
    self.waitOrder.text = [NSString stringWithFormat:@"%@",info[@"number1"]];
    self.myRepair.text = [NSString stringWithFormat:@"%@",info[@"number2"]];
    self.myApprove.text = [NSString stringWithFormat:@"%@",info[@"number3"]];
    self.noticeLabel.text = [NSString stringWithFormat:@"%@",emptyTransform(info[@"messageContent"])];
}

// 101 102 103
- (IBAction)clickButtonsAction:(id)sender {
    UIButton *button = (UIButton *)sender;
    
    [self routerEventWithName:ChooseButtonAction dataInfo:@{@"index":@(button.tag - 100)}];
    
}

- (IBAction)scanButtonAction:(id)sender {
    [self routerEventWithName:ChooseButtonAction dataInfo:@{@"index":@(10000)}];
}

- (IBAction)clickNoticeAction:(id)sender {
    [self routerEventWithName:ClickNoticeAction dataInfo:@{@"index":@(111)}];
}


@end
