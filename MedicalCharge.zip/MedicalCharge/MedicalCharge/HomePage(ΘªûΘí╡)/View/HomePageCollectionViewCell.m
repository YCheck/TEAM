//
//  HomePageCollectionViewCell.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/2.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "HomePageCollectionViewCell.h"

@implementation HomePageCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)configureForCell:(NSDictionary *)model{
    self.imageContent.image = YCYImage(model[@"img"]);
    self.titleLabel.text = model[@"title"];
    if ([model[@"number"] integerValue] == 0) {
        self.markLabel.hidden = YES;
    }else{
        self.markLabel.hidden = NO;
        self.markLabel.text = [NSString stringWithFormat:@"%@",model[@"number"]];
    }
}

@end
