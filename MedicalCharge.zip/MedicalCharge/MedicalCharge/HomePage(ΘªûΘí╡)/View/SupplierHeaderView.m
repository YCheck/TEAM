//
//  SupplierHeaderView.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/2.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "SupplierHeaderView.h"

@implementation SupplierHeaderView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

// 101 102
- (IBAction)clickButtonsAction:(id)sender {
    UIButton *button = (UIButton *)sender;
    
    [self routerEventWithName:ChooseButtonsAction dataInfo:@{@"index":@(button.tag - 100)}];
}


- (void)configureForHeaderView:(NSDictionary *)info{
    self.headerButton.layer.cornerRadius = 38;
    self.headerButton.clipsToBounds = YES;
    [self.headerButton sd_setImageWithURL:YCYURL(HeaderPath) forState:UIControlStateNormal placeholderImage:HeaderDefaultImage];
//    [self.headerButton.imageView py_setImageWithURL:YCYURL(HeaderPath) placeholderImage:HeaderDefaultImage];
    
    self.company.text = Company;
    self.name.text = RealName;
    if (IsEngineer) {
        self.subject.hidden = NO;
    }else{
        self.subject.hidden = YES;
    }
    
    
    self.orderNumber.text = [NSString stringWithFormat:@"%@",info[@"number1"]];
    self.repairNumber.text = [NSString stringWithFormat:@"%@",info[@"number2"]];
}

@end
