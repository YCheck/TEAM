//
//  ScanJumpLogic.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/25.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef void(^CallBack)(NSDictionary* result);

@interface ScanJumpLogic : NSObject


/**
 获取订单状态

 @param hospitalGuid 医院guid
 @param number 编号
 @param fromView 扫码所来自的页面
 @param block 返回订单状态
 */
+ (void)getOrderStatusForHospitalGuid:(NSString *)hospitalGuid businessNumber:(NSString *)number fromView:(NSInteger)fromView andBlock:(CallBack)block;

@end
