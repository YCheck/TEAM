//
//  ScanViewController.h
//  Social
//
//  Created by yangchengyou on 17/11/9.
//  Copyright © 2017年 NULLS. All rights reserved.
//

#import "BaseViewController.h"
#import <ZXingObjC.h>
@interface ScanViewController : BaseViewController
//1 验收入库（耗材）  2 扫码报修 3 维修管理 4报修验收
@property (nonatomic,assign) NSInteger fromView;


/**
 *  根据字符串生成二维码 UIImage 对象
 *
 *  @param str 需要生成二维码的字符串
 *  @param size 生成的大小
 *  @param format 二维码选 kBarcodeFormatQRCode
 *  @return 生成的二维码
 */
+ (UIImage*)createCodeWithString:(NSString*)str
                            size:(CGSize)size
                      CodeFomart:(ZXBarcodeFormat)format;


@end
