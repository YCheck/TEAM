//
//  ScanJumpLogic.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/25.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "ScanJumpLogic.h"

@interface ScanJumpLogic ()<CHNetWorkingDelegate>
{
    
}

//1 验收入库（耗材）  2 扫码报修 3 维修管理 4报修验收
@property (nonatomic,assign) NSInteger fromView;

@property (nonatomic,retain) NSString *hospitalGuid;//医院guid
@property (nonatomic, copy) NSString *number;//编号

@property (nonatomic,copy) CallBack callBack;
@property (nonatomic,retain) ScanJumpLogic *scanLogic;


@end
@implementation ScanJumpLogic

+(void)getOrderStatusForHospitalGuid:(NSString *)hospitalGuid businessNumber:(NSString *)number fromView:(NSInteger)fromView andBlock:(CallBack)block{
    ScanJumpLogic *scanLogic = [[self alloc] init];
    scanLogic.callBack = block;
    scanLogic.hospitalGuid = hospitalGuid;
    scanLogic.number = number;
    scanLogic.fromView = fromView;
    scanLogic.scanLogic = scanLogic;
    
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:scanLogic.scanLogic andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:1];
}


#pragma mark== networkdelegate
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    if (manager.requestNumber == 1) {//获取地铁信息
        NSString *url = @"";
        NSString *numberKey = @"businessNumber";
        if (self.scanLogic.fromView == 1) {
            url = CheckOrderDetailsForScanAPI;
        }else if (self.scanLogic.fromView == 2){
            numberKey = @"number";
            url = ScanCodeRepairAPI;
        }else if (self.scanLogic.fromView == 3){
            numberKey = @"number";
            url = ScanCodeAPI;
        }else if (self.scanLogic.fromView == 4){
            numberKey = @"number";
            url = ScanCheckAPI;
        }
        return @{@"url":url,@"params":@{numberKey:self.scanLogic.number,@"hospitalGuid":self.scanLogic.hospitalGuid}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    NSDictionary *result = manager.response.content;
    if ([manager.response.content[@"success"] integerValue] != 1) {
        [XHToast showCenterWithText:result[@"msg"] duration:3];
        self.callBack(nil);
    }else{
        if (manager.requestNumber == 1) {
            if (self.fromView == 1) {
                self.callBack(@{@"gid":result[@"data"][@"gid"],@"status":result[@"data"][@"orderStage"]});
            }else if (self.fromView == 2){
                self.callBack(result[@"data"]);
            }else if (self.fromView == 3){
            self.callBack(@{@"msg":result[@"msg"],@"number":self.number,@"hospitalGuid":self.hospitalGuid});
            }else{
                self.callBack(result[@"data"]);
            }
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [XHToast showBottomWithText:@"网络错误~"];
}

@end
