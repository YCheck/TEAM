//
//  ScanViewController.m
//  Social
//
//  Created by yangchengyou on 17/11/9.
//  Copyright © 2017年 NULLS. All rights reserved.
//

#import "ScanViewController.h"
#import "ScanJumpLogic.h"
#import "CoreObject+DeviceDynamic.h"
#import "YZGCheckIncomingDetailViewController.h"
#import "YZGRepairDeviceViewController.h"
#import "YZGAcceptanceViewController.h"
#import "YZGMaintenanceRegisterViewController.h"
#define scanX (YCYScreen_Width - scanWidth)/2
#define scanY 80
#define scanWidth   260
#define scanHeight  260
@interface BScanMaskView : UIView

@end

@implementation BScanMaskView

- (instancetype)initWithFrame:(CGRect)frame{
    if(self = [super initWithFrame:frame]){
        self.backgroundColor = [UIColor clearColor];
    }
    return self;
}

- (void)drawRect:(CGRect)rect{
    [super drawRect:rect];
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    CGContextBeginPath(ctx);
    CGContextSetFillColorWithColor(ctx, [[UIColor blackColor] colorWithAlphaComponent:0.5].CGColor);
    CGContextSetStrokeColorWithColor(ctx, [UIColor clearColor].CGColor);
    CGContextFillRect(ctx, rect);
    
    NSInteger top = scanY;
    if (YCYScreen_Height < 667) {
        top = 40;
    }
    
    CGContextAddRect(ctx, CGRectMake(scanX,top + 1, scanWidth,scanHeight ));
    CGContextDrawPath(ctx, kCGPathStroke);
    
    CGContextAddRect(ctx, CGRectMake(scanX,top + 1, scanWidth, scanHeight));
    CGContextSetBlendMode(ctx, kCGBlendModeClear);
    CGContextDrawPath(ctx, kCGPathFill);
}

@end

@interface ScanViewController ()<AVCaptureMetadataOutputObjectsDelegate>
{
    NSTimer *_timer;
    NSDictionary *_currentInfo;
    UIImageView *_imageView;
}
@property (nonatomic,strong) UIImageView *scanLineImage;
@property (nonatomic,retain) UIImage *selectedImage;

@property (strong,nonatomic)AVCaptureDevice * device;
@property (strong,nonatomic)AVCaptureDeviceInput * input;
@property (strong,nonatomic)AVCaptureMetadataOutput * output;
@property (strong,nonatomic)AVCaptureSession * session;
@property (strong,nonatomic)AVCaptureVideoPreviewLayer * preview;

@property (nonatomic,assign) NSInteger scanType;//区别是 2计时  1报修 3登记
@property (nonatomic,retain) NSDictionary *result;

@end

@implementation ScanViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"扫一扫";
    self.view.backgroundColor = [UIColor blackColor];
//    WeakSelf
//    [self actionCustomRightBtnWithNrlImage:nil htlImage:nil title:@"相册" btnFrame:CGRectMake(0, 0, 40, 44) action:^{
//        [weakSelf choosePhoto];
//    }];
    
    _imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"main_saomiaokuang"]];
    [self.view addSubview:_imageView];
    [self setImageViewConstraint];
    
    [self.view addSubview:self.scanLineImage];
    
    BScanMaskView *mask = [[BScanMaskView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    [self.view addSubview:mask];
    [self initUI:self.view.bounds];
    
    UILabel *tipLabel = [[UILabel alloc] init];
    tipLabel.text = @"请将二维码对准";
    tipLabel.textColor = WhiteColor;
    tipLabel.font = YCYFont(15);
    tipLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:tipLabel];
    [tipLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_imageView.mas_bottom).offset(10);
        make.height.offset(21);
        make.left.offset(0);
        make.right.offset(0);
    }];
    
//    UIButton *createQRCode = [UIButton buttonWithType:UIButtonTypeCustom];
//    [createQRCode setTitle:@"生成我自己的二维码" forState:UIControlStateNormal];
//    [createQRCode setTitleColor:YCYHexColor(@"00d44a") forState:UIControlStateNormal];
//    createQRCode.titleLabel.font = YCYFont(16);
//    [createQRCode addTarget:self action:@selector(createQRCodeAction) forControlEvents:UIControlEventTouchUpInside];
//    [self.view addSubview:createQRCode];
//    createQRCode.layer.cornerRadius = 2;
//    createQRCode.layer.borderWidth = 1;
//    createQRCode.layer.borderColor = YCYHexColor(@"00d44a").CGColor;
//    [createQRCode mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.equalTo(tipLabel.mas_bottom).offset(43);
//        make.width.offset(scanWidth);
//        make.height.offset(40);
//        make.centerX.offset(0);
//    }];
//
//    UIButton *payQRCode = [UIButton buttonWithType:UIButtonTypeCustom];
//    [payQRCode setTitle:@"付款二维码" forState:UIControlStateNormal];
//    [payQRCode setImage:YCYImage(@"b3_fukuan") forState:UIControlStateNormal];
//    [payQRCode setTitleColor:WhiteColor forState:UIControlStateNormal];
//    payQRCode.titleLabel.font = YCYFont(15);
//    [payQRCode addTarget:self action:@selector(createPayQRCodeAction:) forControlEvents:UIControlEventTouchUpInside];
//    [self.view addSubview:payQRCode];
//    payQRCode.tag = 1;
//    payQRCode.layer.cornerRadius = 2;
//    payQRCode.backgroundColor = YCYHexColor(@"dddddd");
//    [payQRCode ycy_setImagePosition:YCYImagePositionLeft spacing:10];
//    [payQRCode mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.bottom.offset(-30);
//        make.width.offset(150);
//        make.height.offset(40);
//        make.centerX.offset(-92);
//    }];
//
//    UIButton *collectionQRCode = [UIButton buttonWithType:UIButtonTypeCustom];
//    [collectionQRCode setTitle:@"收款二维码" forState:UIControlStateNormal];
//    [collectionQRCode setImage:YCYImage(@"b3_shoukuan") forState:UIControlStateNormal];
//    [collectionQRCode setTitleColor:WhiteColor forState:UIControlStateNormal];
//    collectionQRCode.titleLabel.font = YCYFont(15);
//    [collectionQRCode addTarget:self action:@selector(createPayQRCodeAction:) forControlEvents:UIControlEventTouchUpInside];
//    [self.view addSubview:collectionQRCode];
//    collectionQRCode.tag = 2;
//    collectionQRCode.layer.cornerRadius = 2;
//    collectionQRCode.backgroundColor = YCYHexColor(@"dddddd");
//    [collectionQRCode ycy_setImagePosition:YCYImagePositionLeft spacing:10];
//    [collectionQRCode mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.bottom.offset(-30);
//        make.width.offset(150);
//        make.height.offset(40);
//        make.centerX.offset(92);
//    }];
//    if (YCYScreen_Height < 667) {
//        [collectionQRCode mas_updateConstraints:^(MASConstraintMaker *make) {
//            make.centerX.offset(82);
//            make.width.offset(130);
//        }];
//        [payQRCode mas_updateConstraints:^(MASConstraintMaker *make) {
//            make.centerX.offset(-82);
//            make.width.offset(130);
//        }];
//    }
}

- (void)backViewController{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)setImageViewConstraint{
    NSInteger top = scanY;
    if (YCYScreen_Height < 667) {
        top = 40;
    }
    [_imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.offset(top);
        make.centerX.offset(0);
        make.width.offset(260);
        make.height.offset(260);
    }];
    
}

- (void)choosePhoto{
    //三方相册选择
    TZImagePickerController *imagePickerVc = [[TZImagePickerController alloc] initWithMaxImagesCount:1 delegate:nil];
    imagePickerVc.sortAscendingByModificationDate = NO;
    imagePickerVc.allowPickingOriginalPhoto = NO;
    imagePickerVc.allowPickingVideo = NO;
    imagePickerVc.allowTakePicture = NO;
    imagePickerVc.allowPreview = NO;
    WeakSelf
    [imagePickerVc setDidFinishPickingPhotosHandle:^(NSArray<UIImage *> *photos, NSArray *assets, BOOL isSelectOriginalPhoto) {
        if (photos.count > 0) {
            weakSelf.selectedImage = photos[0];
            [weakSelf zxReadFromeImage:weakSelf.selectedImage];
        }
    }];
    [self presentViewController:imagePickerVc animated:YES completion:nil];
}

#pragma mark -- 开始扫描
- (void)startScan{
    [self startAnimation];
    _timer = [NSTimer scheduledTimerWithTimeInterval:4 target:self selector:@selector(startAnimation) userInfo:nil repeats:YES];
}

- (void)initUI:(CGRect)previewFrame
{
    
    self.device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    NSError *error = nil;
    
    self.input = [AVCaptureDeviceInput deviceInputWithDevice:self.device error:&error];
    if (error) {
        NSLog(@"您的手机不支持扫码功能");
        return;
    }
    
    self.output = [[AVCaptureMetadataOutput alloc]init];
    
    [self.output setMetadataObjectsDelegate:self queue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)];
    
    self.session = [[AVCaptureSession alloc]init];
    
    if ([self.session canAddInput:self.input])
    {
        [self.session addInput:self.input];
    }
    
    if ([self.session canAddOutput:self.output])
    {
        [self.session addOutput:self.output];
    }
    
    if ([UIScreen mainScreen].bounds.size.height == 480)
    {
        [self.session setSessionPreset:AVCaptureSessionPreset640x480];
    }
    else
    {
        [self.session setSessionPreset:AVCaptureSessionPresetHigh];
    }
    
    if ([self.output.availableMetadataObjectTypes containsObject:AVMetadataObjectTypeQRCode]||
        [self.output.availableMetadataObjectTypes containsObject:AVMetadataObjectTypeCode128Code]){
        [_output setMetadataObjectTypes:[NSArray arrayWithObjects:AVMetadataObjectTypeQRCode,AVMetadataObjectTypeCode39Code,AVMetadataObjectTypeCode128Code,AVMetadataObjectTypeCode39Mod43Code,AVMetadataObjectTypeEAN13Code,AVMetadataObjectTypeEAN8Code,AVMetadataObjectTypeCode93Code,nil]];
    }else {
        return;
    }
    
    self.preview = [AVCaptureVideoPreviewLayer layerWithSession:self.session];
    
    self.preview.videoGravity = AVLayerVideoGravityResizeAspectFill;
    
    self.preview.frame = previewFrame;
    if ([[self.preview connection] isVideoOrientationSupported]){
        [[self.preview connection] setVideoOrientation:(AVCaptureVideoOrientation)[UIApplication sharedApplication].statusBarOrientation];
    }
    [self.view.layer insertSublayer:self.preview atIndex:0];
    [self.session startRunning];
}

#pragma mark ==av delegate
- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputMetadataObjects:(NSArray *)metadataObjects fromConnection:(AVCaptureConnection *)connection
{
    //暂停扫描
    //    [_timer invalidate];
    [self.session stopRunning];
    
    id val = nil;
    if (metadataObjects.count > 0)
    {
        AVMetadataMachineReadableCodeObject *obj = metadataObjects[0];
        
        NSLog(@"二维码数据 = %@",val);
        [self sendRequest:obj.stringValue];
        //扫描完成
    }
}


- (void)zxReadFromeImage:(UIImage *)image{
    
    if(!image)return;
    ZXLuminanceSource *source = [[ZXCGImageLuminanceSource alloc]initWithCGImage:image.CGImage];
    ZXBinaryBitmap *bitmap = [ZXBinaryBitmap binaryBitmapWithBinarizer:[ZXHybridBinarizer binarizerWithSource:source]];
    NSError *error = nil;
    ZXDecodeHints *hints = [ZXDecodeHints hints];
    ZXMultiFormatReader *reader = [ZXMultiFormatReader reader];
    ZXResult *result = [reader decode:bitmap hints:hints error:&error];
    if(result){
        NSString *contents = result.text;
        [self sendRequest:contents];
        return;
        //完成
    }else{
        NSLog(@"%@",error.localizedDescription);
        [XHToast showBottomWithText:error.localizedDescription duration:3];
        
    }
}

- (void)sendRequest:(NSString *)code{
    NSLog(@"扫描成功 === code= %@",code);
    NSLog(@"============%@",[NSThread currentThread]);
    NSArray *array = [code componentsSeparatedByString:@"|"];
    if (!code || code.length == 0 || array.count != 2) {
        
        WeakSelf
        [self ycy_performOnMainThread:^{
            [XHToast showBottomWithText:@"二维码无效~" duration:2];
            [weakSelf.navigationController popViewControllerAnimated:YES];
//            [weakSelf performSelector:@selector(startRunning) withObject:nil afterDelay:2];
        } wait:NO];
        
        return;
    }
    
//    NSDictionary *val = [code ycy_dictionaryValue];
//
//    if (val.allKeys == 0 || val[@"type"] == [NSNull null] || val[@"data"] == [NSNull null]) {
//        [XHToast showBottomWithText:@"无法识别~"];
//        [self.session startRunning];
//        return;
//    }
//    _currentInfo = val;
    WeakSelf
    [self ycy_performOnMainThread:^{
        [weakSelf scanResultInfo:array];
    } wait:NO];
    
    
}

- (void)startRunning{
    [self.session startRunning];
}

- (void)scanResultInfo:(NSArray *)array{
    NSString *hospitalGuid = array[0];
    NSString *number = array[1];
    if (hospitalGuid.length == 0) {
        [XHToast showBottomWithText:@"医院数据异常~"];
        return;
    }
    if (number.length == 0) {
        [XHToast showBottomWithText:@"数据异常~"];
        return;
    }
    WeakSelf
    [ScanJumpLogic getOrderStatusForHospitalGuid:hospitalGuid businessNumber:number fromView:self.fromView andBlock:^(NSDictionary *result) {
        [weakSelf scanStatus:result];
        
    }];
}

//扫描线动画
- (void)startAnimation
{
    CABasicAnimation *anima = [CABasicAnimation animationWithKeyPath:@"position"];
    anima.fromValue = [NSValue valueWithCGPoint:CGPointMake(self.scanLineImage.center.x, self.scanLineImage.center.y )];
    anima.toValue = [NSValue valueWithCGPoint:CGPointMake(self.scanLineImage.center.x, self.scanLineImage.center.y + scanHeight)];
    anima.duration = 4.0f;
    [_scanLineImage.layer addAnimation:anima forKey:@"positionAnimation"];
    
}

- (UIImageView *)scanLineImage{
    if (!_scanLineImage) {
        NSInteger top = scanY;
        if (YCYScreen_Height < 667) {
            top = 40;
        }
        self.scanLineImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"main_saomiaotiao"]];
        self.scanLineImage.frame = CGRectMake(scanX, top, scanWidth, 2);
        self.scanLineImage.center = CGPointMake(self.view.center.x, self.scanLineImage.center.y);
    }
    return _scanLineImage;
}

- (void)viewWillAppear:(BOOL)animated{
    if (self.session) {
        [self.session startRunning];
    }
    [self startScan];
    
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
}

- (void)viewDidDisappear:(BOOL)animated{
    [_timer invalidate];
    if (self.session) {
        [self.session stopRunning];
    }
    _timer = nil;
}

/**
 *  根据字符串生成二维码 UIImage 对象
 *
 *  @param str 需要生成二维码的字符串
 *  @param size 生成的大小
 *  @param format 二维码选 kBarcodeFormatQRCode
 *  @return 生成的二维码
 */
+ (UIImage*)createCodeWithString:(NSString*)str
                            size:(CGSize)size
                      CodeFomart:(ZXBarcodeFormat)format
{
    ZXMultiFormatWriter *writer = [[ZXMultiFormatWriter alloc] init];
    ZXBitMatrix *result = [writer encode:str format:format width:size.width height:size.width error:nil];
    ZXImage *image = [ZXImage imageWithMatrix:result];
    return [UIImage imageWithCGImage:image.cgimage];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma mark -- 根据扫码返回状态跳转不同界面

- (void)scanStatus:(NSDictionary *)result{
    
    if (result == nil) {
        [self.session startRunning];
        return;
    }
    
    if (self.fromView == 1) {
        NSString *status = result[@"status"];
        YZGCheckIncomingDetailViewController *controller = [[YZGCheckIncomingDetailViewController alloc] init];
        controller.orderId = result[@"gid"];
        if ([status isEqualToString:@"已处理"] || [status isEqualToString:@"已发货"] || [status isEqualToString:@"部分验收"]) {
            controller.fromView = 2;
        }else{
            controller.fromView = 1;
        }
        [self pushToControllerDetail:controller];
    }else if (self.fromView == 2){
        CoreObject_DeviceDynamic *model = [[CoreObject_DeviceDynamic alloc] init];
        model.materialNumber = emptyTransform(result[@"sbNumber"]);
        model.name = emptyTransform(result[@"name"]);
        model.useDepartment = emptyTransform(result[@"departmentName"]);
        model.hospitalGuid = emptyTransform(result[@"hospitalGUID"]);
        
        YZGRepairDeviceViewController *controller = [[YZGRepairDeviceViewController alloc] init];
        controller.fromView = 1;
        controller.deviceModel = model;
        [self pushToControllerDetail:controller];
    }else if (self.fromView == 3){
        NSString *status = result[@"msg"];
        self.result = result;
        if ([status isEqualToString:@"扫码报修"]) {
            self.scanType = 1;
            [self getScanCodeRequest];
        }else if ([status isEqualToString:@"扫码计时"]){
            self.scanType = 2;
            [self getScanCodeRequest];
        }else if ([status isEqualToString:@"维修登记"]){
            self.scanType = 3;
            [self getScanCodeRequest];
        }else{
            [self.session startRunning];
            return;
        }
    }else if (self.fromView == 4){
        YZGAcceptanceViewController *controller = [[YZGAcceptanceViewController alloc] init];
        controller.repairId = result[@"applyGuid"];
        [self pushToControllerDetail:controller];
    }else{
        [self.session startRunning];
    }
}

- (void)pushToControllerDetail:(UIViewController *)controller{
    NSMutableArray *viewControllers = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
    [viewControllers removeLastObject];
    [viewControllers addObject:controller];
    self.navigationController.viewControllers = viewControllers;
}

#pragma mark --------   网络请求------
- (void)getScanCodeRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:1];
}

#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    if (manager.requestNumber == 1) {
        NSString *url = @"";
        NSString *numberKey = @"number";
        if (self.scanType == 1) {
            numberKey = @"number";
            url = ScanCodeRepairAPI;
        }else if (self.scanType == 2){
            numberKey = @"number";
            url = MaintenanceTimingAPI;
        }else if (self.scanType == 3){
            numberKey = @"number";
            url = MaintenanceRegisterScanAPI;
        }
        return @{@"url":url,@"params":@{numberKey:self.result[@"number"],@"hospitalGuid":self.result[@"hospitalGuid"]}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([result isKindOfClass:[NSDictionary class]] && [manager.response.content[@"success"] integerValue] != 1) {
        [XHToast showCenterWithText:result[@"msg"] duration:3];
        [self.session startRunning];
    }else{
        if (manager.requestNumber == 1){
            if (self.scanType == 1) {
                CoreObject_DeviceDynamic *model = [[CoreObject_DeviceDynamic alloc] init];
                model.materialNumber = emptyTransform(result[@"data"][@"sbNumber"]);
                model.name = emptyTransform(result[@"data"][@"name"]);
                model.useDepartment = emptyTransform(result[@"data"][@"departmentName"]);
                model.hospitalGuid = emptyTransform(result[@"data"][@"hospitalGUID"]);
                
                YZGRepairDeviceViewController *controller = [[YZGRepairDeviceViewController alloc] init];
                controller.fromView = 1;
                controller.deviceModel = model;
                [self pushToControllerDetail:controller];
            }else if (self.scanType == 2){
                [XHToast showCenterWithText:result[@"msg"] duration:2];
                [self.navigationController popViewControllerAnimated:YES];
            }else if (self.scanType == 3){
//                [self.navigationController popViewControllerAnimated:YES];
//                [[NSNotificationCenter defaultCenter] postNotificationName:@"ScanRegister" object:nil userInfo:@{@"gid":result[@"data"][@"gid"]}];
                YZGMaintenanceRegisterViewController *controller = [[YZGMaintenanceRegisterViewController alloc] init];
                controller.repairId = emptyTransform(result[@"data"][@"applyGuid"]);
                [self pushToControllerDetail:controller];
            }
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

