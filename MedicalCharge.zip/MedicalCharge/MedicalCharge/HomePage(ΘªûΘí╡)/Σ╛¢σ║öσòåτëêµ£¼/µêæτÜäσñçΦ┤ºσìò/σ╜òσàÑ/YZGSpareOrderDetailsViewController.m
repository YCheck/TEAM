//
//  YZGSpareOrderDetailsViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/23.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGSpareOrderDetailsViewController.h"
#import "SpareOrderDetailsTableViewCell.h"
#import "CoreObject+CheckIncomingRoot.h"
@interface YZGSpareOrderDetailsViewController ()

@property (nonatomic, retain) NSMutableArray *dataSource;
@property (nonatomic, retain) NSIndexPath *indexPath;
@property (nonatomic, retain) CoreObject_CheckIncomingRoot *detailModel;
@property (nonatomic, retain) NSMutableArray *checkArray;

@end

@implementation YZGSpareOrderDetailsViewController

- (NSMutableArray *)checkArray{
    if (!_checkArray) {
        _checkArray = [NSMutableArray array];
    }
    return _checkArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    if (self.fromView == 1) {
        self.navigationItem.title = @"备货单信息";
        self.bottomViewHeight.constant = 0;
        self.bottomView.hidden = YES;
    }else if (self.fromView == 2){
        self.navigationItem.title = @"录入备货单";
    }
    
    self.detailModel = [[CoreObject_CheckIncomingRoot alloc] init];
    [self initTableView];
    [self getSpareOrderDetailRequest];
}

- (void)initTableView{
    
    self.dataSource = [NSMutableArray array];
    
    self.tableView.backgroundColor = LightGrayColor;
    self.tableView.estimatedRowHeight = 80.0f;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    [self.tableView registerNib:[SpareOrderDetailsTableViewCell ycy_nib] forCellReuseIdentifier:[SpareOrderDetailsTableViewCell ycy_className]];
    
    self.tableView.tableHeaderView = self.headerView;
}

- (void)setHeaderViewData{
    self.hospitalName.text = self.detailModel.hospitalName;
    self.department.text = self.detailModel.departmentName;
    self.time.text = [TimeTransform timeSubstringYMD:self.detailModel.orderTime];
    self.orderNo.text = self.detailModel.businessNumber;
    self.orderState.text = self.detailModel.orderStage;
    self.price.text = YCYAppendString(@"¥", self.detailModel.totalAmount);
}

#pragma mark -- 验收订单
- (IBAction)checkOrderButtonAction:(id)sender{
    [self.checkArray removeAllObjects];
    
    for (CoreObject_CheckIncoming *model in self.dataSource) {
        NSMutableDictionary *dic = [NSMutableDictionary dictionary];
        [dic setValue:self.orderId forKey:@"orderGuid"];
        [dic setValue:model.gid forKey:@"guid"];
        if (model.batchNumber.length == 0) {
            [XHToast showBottomWithText:@"请输入批号~"];
            return;
        }else if (model.serialNum.length == 0) {
            [XHToast showBottomWithText:@"请输入序列号~"];
            return;
        }else if (model.productNum.length == 0) {
            [XHToast showBottomWithText:@"请输入产品编号~"];
            return;
        }
        [dic setValue:model.productNum forKey:@"productNum"];
        [dic setValue:model.batchNumber forKey:@"batchNumber"];
        [dic setValue:model.valid forKey:@"valid"];
        [dic setValue:model.serialNum forKey:@"serialNum"];
        [self.checkArray addObject:dic];
    }
    [self commitOrderRequest];
}

#pragma mark -- UITableViewDelegate,UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.dataSource.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (self.dataSource.count == 0){
        return 0;
    }
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    SpareOrderDetailsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[SpareOrderDetailsTableViewCell ycy_className] forIndexPath:indexPath];
    CoreObject_CheckIncoming *model = self.dataSource[indexPath.section];
    [cell configureForCell:model indexPath:indexPath];
    
    if (self.fromView == 1) {
        cell.timeButton.userInteractionEnabled = NO;
        cell.number.userInteractionEnabled = NO;
        cell.serialNumber.userInteractionEnabled = NO;
        cell.code.userInteractionEnabled = NO;
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}

//- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
//    return 100;
//}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return 40;
    }
    return 10;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    //    NSInteger height = 10;
    //    if (section == 0) {
    //        height = 40;
    //    }
    
    if (section == 0) {
        UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, YCYScreen_Width, 40)];
        header.backgroundColor = LightGrayColor;
        
        UILabel *label = [[UILabel alloc] init];
        label.frame = CGRectMake(15, 11, 120, 18);
        label.font = YCYFont(15);
        label.textColor = TextCOLOR333;
        label.text = @"备货单详情";
        [header addSubview:label];
        return header;
    }
    return nil;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    
    return nil;
}

- (void)routerEventWithName:(NSString *)eventName dataInfo:(NSDictionary *)dataInfo{
    if ([EndEditTextAction isEqualToString:eventName]) {
        NSInteger section = [dataInfo[@"section"] integerValue];
        NSInteger type = [dataInfo[@"type"] integerValue];
        NSString *content = dataInfo[@"content"];
        CoreObject_CheckIncoming *model = self.dataSource[section];
        if (type == 1) {
            model.batchNumber = content;
        }else if (type == 2) {
            model.valid = content;
        }else if (type == 3) {
            model.serialNum = content;
        }else if (type == 4) {
            model.productNum = content;
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --------   网络请求------
- (void)getSpareOrderDetailRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:[CoreObject_CheckIncomingRoot class] andIsPersistence:NO andNumber:1];
}

- (void)commitOrderRequest{
    [CHNetworkingConfig shardInstance].requestType = 1;
    
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:2];
}

#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    if (manager.requestNumber == 1) {
        return @{@"url":SpareOrderDetailsAPI,@"params":@{@"orderID":self.orderId}};
    }else if (manager.requestNumber == 2) {
        
        return @{@"url":AddSpareOrderAPI,@"params":self.checkArray};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([result isKindOfClass:[NSDictionary class]] && [manager.response.content[@"success"] integerValue] != 1) {
        [XHToast showCenterWithText:result[@"msg"] duration:3];
        
    }else{
        if (manager.requestNumber == 1){
            
            self.detailModel = manager.model;
            
            [self.dataSource removeAllObjects];
            if (self.fromView == 1) {
                [self.dataSource addObjectsFromArray:self.detailModel.detailsList];
            }else if (self.fromView == 2){
                [self.dataSource addObjectsFromArray:self.detailModel.detailsList];
            }
            
            [self setHeaderViewData];
            [self.tableView reloadData];
            
            
        }else if (manager.requestNumber == 2){
            [self.navigationController popViewControllerAnimated:YES];
            [XHToast showCenterWithText:result[@"msg"] duration:2];
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
