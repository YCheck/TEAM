//
//  SpareOrderDetailsTableViewCell.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/23.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CoreObject+CheckIncoming.h"

static NSString *const EndEditTextAction = @"EndEditTextAction";

@interface SpareOrderDetailsTableViewCell : UITableViewCell<UITextFieldDelegate,CustomDatePickerDelegate>

@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *specification;
@property (weak, nonatomic) IBOutlet UILabel *packing;
@property (weak, nonatomic) IBOutlet UILabel *price;

@property (weak, nonatomic) IBOutlet UITextField *number;
@property (weak, nonatomic) IBOutlet UITextField *serialNumber;
@property (weak, nonatomic) IBOutlet UITextField *time;
@property (weak, nonatomic) IBOutlet UITextField *code;
@property (weak, nonatomic) IBOutlet UIButton *timeButton;




@property (nonatomic,assign) NSInteger section;
- (void)configureForCell:(CoreObject_CheckIncoming *)model indexPath:(NSIndexPath *)indexPath;

@end
