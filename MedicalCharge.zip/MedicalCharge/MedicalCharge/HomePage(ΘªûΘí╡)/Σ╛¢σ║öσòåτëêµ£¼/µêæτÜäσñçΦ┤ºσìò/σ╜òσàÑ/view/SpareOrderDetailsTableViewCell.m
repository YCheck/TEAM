//
//  SpareOrderDetailsTableViewCell.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/23.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "SpareOrderDetailsTableViewCell.h"

@implementation SpareOrderDetailsTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.number.delegate = self;
    self.serialNumber.delegate = self;
    self.code.delegate = self;
}

- (void)configureForCell:(CoreObject_CheckIncoming *)model indexPath:(NSIndexPath *)indexPath{
    _section = indexPath.section;
    
    self.name.text = model.name;
    self.specification.text = [NSString stringWithFormat:@"%@/%@",model.quantity,model.unit];
    self.packing.text = model.packing;
    self.price.text = model.price;
    
    self.number.text = model.batchNumber;
    self.time.text = [TimeTransform timeSubstringYMD:model.valid];
    self.serialNumber.text = model.serialNum;
    self.code.text = model.productNum;
}

- (IBAction)chooseDateAction:(id)sender {
    [self endEditing:YES];
    CustomDatePickerView *pickerView = [[CustomDatePickerView alloc] initWithTarget:self];
    [pickerView showView];
}


- (void)datePickerView:(CustomDatePickerView *)pickerView didValueChanged:(NSString *)dateString{
    self.time.text = [TimeTransform timeSubstringYMD:dateString];
    [self routerEventWithName:EndEditTextAction dataInfo:@{@"section":@(_section),@"type":@(2),@"content":dateString}];
}

#pragma mark -- UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self endEditing:YES];
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    NSInteger type = 0;
    if (textField == self.number) {
        type = 1;
    }else if (textField == self.time) {
        type = 2;
    }else if (textField == self.serialNumber) {
        type = 3;
    }else if (textField == self.code) {
        type = 4;
    }
    [self routerEventWithName:EndEditTextAction dataInfo:@{@"section":@(_section),@"type":@(type),@"content":textField.text}];
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
