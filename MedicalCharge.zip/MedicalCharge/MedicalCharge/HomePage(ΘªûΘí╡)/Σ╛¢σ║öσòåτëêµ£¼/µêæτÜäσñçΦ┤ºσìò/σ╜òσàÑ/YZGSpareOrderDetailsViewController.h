//
//  YZGSpareOrderDetailsViewController.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/23.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BaseViewController.h"

@interface YZGSpareOrderDetailsViewController : BaseViewController
@property (strong, nonatomic) IBOutlet UIView *headerView;
@property (weak, nonatomic) IBOutlet UILabel *hospitalName;
@property (weak, nonatomic) IBOutlet UILabel *department;
@property (weak, nonatomic) IBOutlet UILabel *time;
@property (weak, nonatomic) IBOutlet UILabel *orderNo;
@property (weak, nonatomic) IBOutlet UILabel *orderState;
@property (weak, nonatomic) IBOutlet UILabel *price;

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIView *bottomView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomViewHeight;
@property (weak, nonatomic) IBOutlet UIButton *bottomButton;


@property (nonatomic, copy) NSString *orderId;//订单id
@property (nonatomic,assign) NSInteger fromView;//1 查看详情 2 录入
@end
