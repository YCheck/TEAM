//
//  YZGMyReadySingleViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/12.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGMyReadySingleViewController.h"
#import "OrderManagerTableViewCell.h"
#import "OrderDealTableViewCell.h"
#import "CoreObject+CheckIncomingRoot.h"
#import "YZGSpareOrderDetailsViewController.h"
#import "YZGQRCodeViewController.h"
#import "YCYMakingCardMoneyView.h"
@interface YZGMyReadySingleViewController ()<YZGSearchViewDelegate,YCYMakingCardMoneyViewDelegate>
@property (nonatomic,retain) NSMutableArray *dataSource;
@property (nonatomic, retain) NSIndexPath *indexPath;
@property (nonatomic, assign) NSInteger section;
@property (nonatomic,assign) NSInteger startIndex;
@property (nonatomic,assign) NSInteger type;//选择状态
@property (nonatomic,retain) NSString *cancelContent;//取消订单原因

@end

@implementation YZGMyReadySingleViewController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self uploadHeader];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"我的备货单";
    WeakSelf
    [self actionCustomRightBtnWithNrlImage:@"searchimg" htlImage:nil title:nil btnFrame:CGRectMake(0, 0, 44, 44) action:^{
        [weakSelf rightButtonAction];
    }];
    
    self.type = 1;
    self.searchViewHeight.constant = 0;
    self.searchView.hidden = YES;
    self.searchView.delegate = self;
    
    [self initTableView];
}

- (void)rightButtonAction{
    [self searchCheckincoming];
}

- (void)searchCheckincoming{
    if (self.searchViewHeight.constant == 0) {
        self.searchViewHeight.constant = 45;
        self.searchView.hidden = NO;
    }else{
        self.searchView.hidden = YES;
        self.searchViewHeight.constant = 0;
    }
}

#pragma mark -- YZGSearchViewDelegate
- (void)yzg_searchView:(YZGSearchView *)searchView searchContent:(NSString *)content andCollation:(NSInteger)sort{
    [self uploadHeader];
}

- (void)initTableView{
    _startIndex = 1;
    self.dataSource = [NSMutableArray array];
    
    
    self.tableView.backgroundColor = LightGrayColor;
    self.tableView.estimatedRowHeight = 120.0f;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    [self.tableView registerNib:[OrderManagerTableViewCell ycy_nib] forCellReuseIdentifier:[OrderManagerTableViewCell ycy_className]];
    [self.tableView registerNib:[OrderDealTableViewCell ycy_nib] forCellReuseIdentifier:[OrderDealTableViewCell ycy_className]];
    [self initWithTableViewRefreshAnimation];
}

#pragma mark -- UITableViewDelegate,UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.dataSource.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    CoreObject_CheckIncomingRoot *model = self.dataSource[section];
    if (model.isShow == NO) {
        return 0;
    }
    return model.detailsList.count + 1;//默认带一行订单处理cell
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CoreObject_CheckIncomingRoot *model = self.dataSource[indexPath.section];
    if (indexPath.row < model.detailsList.count) {
        OrderManagerTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[OrderManagerTableViewCell ycy_className] forIndexPath:indexPath];
        CoreObject_CheckIncoming *checkModel = model.detailsList[indexPath.row];
        [cell configureForCell:checkModel];
        return cell;
    }else{
        OrderDealTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[OrderDealTableViewCell ycy_className] forIndexPath:indexPath];
        [cell configureForCell:nil andSection:indexPath.section];
        cell.totalMoney.text = YCYAppendString(@"¥", model.totalAmount);
        if ([model.orderStage isEqualToString:@"待接单"] || [model.orderStage isEqualToString:@"处理中"]) {
            cell.cancelButton.hidden = NO;
            cell.enterButton.hidden = NO;
        }else{
            cell.cancelButton.hidden = YES;
            cell.enterButton.hidden = YES;
        }
        return cell;
    }
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    CoreObject_CheckIncomingRoot *model = self.dataSource[indexPath.section];
    if (indexPath.section == model.detailsList.count ) {
        return 62;
    }
    return 62;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 120;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 30;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    CoreObject_CheckIncomingRoot *model = self.dataSource[section];
    
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, YCYScreen_Width, 120)];
    headerView.backgroundColor = LightGrayColor;
    
    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 15, YCYScreen_Width, 105)];
    header.backgroundColor = [UIColor whiteColor];
    [headerView addSubview:header];
    
    UILabel *label = [[UILabel alloc] init];
    label.frame = CGRectMake(15, 12, YCYScreen_Width - 120, 18);
    label.font = YCYFont(16);
    label.textColor = TextCOLOR333;
    label.text = model.hospitalName;
    [header addSubview:label];
    
    UILabel *hospital = [[UILabel alloc] init];
    hospital.frame = CGRectMake(15, CGRectGetMaxY(label.frame) + 10, 68, 15);
    hospital.font = YCYFont(13);
    hospital.textColor = TextCOLOR333;
    hospital.text = @"备货科室：";
    [header addSubview:hospital];
    
    UILabel *subject = [[UILabel alloc] init];
    subject.frame = CGRectMake(CGRectGetMaxX(hospital.frame), CGRectGetMaxY(label.frame) + 8, 180, 15);
    subject.font = YCYFont(13);
    subject.textColor = TextCOLOR333;
    subject.text = model.departmentName;
    [header addSubview:subject];
    
    UILabel *numberTitle = [[UILabel alloc] init];
    numberTitle.frame = CGRectMake(15, CGRectGetMaxY(hospital.frame) + 8, 68, 15);
    numberTitle.font = YCYFont(13);
    numberTitle.textColor = TextCOLOR333;
    numberTitle.text = @"备货单号：";
    [header addSubview:numberTitle];
    
    UILabel *number = [[UILabel alloc] init];
    number.frame = CGRectMake(CGRectGetMaxX(numberTitle.frame) , CGRectGetMaxY(hospital.frame) + 8, 180, 15);
    number.font = YCYFont(13);
    number.textColor = TextCOLOR333;
    number.text = model.businessNumber;
    [header addSubview:number];
    
    UILabel *timeTitle = [[UILabel alloc] init];
    timeTitle.frame = CGRectMake(15, CGRectGetMaxY(numberTitle.frame) + 8, 40, 15);
    timeTitle.font = YCYFont(13);
    timeTitle.textColor = TextCOLOR333;
    timeTitle.text = @"时间：";
    [header addSubview:timeTitle];
    
    UILabel *time = [[UILabel alloc] init];
    time.frame = CGRectMake(CGRectGetMaxX(timeTitle.frame), CGRectGetMaxY(numberTitle.frame) + 8, 180, 15);
    time.font = YCYFont(13);
    time.textColor = TextCOLOR333;
    time.text = [TimeTransform timeSubstringYMD:model.orderTime];
    [header addSubview:time];
    
    UILabel *status = [[UILabel alloc] init];
    status.frame = CGRectMake(YCYScreen_Width - 105, 12, 90, 15);
    status.font = YCYFont(13);
    status.textColor = YCYHexColor(model.orderStageColor);
    status.textAlignment = NSTextAlignmentRight;
    status.text = model.orderStage;
    [header addSubview:status];
    
    UILabel *orderStatus = [[UILabel alloc] init];
    orderStatus.frame = CGRectMake(YCYScreen_Width - 100, CGRectGetMaxY(status.frame) + 8, 85, 15);
    orderStatus.font = YCYFont(13);
    orderStatus.textColor = RedCOLOR;
    orderStatus.textAlignment = NSTextAlignmentRight;
    orderStatus.text = @"";
    [header addSubview:orderStatus];
    
    UIButton *clickHeaderButton = [UIButton buttonWithType:UIButtonTypeCustom];
    clickHeaderButton.frame = header.bounds;
    clickHeaderButton.backgroundColor = [UIColor clearColor];
    clickHeaderButton.tag = section + 10000;
    [clickHeaderButton addTarget:self action:@selector(lookAtOrderDetail:) forControlEvents:UIControlEventTouchUpInside];
    [header addSubview:clickHeaderButton];
    
    UIButton *codeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    codeButton.frame = CGRectMake(YCYScreen_Width - 55, CGRectGetMaxY(orderStatus.frame) , 40, 35);
    codeButton.backgroundColor = [UIColor clearColor];
    [codeButton setTitle:@"" forState:UIControlStateNormal];
    [codeButton setTitleColor:WhiteColor forState:UIControlStateNormal];
    [codeButton setImage:YCYImage(@"查找") forState:UIControlStateNormal];
    codeButton.tag = section + 30000;
    [codeButton addTarget:self action:@selector(codeButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    codeButton.titleLabel.font = YCYFont(13);
    [header addSubview:codeButton];
    
    return headerView;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    
    CoreObject_CheckIncomingRoot *model = self.dataSource[section];
    
    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, YCYScreen_Width, 41)];
    header.backgroundColor = [UIColor clearColor];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(0, 0, YCYScreen_Width, 30);
    button.backgroundColor = [UIColor whiteColor];
    [button setTitle:@"" forState:UIControlStateNormal];
    if (model.isShow) {
        [button setImage:YCYImage(@"keepimg") forState:UIControlStateNormal];
    }else{
        [button setImage:YCYImage(@"spreadoutimg") forState:UIControlStateNormal];
    }
    button.tag = section + 20000;
    button.selected = NO;
    [button addTarget:self action:@selector(moreBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [header addSubview:button];
    
    return header;
    
}


- (void)codeButtonAction:(UIButton *)sender{
    NSInteger index = sender.tag - 30000;
    CoreObject_CheckIncomingRoot *model = self.dataSource[index];
    
    YZGQRCodeViewController *controller = [[YZGQRCodeViewController alloc] init];
    controller.qrStr = [NSString stringWithFormat:@"%@|%@",model.hospitalGuid,model.businessNumber];
    [self.navigationController pushViewController:controller animated:YES];
}

- (void)lookAtOrderDetail:(UIButton *)sender{
    NSInteger index = sender.tag - 10000;
    CoreObject_CheckIncomingRoot *model = self.dataSource[index];
    
    YZGSpareOrderDetailsViewController *controller = [[YZGSpareOrderDetailsViewController alloc] init];
    controller.orderId = model.gid;
    controller.fromView = 1;
    [self.navigationController pushViewController:controller animated:YES];
}

#pragma mark -- 点击查看更多
- (void)moreBtnAction:(UIButton *)sender{
    sender.selected = !sender.selected;
    
    CoreObject_CheckIncomingRoot *model = self.dataSource[sender.tag - 20000];
    if (model.isShow) {
        
    }else{
        for (CoreObject_CheckIncomingRoot *model in self.dataSource) {
            model.isShow = NO;
        }
    }
    model.isShow = !model.isShow;
    
    //    NSIndexSet *set = [NSIndexSet indexSetWithIndex:sender.tag];
    //    [self.tableView reloadSections:set withRowAnimation:UITableViewRowAnimationAutomatic];
    
    [self.tableView reloadData];
}

- (void)routerEventWithName:(NSString *)eventName dataInfo:(NSDictionary *)dataInfo{
    if ([CancelButtonAction isEqualToString:eventName]) {
        NSInteger section = [dataInfo[@"section"] integerValue];
        self.section = section;
        
        YCYMakingCardMoneyView *makingView = [[YCYMakingCardMoneyView alloc] initWithTarget:self andContent:@""];
        makingView.userInputEnable = YES;
        makingView.placeHolder = @"请填写";
        makingView.titleString = @"取消原因";
        makingView.sureButtonString = @"确定";
        [makingView showView];
        
    }else if ([EnterButtonAction isEqualToString:eventName]) {
        NSInteger section = [dataInfo[@"section"] integerValue];
        CoreObject_CheckIncomingRoot *model = self.dataSource[section];
        
        YZGSpareOrderDetailsViewController *controller = [[YZGSpareOrderDetailsViewController alloc] init];
        controller.orderId = model.gid;
        controller.fromView = 2;
        [self.navigationController pushViewController:controller animated:YES];
    }
}

#pragma mark -- YCYMakingCardMoneyViewDelegate
- (void)ycyMakingCardMoneyView:(NSString *)content andSelectedIndex:(NSInteger)index{
    self.cancelContent = content;
    [self cancelOrderRequest];
}

#pragma mark -- 顶部按钮切换 11 12 13
- (IBAction)topButtonAction:(id)sender {
    
    UIButton *button = (UIButton *)sender;
    self.lineView.center = CGPointMake(button.center.x, self.lineView.center.y);
    
    self.type = button.tag - 10;
    [self uploadHeader];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --------   网络请求------

- (void)getSpareOrderListRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:[CoreObject_CheckIncomingRoot class] andIsPersistence:NO andNumber:1];
}

- (void)cancelOrderRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:2];
}

- (void)uploadHeader{
    _startIndex = 1;
    [self getSpareOrderListRequest];
}

- (void)uploadFooter{
    _startIndex ++;
    [self getSpareOrderListRequest];
}

#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    if (manager.requestNumber == 1) {
        NSString *sort = @"desc";//默认降序
        if (self.searchView.timeButton.selected) {
            sort = @"asc";
        }
        
        NSString *value1 = @"0";NSString *value2 = @"";
        if (self.type == 2) {
            value1 = @"1";
        }else if (self.type == 3) {
            value1 = @"3";
        }
        value2 = self.searchView.textField.text;
        
        NSDictionary *param1 = @{@"Rules":@[@{@"Field":@"OrderStage",@"Value":value1,@"Operate":@"equal"},@{@"Field":@"businessNumber",@"Value":value2,@"Operate":@"contains"}],@"Operate":@"and"};
        return @{@"url":SpareOrderListAPI,@"params":@{@"pageIndex":@(_startIndex),@"pageSize":@(ListPageSize),@"sortField":@"Id",@"sortOrder":sort,@"filter_group":param1.ycy_JSONString}};
    }else if (manager.requestNumber == 2){
        
        CoreObject_CheckIncomingRoot *model = self.dataSource[self.section];
        return @{@"url":CancelSpareOrderAPI,@"params":@{@"guid":model.gid,@"remark":self.cancelContent}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([result isKindOfClass:[NSDictionary class]] && [manager.response.content[@"success"] integerValue] != 1) {
        if (manager.requestNumber == 1) {
            [self.dataSource removeAllObjects];
            [self.tableView reloadData];
        }
    }else{
        if (manager.requestNumber == 1){
            
            NSArray *array = manager.model;
            
            if (_startIndex == 1) {
                [_dataSource removeAllObjects];
            }
            if (array.count < ListPageSize) {
                self.tableView.mj_footer.state = MJRefreshStateNoMoreData;
            }else{
                [self.tableView.mj_footer endRefreshing];
            }
            
            [self.dataSource addObjectsFromArray:manager.model];
            [self.tableView reloadData];
            
            if (self.type == 1) {
                [self.allButton setTitle:[NSString stringWithFormat:@"全部(%@)",result[@"data"][@"total"]] forState:UIControlStateNormal];
            }
        }else if (manager.requestNumber == 2){
            [XHToast showBottomWithText:@"订单已申请取消~"];
            [self uploadHeader];
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
