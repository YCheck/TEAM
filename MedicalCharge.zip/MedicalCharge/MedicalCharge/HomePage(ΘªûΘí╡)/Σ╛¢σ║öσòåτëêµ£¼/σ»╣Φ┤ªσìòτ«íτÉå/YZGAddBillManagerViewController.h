//
//  YZGAddBillManagerViewController.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/13.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BaseViewController.h"

@interface YZGAddBillManagerViewController : BaseViewController

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end
