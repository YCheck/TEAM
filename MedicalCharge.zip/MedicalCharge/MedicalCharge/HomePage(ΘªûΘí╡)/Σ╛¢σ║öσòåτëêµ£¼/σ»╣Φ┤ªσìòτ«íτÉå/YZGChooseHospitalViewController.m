//
//  YZGChooseHospitalViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/13.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGChooseHospitalViewController.h"
#import "ChooseHospitalTableViewCell.h"
#import "CoreObject+Hospital.h"

@interface YZGChooseHospitalViewController ()

@property (nonatomic,retain) NSMutableArray *dataSource;
@property (nonatomic,retain) NSMutableArray *selectedSource;

@end

@implementation YZGChooseHospitalViewController

- (NSMutableArray *)selectedSource{
    if (!_selectedSource) {
        _selectedSource = [NSMutableArray array];
    }
    return _selectedSource;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"选择医院";
    WeakSelf
    [self actionCustomRightBtnWithNrlImage:nil htlImage:nil title:@"保存" btnFrame:CGRectMake(0, 0, 44, 44) action:^{
        [weakSelf rightButtonAction];
    }];
    
    [self initTableView];
    [self getHospitalListRequest];
}

- (void)rightButtonAction{
    if (_delegate && [_delegate respondsToSelector:@selector(chooseHospitals:)]) {
        [_delegate chooseHospitals:self.selectedSource];
    }
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)initTableView{
    
    self.dataSource = [NSMutableArray array];
    
    self.tableView.backgroundColor = LightGrayColor;
    self.tableView.estimatedRowHeight = 120.0f;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    [self.tableView registerNib:[ChooseHospitalTableViewCell ycy_nib] forCellReuseIdentifier:[ChooseHospitalTableViewCell ycy_className]];
    self.tableView.tableFooterView = [UIView new];
}

#pragma mark -- UITableViewDataSource,UITableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.dataSource.count == 0) {
        return 0;
    }
    return 1;
}

//显示多少组
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ChooseHospitalTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[ChooseHospitalTableViewCell ycy_className] forIndexPath:indexPath];
    CoreObject_Hospital *hospital = self.dataSource[indexPath.section];
    [cell configureForCell:hospital andIndexPath:indexPath];
    
    return cell;
}

//单行点击
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 10;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    return nil;
    
    //    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, YCYScreen_Width, 42)];
    //    header.backgroundColor = [UIColor whiteColor];
    //
    //    return header;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    
    return nil;
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    [self closeKeyBoard];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self closeKeyBoard];
    return YES;
}

- (void)routerEventWithName:(NSString *)eventName dataInfo:(NSDictionary *)dataInfo{
    if ([eventName isEqualToString:ChooseButtonAction]) {
        NSInteger section = [dataInfo[@"section"] integerValue];
        NSInteger row = [dataInfo[@"row"] integerValue];
        BOOL isSelected = [dataInfo[@"isSelected"] boolValue];
        
        CoreObject_Hospital *model = _dataSource[section];
        model.isSelected = isSelected;
        
        if (isSelected == YES) {
            [self.selectedSource addObject:model];
        }else{
            [self.selectedSource removeObject:model];
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --------   网络请求------

- (void)getHospitalListRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:[CoreObject_Hospital class] andIsPersistence:NO andNumber:1];
}
#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    if (manager.requestNumber == 1) {
        
        return @{@"url":MyHospitalListAPI,@"params":@{}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([result isKindOfClass:[NSDictionary class]] && [manager.response.content[@"success"] integerValue] != 1) {
        //        [XHToast showCenterWithText:result[@"msg"]];
    }else{
        if (manager.requestNumber == 1){
            [self.dataSource removeAllObjects];
            [self.dataSource addObjectsFromArray:manager.model];
            [self.tableView reloadData];
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
