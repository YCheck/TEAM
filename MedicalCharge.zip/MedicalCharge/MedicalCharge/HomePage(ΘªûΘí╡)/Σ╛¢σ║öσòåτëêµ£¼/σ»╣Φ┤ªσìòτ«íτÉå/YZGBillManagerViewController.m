//
//  YZGBillManagerViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/13.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGBillManagerViewController.h"
#import "BillManagerTableViewCell.h"
#import "RequestedBillTableViewCell.h"
#import "YZGAddBillManagerViewController.h"
#import "CoreObject+Bill.h"
@interface YZGBillManagerViewController ()

@property (nonatomic,retain) NSMutableArray *dataSource;
@property (nonatomic,assign) NSInteger startIndex;
@property (nonatomic,assign) NSInteger section;
@property (nonatomic,assign) NSInteger type;//1 对账单 2 已请求对账单

@end

@implementation YZGBillManagerViewController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self uploadHeader];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"对账单管理";
    
    WeakSelf
    [self actionCustomRightBtnWithNrlImage:@"add" htlImage:nil title:nil btnFrame:CGRectMake(0, 0, 44, 44) action:^{
        [weakSelf rightButtonAction];
    }];
    
    self.type = 1;
    [self initTableView];
}

- (void)rightButtonAction{
    YZGAddBillManagerViewController *controller = [[YZGAddBillManagerViewController alloc] init];
    [self.navigationController pushViewController:controller animated:YES];
}

- (void)initTableView{
    _startIndex = 1;
    self.dataSource = [NSMutableArray array];
    
    self.tableView.backgroundColor = LightGrayColor;
    self.tableView.estimatedRowHeight = 120.0f;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    [self.tableView registerNib:[BillManagerTableViewCell ycy_nib] forCellReuseIdentifier:[BillManagerTableViewCell ycy_className]];
    [self.tableView registerNib:[RequestedBillTableViewCell ycy_nib] forCellReuseIdentifier:[RequestedBillTableViewCell ycy_className]];
    [self initWithTableViewRefreshAnimation];
}

#pragma mark -- UITableViewDelegate,UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.dataSource.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.type == 1) {
        BillManagerTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[BillManagerTableViewCell ycy_className] forIndexPath:indexPath];
        [cell configureForCell:self.dataSource[indexPath.section] section:indexPath.section];
        return cell;
    }else{
        RequestedBillTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[RequestedBillTableViewCell ycy_className] forIndexPath:indexPath];
        [cell configureForCell:self.dataSource[indexPath.section] section:indexPath.section];
        return cell;
    }
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.type == 1) {
        return 148;
    }
    return 160;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 10;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    return nil;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    return nil;
}

- (void)routerEventWithName:(NSString *)eventName dataInfo:(NSDictionary *)dataInfo{
    if ([ConfirmButtonAction isEqualToString:eventName]) {
        NSInteger section = [dataInfo[@"section"] integerValue];
        self.section = section;
        [self confirmBillRequest];
    }
}

#pragma mark -- 顶部按钮切换
- (IBAction)topButtonAction:(id)sender {
    
    UIButton *button = (UIButton *)sender;
    self.lineView.center = CGPointMake(button.center.x, self.lineView.center.y);
    
    self.type = button.tag - 10;
    [self uploadHeader];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --------   网络请求------

- (void)getBillListRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:[CoreObject_Bill class] andIsPersistence:NO andNumber:1];
}

- (void)confirmBillRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:2];
}

- (void)uploadHeader{
    _startIndex = 1;
    [self getBillListRequest];
}

- (void)uploadFooter{
    _startIndex ++;
    [self getBillListRequest];
}

#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    if (manager.requestNumber == 1) {
        NSString *url = @"";
        if (self.type == 1) {
            url = BillRequestListAPI;
        }else if (self.type == 2){
            url = BillManagerListAPI;
        }
        return @{@"url":url,@"params":@{@"pageIndex":@(_startIndex),@"pageSize":@(ListPageSize)}};
    }else if (manager.requestNumber == 2){
            CoreObject_Bill *model = self.dataSource[self.section];
            return @{@"url":ConfirmBillAPI,@"params":@{@"guid":model.gid}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([result isKindOfClass:[NSDictionary class]] && [manager.response.content[@"success"] integerValue] != 1) {
        if (manager.requestNumber == 1) {
            [self.dataSource removeAllObjects];
            [self.tableView reloadData];
        }
    }else{
        if (manager.requestNumber == 1){
            
            NSArray *array = manager.model;
            
            if (_startIndex == 1) {
                [_dataSource removeAllObjects];
            }
            if (array.count < ListPageSize) {
                self.tableView.mj_footer.state = MJRefreshStateNoMoreData;
            }else{
                [self.tableView.mj_footer endRefreshing];
            }
            
            [self.dataSource addObjectsFromArray:manager.model];
            [self.tableView reloadData];
            
        }else if (manager.requestNumber == 2){
            [XHToast showCenterWithText:result[@"msg"]];
            [self uploadHeader];
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
