//
//  YZGAddBillManagerViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/13.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGAddBillManagerViewController.h"
#import "AddBillManagerTableViewCell.h"
#import "YZGChooseHospitalViewController.h"
#import "CoreObject+Hospital.h"
@interface YZGAddBillManagerViewController ()<ChooseHospitalDelegate,CustomDatePickerDelegate>

@property (nonatomic,retain) NSMutableArray *dataSource;
@property (nonatomic,retain) NSMutableArray *hospitalGuids;//选择医院的guid数组
@property (nonatomic,retain) NSString *startTime;//开始时间
@property (nonatomic,retain) NSString *endTime;//结束时间

@end

@implementation YZGAddBillManagerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"添加对账单";
    
    WeakSelf
    [self actionCustomRightBtnWithNrlImage:nil htlImage:nil title:@"保存" btnFrame:CGRectMake(0, 0, 44, 44) action:^{
        [weakSelf rightButtonAction];
    }];
    
    self.startTime = @"";
    self.endTime = @"";
    
    [self initTableView];
    [self getTimeRequest];
}

- (void)rightButtonAction{
    if (self.startTime.length == 0) {
        [XHToast showBottomWithText:@"请选择开始时间~"];
        return;
    }
    if (self.endTime.length == 0) {
        [XHToast showBottomWithText:@"请选择结束时间~"];
        return;
    }
    if (self.hospitalGuids.count == 0) {
        [XHToast showBottomWithText:@"请选择供货医院~"];
        return;
    }
    
    [self commitBillRequest];
}

- (void)initTableView{
    
    self.dataSource = [NSMutableArray array];
    [self.dataSource addObject:@"开始时间"];[self.dataSource addObject:@"结束时间"];[self.dataSource addObject:@"供货医院"];
    
    self.tableView.backgroundColor = LightGrayColor;
    self.tableView.estimatedRowHeight = 120.0f;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    [self.tableView registerNib:[AddBillManagerTableViewCell ycy_nib] forCellReuseIdentifier:[AddBillManagerTableViewCell ycy_className]];
    
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, YCYScreen_Width, 20)];
    headerView.backgroundColor = LightGrayColor;
    self.tableView.tableHeaderView = headerView;
}

#pragma mark -- UITableViewDelegate,UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    AddBillManagerTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[AddBillManagerTableViewCell ycy_className] forIndexPath:indexPath];
    cell.titleLabel.text = self.dataSource[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row == 0) {
        CustomDatePickerView *pickerView = [[CustomDatePickerView alloc] initWithTarget:self];
        pickerView.tag = 101;
        [pickerView showView];
    }else if (indexPath.row == 1){
        CustomDatePickerView *pickerView = [[CustomDatePickerView alloc] initWithTarget:self];
        pickerView.tag = 102;
        [pickerView showView];
    }else if (indexPath.row == 2) {
        YZGChooseHospitalViewController *controller = [[YZGChooseHospitalViewController alloc] init];
        controller.delegate = self;
        [self.navigationController pushViewController:controller animated:YES];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0.01;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    return nil;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    return nil;
}

- (void)datePickerView:(CustomDatePickerView *)pickerView didValueChanged:(NSString *)dateString{
    if (pickerView.tag == 101) {
        AddBillManagerTableViewCell *cell1 = [self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
        cell1.contentLabel.text = [TimeTransform timeSubstringYMD:dateString];
        self.startTime = dateString;
    }else if (pickerView.tag == 102) {
        AddBillManagerTableViewCell *cell2 = [self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:0]];
        cell2.contentLabel.text = [TimeTransform timeSubstringYMD:dateString];
        self.endTime = dateString;
    }
    
}

#pragma mark -- ChooseHospitalDelegate
- (void)chooseHospitals:(NSArray *)hospitalArray{
    self.hospitalGuids = [NSMutableArray array];
    
    NSMutableString *imageIds = [NSMutableString stringWithFormat:@""];
    for (int i = 0; i < hospitalArray.count; i ++) {
        CoreObject_Hospital *hospital = hospitalArray[i];
        [imageIds appendString:[NSString stringWithFormat:@"%@",hospital.name]];
        if (i < hospitalArray.count - 1) {
            [imageIds appendString:@","];
        }
        [self.hospitalGuids addObject:hospital.id];
    }
    AddBillManagerTableViewCell *cell3 = [self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:2 inSection:0]];
    cell3.contentLabel.text = imageIds;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --------   网络请求------

- (void)commitBillRequest{
    [CHNetworkingConfig shardInstance].requestType = 1;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:1];
}

- (void)getTimeRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:2];
}


#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    if (manager.requestNumber == 1) {
        
        return @{@"url":AddBillAPI,@"params":@{@"hospitalId":self.hospitalGuids,@"beginTime":self.startTime,@"endTime":self.endTime}};
    }else if (manager.requestNumber == 2) {
        
        return @{@"url":GetDefaultTimeAPI,@"params":@{}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([result isKindOfClass:[NSDictionary class]] && [manager.response.content[@"success"] integerValue] != 1) {
        if (manager.requestNumber == 1) {
            [XHToast showCenterWithText:result[@"msg"]];
        }
    }else{
        if (manager.requestNumber == 1){
            [XHToast showBottomWithText:@"添加成功~"];
            [self.navigationController popViewControllerAnimated:YES];
        }else if (manager.requestNumber == 2){
            AddBillManagerTableViewCell *cell1 = [self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
            cell1.contentLabel.text = [TimeTransform timeSubstringYMD:[TimeTransform timeSubstringYMD:result[@"data"]]];
            self.startTime = result[@"data"];
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
