//
//  ChooseHospitalTableViewCell.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/13.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CoreObject+Hospital.h"
static NSString *const ChooseButtonAction = @"ChooseButtonAction";
@interface ChooseHospitalTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIButton *chooseButton;

@property (nonatomic,retain) NSIndexPath *indexPath;
- (void)configureForCell:(CoreObject_Hospital *)model andIndexPath:(NSIndexPath *)indexPath;
@end
