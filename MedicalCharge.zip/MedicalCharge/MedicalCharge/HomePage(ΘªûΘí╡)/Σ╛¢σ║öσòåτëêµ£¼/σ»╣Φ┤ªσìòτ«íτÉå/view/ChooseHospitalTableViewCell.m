//
//  ChooseHospitalTableViewCell.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/13.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "ChooseHospitalTableViewCell.h"

@implementation ChooseHospitalTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)configureForCell:(CoreObject_Hospital *)model andIndexPath:(NSIndexPath *)indexPath{
    _indexPath = indexPath;
    
    self.titleLabel.text = model.name;
}

- (IBAction)chooseButtonAction:(id)sender {
    UIButton *button = (UIButton *)sender;
    button.selected = !button.selected;
    
    [self routerEventWithName:ChooseButtonAction dataInfo:@{@"section":@(_indexPath.section),@"row":@(_indexPath.row),@"isSelected":@(button.selected)}];
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
