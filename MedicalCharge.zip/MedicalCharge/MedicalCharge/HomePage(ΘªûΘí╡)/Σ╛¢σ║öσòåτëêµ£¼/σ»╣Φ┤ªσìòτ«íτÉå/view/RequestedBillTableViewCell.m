//
//  RequestedBillTableViewCell.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/23.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "RequestedBillTableViewCell.h"

@implementation RequestedBillTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.confirmButton.layer.borderWidth = 0.5;
    self.confirmButton.layer.borderColor = LineCOLOR.CGColor;
}

- (void)configureForCell:(CoreObject_Bill *)model section:(NSInteger)section{
    _section = section;
    
    self.hospitalName.text = model.hospitalName;
    self.createTime.text = [TimeTransform timeSubstringYMD:model.createTime];
    self.price1.text = model.actualAmount;
    self.price2.text = model.pretendAmount;
    self.price3.text = model.returnAmount;
    self.price4.text = model.reconciliationAmount;
    self.status.text = model.confirmStatus;
    if ([model.confirmStatus isEqualToString:@"已确认"]) {
        [self.confirmButton setTitleColor:TextCOLOR999 forState:UIControlStateNormal];
        self.confirmButton.enabled = NO;
    }else{
        [self.confirmButton setTitleColor:TextCOLOR333 forState:UIControlStateNormal];
        self.confirmButton.enabled = YES;
    }
}

- (IBAction)confirmButtonAction:(id)sender {
    [self routerEventWithName:ConfirmButtonAction dataInfo:@{@"section":@(_section)}];
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
