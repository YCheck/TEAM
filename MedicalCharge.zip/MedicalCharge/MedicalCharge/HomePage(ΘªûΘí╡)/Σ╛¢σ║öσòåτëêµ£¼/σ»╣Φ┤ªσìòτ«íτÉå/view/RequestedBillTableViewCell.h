//
//  RequestedBillTableViewCell.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/23.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CoreObject+Bill.h"

static NSString *const ConfirmButtonAction = @"ConfirmButtonAction";
@interface RequestedBillTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *hospitalName;
@property (weak, nonatomic) IBOutlet UILabel *price1;
@property (weak, nonatomic) IBOutlet UILabel *price2;
@property (weak, nonatomic) IBOutlet UILabel *price3;
@property (weak, nonatomic) IBOutlet UILabel *price4;

@property (weak, nonatomic) IBOutlet UILabel *createTime;
@property (weak, nonatomic) IBOutlet UILabel *status;
@property (weak, nonatomic) IBOutlet UIButton *confirmButton;


@property (nonatomic,assign) NSInteger section;
- (void)configureForCell:(CoreObject_Bill *)model section:(NSInteger)section;
@end
