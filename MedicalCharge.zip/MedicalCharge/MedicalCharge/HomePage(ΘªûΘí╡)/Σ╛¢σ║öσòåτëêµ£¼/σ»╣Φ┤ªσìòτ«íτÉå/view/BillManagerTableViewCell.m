//
//  BillManagerTableViewCell.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/13.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BillManagerTableViewCell.h"

@implementation BillManagerTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)configureForCell:(CoreObject_Bill *)model section:(NSInteger)section{
    _section = section;
    
    self.number.text = model.requestNumber;
    self.hospitalName.text = model.hospitalName;
    self.startTime.text = [TimeTransform timeSubstringYMD:model.reconciliationDate1];
    self.endTime.text = [TimeTransform timeSubstringYMD:model.reconciliationDate2];
    self.createTime.text = [TimeTransform timeSubstringYMD:model.createTime];
    self.status.text = model.handleStatus;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
