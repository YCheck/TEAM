//
//  BillManagerTableViewCell.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/13.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CoreObject+Bill.h"
@interface BillManagerTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *number;
@property (weak, nonatomic) IBOutlet UILabel *hospitalName;
@property (weak, nonatomic) IBOutlet UILabel *startTime;
@property (weak, nonatomic) IBOutlet UILabel *endTime;
@property (weak, nonatomic) IBOutlet UILabel *createTime;
@property (weak, nonatomic) IBOutlet UILabel *status;

@property (nonatomic,assign) NSInteger section;
- (void)configureForCell:(CoreObject_Bill *)model section:(NSInteger)section;

@end
