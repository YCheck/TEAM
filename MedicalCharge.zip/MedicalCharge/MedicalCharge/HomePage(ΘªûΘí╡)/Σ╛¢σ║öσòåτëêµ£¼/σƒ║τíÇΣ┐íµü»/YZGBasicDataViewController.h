//
//  YZGBasicDataViewController.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/12.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BaseViewController.h"

@interface YZGBasicDataViewController : BaseViewController


@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIView *lineView;

@property (weak, nonatomic) IBOutlet UIView *myBasicDataView;
@property (weak, nonatomic) IBOutlet UIView *hospitalBasicDataView;


@end
