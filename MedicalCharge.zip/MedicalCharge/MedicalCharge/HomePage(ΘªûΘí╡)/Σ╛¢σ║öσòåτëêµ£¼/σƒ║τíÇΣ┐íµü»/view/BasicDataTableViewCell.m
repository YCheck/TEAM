//
//  BasicDataTableViewCell.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/12.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BasicDataTableViewCell.h"

@implementation BasicDataTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)configureForCell:(CoreObject_BasicData *)model{
    self.name.text = model.name;
    self.specification.text = model.specification;
    self.model.text = model.model;
    self.product.text = model.manufacturerName;
    self.registerNumber.text = model.registrationNumber;
    self.price.text = model.price;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
}

@end
