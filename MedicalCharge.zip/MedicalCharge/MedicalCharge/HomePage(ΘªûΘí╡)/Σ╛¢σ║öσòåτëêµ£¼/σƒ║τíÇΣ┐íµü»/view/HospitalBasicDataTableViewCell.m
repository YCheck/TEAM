//
//  HospitalBasicDataTableViewCell.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/12.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "HospitalBasicDataTableViewCell.h"

@implementation HospitalBasicDataTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)configureForCell:(CoreObject_BasicData *)model{
    self.name.text = model.name;
    self.code.text = model.code;
    self.hospitalName.text = model.hospitalName;
    self.price.text = model.price;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
