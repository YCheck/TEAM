//
//  BasicDataTableViewCell.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/12.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CoreObject+BasicData.h"
@interface BasicDataTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *specification;
@property (weak, nonatomic) IBOutlet UILabel *model;
@property (weak, nonatomic) IBOutlet UILabel *price;
@property (weak, nonatomic) IBOutlet UILabel *product;
@property (weak, nonatomic) IBOutlet UILabel *registerNumber;

- (void)configureForCell:(CoreObject_BasicData *)model;

@end
