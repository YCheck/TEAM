//
//  YZGPushDataViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/22.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGPushDataViewController.h"
#import "CoreObject+PushDataRoot.h"
#import "PushDataTableViewCell.h"
#import "YZGChooseHospitalViewController.h"
#import "CoreObject+Hospital.h"
@interface YZGPushDataViewController ()<UITextFieldDelegate,ChooseHospitalDelegate>

@property (nonatomic,retain) NSMutableArray *dataSource;
@property (nonatomic,assign) NSInteger startIndex;
@property (nonatomic,retain) NSMutableArray *hospitalGuids;//选择医院的guid数组

@end

@implementation YZGPushDataViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"选择推送器材的品种";
    
    WeakSelf
    [self actionCustomRightBtnWithNrlImage:nil htlImage:nil title:@"保存" btnFrame:CGRectMake(0, 0, 44, 44) action:^{
        [weakSelf rightButtonAction];
    }];
    [self initTableView];
    [self getPushDataRequest];
}

- (void)rightButtonAction{
    if (self.hospitalGuids.count == 0) {
        [XHToast showBottomWithText:@"请选择要推送的医院~"];
        return;
    }
    [self commitPushDataRequest];
}

- (IBAction)chooseHospitalAction:(id)sender {
    YZGChooseHospitalViewController *controller = [[YZGChooseHospitalViewController alloc] init];
    controller.delegate = self;
    [self.navigationController pushViewController:controller animated:YES];
}

#pragma mark -- ChooseHospitalDelegate

- (void)chooseHospitals:(NSArray *)hospitalArray{
    self.hospitalGuids = [NSMutableArray array];
    
    NSMutableString *imageIds = [NSMutableString stringWithFormat:@""];
    for (int i = 0; i < hospitalArray.count; i ++) {
        CoreObject_Hospital *hospital = hospitalArray[i];
        [imageIds appendString:[NSString stringWithFormat:@"%@",hospital.name]];
        if (i < hospitalArray.count - 1) {
            [imageIds appendString:@","];
        }
        [self.hospitalGuids addObject:hospital.gid];
    }
    
    self.hospitalName.text = imageIds;
}

- (void)initTableView{
    _startIndex = 1;
    self.dataSource = [NSMutableArray array];
    
    self.tableView.backgroundColor = LightGrayColor;
    self.tableView.estimatedRowHeight = 120.0f;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    [self.tableView registerNib:[PushDataTableViewCell ycy_nib] forCellReuseIdentifier:[PushDataTableViewCell ycy_className]];
    [self initWithTableViewRefreshAnimation];
}

/**
 数据加载动画配置
 */
- (void)initWithTableViewRefreshAnimation{
    self.tableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(uploadFooter)];
}

#pragma mark -- UITableViewDelegate,UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.dataSource.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    CoreObject_PushDataRoot *model = self.dataSource[section];
    if (model.isShow == NO) {
        return 0;
    }
    return model.listMany.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    PushDataTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[PushDataTableViewCell ycy_className] forIndexPath:indexPath];
    
    CoreObject_PushDataRoot *model = self.dataSource[indexPath.section];
    CoreObject_PushData *dataModel = model.listMany[indexPath.row];
    [cell configureForCell:dataModel indexPath:indexPath];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 95;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 80;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 30;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    CoreObject_PushDataRoot *model = self.dataSource[section];
    
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, YCYScreen_Width, 80)];
    headerView.backgroundColor = LightGrayColor;
    
    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 15, YCYScreen_Width, 65)];
    header.backgroundColor = [UIColor whiteColor];
    [headerView addSubview:header];
    
    UILabel *label = [[UILabel alloc] init];
    label.frame = CGRectMake(15, 12, 70, 15);
    label.font = YCYFont(13);
    label.textColor = TextCOLOR333;
    label.text = @"器材名称";
    [header addSubview:label];
    
    
    UILabel *timeTitle = [[UILabel alloc] init];
    timeTitle.frame = CGRectMake(15, CGRectGetMaxY(label.frame) + 12, YCYScreen_Width - 85, 15);
    timeTitle.font = YCYFont(13);
    timeTitle.textColor = TextCOLOR333;
    timeTitle.text = model.name;
    [header addSubview:timeTitle];
    
    
    UILabel *orderStatus = [[UILabel alloc] init];
    orderStatus.frame = CGRectMake(YCYScreen_Width - 100, 12, 85, 15);
    orderStatus.font = YCYFont(13);
    orderStatus.textColor = TextCOLOR333;
    orderStatus.textAlignment = NSTextAlignmentRight;
    orderStatus.text = @"统一价格";
    [header addSubview:orderStatus];
    
    UITextField *price = [[UITextField alloc] init];
    price.frame = CGRectMake(YCYScreen_Width - 70, CGRectGetMaxY(orderStatus.frame) + 10, 55, 20);
    price.font = YCYFont(13);
    price.tag = 30000 + section;
    price.textColor = TextCOLOR333;
    price.delegate = self;
    price.layer.borderWidth = 0.5;
    price.layer.borderColor = YCYHexColor(@"dddddd").CGColor;
    price.text = model.price;
    [header addSubview:price];
    
    return headerView;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    
    CoreObject_PushDataRoot *model = self.dataSource[section];
    
    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, YCYScreen_Width, 41)];
    header.backgroundColor = [UIColor clearColor];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(0, 0, YCYScreen_Width, 30);
    button.backgroundColor = [UIColor whiteColor];
    [button setTitle:@"" forState:UIControlStateNormal];
    if (model.isShow) {
        [button setImage:YCYImage(@"keepimg") forState:UIControlStateNormal];
    }else{
        [button setImage:YCYImage(@"spreadoutimg") forState:UIControlStateNormal];
    }
    button.tag = section + 20000;
    button.selected = NO;
    [button addTarget:self action:@selector(moreBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [header addSubview:button];
    
    return header;
    
}


#pragma mark -- 点击查看更多
- (void)moreBtnAction:(UIButton *)sender{
    sender.selected = !sender.selected;
    
    CoreObject_PushDataRoot *model = self.dataSource[sender.tag - 20000];
    model.isShow = !model.isShow;
    
    [self.tableView reloadData];
}

#pragma mark -- UITextFieldDelegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if ([textField.text integerValue] == 0) {
        textField.text = @"";
    }
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self closeKeyBoard];
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    NSInteger index = textField.tag - 30000;
    if (textField.text.length == 0) {
        textField.text = @"0";
    }
    CoreObject_PushDataRoot *rootModel = self.dataSource[index];
    rootModel.price = textField.text;
    for (CoreObject_PushData *model in rootModel.listMany) {
        model.price = textField.text;
    }
    [self.tableView reloadData];
}

- (void)routerEventWithName:(NSString *)eventName dataInfo:(NSDictionary *)dataInfo{
        if ([EndEditTextAction isEqualToString:eventName]) {
            NSInteger section = [dataInfo[@"section"] integerValue];
            NSInteger row = [dataInfo[@"row"] integerValue];
            NSString *content = dataInfo[@"content"];
            
            CoreObject_PushDataRoot *rootModel = self.dataSource[section];
            CoreObject_PushData *model = rootModel.listMany[row];
            model.price = content;
        }
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --------   网络请求------

- (void)getPushDataRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:[CoreObject_PushDataRoot class] andIsPersistence:NO andNumber:1];
}

- (void)commitPushDataRequest{
    [CHNetworkingConfig shardInstance].requestType = 1;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:2];
}

- (void)uploadFooter{
    _startIndex ++;
    [self getPushDataRequest];
}

#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    if (manager.requestNumber == 1) {
        
        return @{@"url":PushBasicDataAPI,@"params":@{@"pageIndex":@(_startIndex),@"pageSize":@(ListPageSize)}};
    }else if (manager.requestNumber == 2){
        NSMutableArray *array = [NSMutableArray array];
        
        for (CoreObject_PushDataRoot *rootModel in self.dataSource) {
            NSMutableDictionary *dic = [NSMutableDictionary dictionary];
            [dic setValue:self.hospitalGuids forKey:@"hospitalGuid"];
            [dic setValue:rootModel.name forKey:@"name"];
            [dic setValue:rootModel.manufacturerName forKey:@"manufacturerName"];
            [dic setValue:rootModel.registrationNumber forKey:@"registrationNumber"];
            [dic setValue:rootModel.price forKey:@"price"];
            NSMutableArray *list = [NSMutableArray array];
            for (CoreObject_PushData *model in rootModel.listMany) {
                NSMutableDictionary *dict = [NSMutableDictionary dictionary];
                [dict setValue:model.id forKey:@"id"];
                [dict setValue:model.model forKey:@"model"];
                [dict setValue:model.specification forKey:@"specification"];
                [dict setValue:model.price forKey:@"price"];
                [list addObject:dict];
            }
            [dic setValue:list forKey:@"listMany"];
            [array addObject:dic];
        }
        
        return @{@"url":CommitPushBasicDataAPI,@"params":array};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([result isKindOfClass:[NSDictionary class]] && [manager.response.content[@"success"] integerValue] != 1) {
        [XHToast showCenterWithText:result[@"msg"] duration:3];
    }else{
        if (manager.requestNumber == 1){
            
            NSArray *array = manager.model;
            
            if (_startIndex == 1) {
                [_dataSource removeAllObjects];
            }
            if (array.count < ListPageSize) {
                self.tableView.mj_footer.state = MJRefreshStateNoMoreData;
            }else{
                [self.tableView.mj_footer endRefreshing];
            }
            
            [self.dataSource addObjectsFromArray:manager.model];
            [self.tableView reloadData];
        }else if (manager.requestNumber == 2){
            [XHToast showBottomWithText:result[@"msg"]];
            [self.navigationController popViewControllerAnimated:YES];
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
