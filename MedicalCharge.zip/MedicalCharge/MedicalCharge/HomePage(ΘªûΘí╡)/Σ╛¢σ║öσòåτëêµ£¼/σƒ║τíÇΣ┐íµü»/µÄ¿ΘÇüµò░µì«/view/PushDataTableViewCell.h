//
//  PushDataTableViewCell.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/22.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CoreObject+PushData.h"

static NSString *const EndEditTextAction = @"EndEditTextAction";
@interface PushDataTableViewCell : UITableViewCell<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UILabel *specification;
@property (weak, nonatomic) IBOutlet UILabel *model;
@property (weak, nonatomic) IBOutlet UITextField *price;

@property (nonatomic,retain) NSIndexPath *indexPath;
- (void)configureForCell:(CoreObject_PushData *)model indexPath:(NSIndexPath *)indexPath;

@end
