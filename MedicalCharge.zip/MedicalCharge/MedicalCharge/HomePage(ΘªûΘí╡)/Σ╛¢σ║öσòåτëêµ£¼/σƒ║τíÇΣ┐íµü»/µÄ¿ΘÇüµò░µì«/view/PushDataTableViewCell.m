//
//  PushDataTableViewCell.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/22.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "PushDataTableViewCell.h"

@implementation PushDataTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.price.delegate = self;
    self.price.layer.borderWidth = 0.5;
    self.price.layer.borderColor = YCYHexColor(@"dddddd").CGColor;
}

- (void)configureForCell:(CoreObject_PushData *)model indexPath:(NSIndexPath *)indexPath{
    _indexPath = indexPath;
    
    self.specification.text = model.specification;
    self.model.text = model.model;
    self.price.text = model.price;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

#pragma mark -- UITextFieldDelegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    if ([textField.text integerValue] == 0) {
        textField.text = @"";
    }
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self endEditing:YES];
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    [self routerEventWithName:EndEditTextAction dataInfo:@{@"section":@(_indexPath.section),@"row":@(_indexPath.row),@"content":textField.text}];
}

@end
