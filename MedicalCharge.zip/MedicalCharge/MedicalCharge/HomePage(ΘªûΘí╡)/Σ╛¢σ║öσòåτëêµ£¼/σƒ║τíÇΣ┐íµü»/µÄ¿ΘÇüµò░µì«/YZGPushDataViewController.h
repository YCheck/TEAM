//
//  YZGPushDataViewController.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/22.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BaseViewController.h"

@interface YZGPushDataViewController : BaseViewController

@property (weak, nonatomic) IBOutlet UILabel *hospitalName;

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end
