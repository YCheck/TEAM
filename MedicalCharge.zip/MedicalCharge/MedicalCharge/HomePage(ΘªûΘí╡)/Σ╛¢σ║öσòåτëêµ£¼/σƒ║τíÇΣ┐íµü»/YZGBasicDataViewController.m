//
//  YZGBasicDataViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/12.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGBasicDataViewController.h"
#import "BasicDataTableViewCell.h"
#import "HospitalBasicDataTableViewCell.h"
#import "CoreObject+BasicData.h"
#import "YZGPushDataViewController.h"
@interface YZGBasicDataViewController ()

@property (nonatomic,retain) NSMutableArray *dataSource;
@property (nonatomic,assign) NSInteger startIndex;
@property (nonatomic,assign) NSInteger type;//1 我的基本信息 2 医院信息

@end

@implementation YZGBasicDataViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"基础数据";
    
    self.type = 1;
    self.myBasicDataView.hidden = NO;
    self.hospitalBasicDataView.hidden = YES;
    
    [self initTableView];
    [self getBasicDataListRequest];
}

- (void)initTableView{
    
    _startIndex = 1;
    self.dataSource = [NSMutableArray array];
    
    self.tableView.backgroundColor = LightGrayColor;
    self.tableView.estimatedRowHeight = 120.0f;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    [self.tableView registerNib:[BasicDataTableViewCell ycy_nib] forCellReuseIdentifier:[BasicDataTableViewCell ycy_className]];
    [self.tableView registerNib:[HospitalBasicDataTableViewCell ycy_nib] forCellReuseIdentifier:[HospitalBasicDataTableViewCell ycy_className]];
    [self initWithTableViewRefreshAnimation];
}

#pragma mark -- UITableViewDelegate,UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.dataSource.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.type == 1) {
        BasicDataTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[BasicDataTableViewCell ycy_className] forIndexPath:indexPath];
        CoreObject_BasicData *model = self.dataSource[indexPath.section];
        [cell configureForCell:model];
        return cell;
    }else{
        HospitalBasicDataTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[HospitalBasicDataTableViewCell ycy_className] forIndexPath:indexPath];
        CoreObject_BasicData *model = self.dataSource[indexPath.section];
        [cell configureForCell:model];
        return cell;
    }
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 120;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 10;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    return nil;
}

- (nullable UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    return nil;
}

- (void)routerEventWithName:(NSString *)eventName dataInfo:(NSDictionary *)dataInfo{
    //    if ([ApplyMaintenanceAction isEqualToString:eventName]) {
    //        NSInteger section = [dataInfo[@"section"] integerValue];
    //        NSInteger row = [dataInfo[@"row"] integerValue];
    //
    //    }
}

#pragma mark -- 顶部按钮切换
- (IBAction)topButtonAction:(id)sender {
    
    UIButton *button = (UIButton *)sender;
    self.lineView.center = CGPointMake(button.center.x, self.lineView.center.y);
    
    self.type = button.tag - 10;
    
    [self.tableView reloadData];
    if (self.type == 1) {
        self.myBasicDataView.hidden = NO;
        self.hospitalBasicDataView.hidden = YES;
    }else{
        self.myBasicDataView.hidden = YES;
        self.hospitalBasicDataView.hidden = NO;
    }
    
    [self uploadHeader];
}

#pragma mark - 我的基础数据11 12 13
- (IBAction)myBasicDataAction:(id)sender {
    [XHToast showBottomWithText:@"请到管理后台操作~"];
}

#pragma mark - 医院基础数据 21 22
- (IBAction)hospitalBasicDataAction:(id)sender {
    UIButton *button = (UIButton *)sender;
    
    if (button.tag == 21) {
        YZGPushDataViewController *controller = [[YZGPushDataViewController alloc] init];
        [self.navigationController pushViewController:controller animated:YES];
    }else{
        [XHToast showBottomWithText:@"请到管理后台操作~"];
    }
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --------   网络请求------

- (void)getBasicDataListRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:[CoreObject_BasicData class] andIsPersistence:NO andNumber:1];
}

- (void)cancelOrderRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:2];
}

- (void)uploadHeader{
    _startIndex = 1;
    [self getBasicDataListRequest];
}

- (void)uploadFooter{
    _startIndex ++;
    [self getBasicDataListRequest];
}

#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    if (manager.requestNumber == 1) {
        NSString *url = @"";
        if (self.type == 1) {
            url = MyBasicMessageAPI;
        }else if (self.type == 2){
            url = HospitalBasicMessageAPI;
        }
        return @{@"url":url,@"params":@{@"pageIndex":@(_startIndex),@"pageSize":@(ListPageSize)}};
    }else if (manager.requestNumber == 2){
        
//        CoreObject_CheckIncomingRoot *model = self.dataSource[self.section];
//        return @{@"url":CancelOrderAPI,@"params":@{@"guid":model.gid}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([result isKindOfClass:[NSDictionary class]] && [manager.response.content[@"success"] integerValue] != 1) {
        if (manager.requestNumber == 1) {
            [self.dataSource removeAllObjects];
            [self.tableView reloadData];
        }
    }else{
        if (manager.requestNumber == 1){
            
            NSArray *array = manager.model;
            
            if (_startIndex == 1) {
                [_dataSource removeAllObjects];
            }
            if (array.count < ListPageSize) {
                self.tableView.mj_footer.state = MJRefreshStateNoMoreData;
            }else{
                [self.tableView.mj_footer endRefreshing];
            }
            
            [self.dataSource addObjectsFromArray:manager.model];
            [self.tableView reloadData];
            
        }else if (manager.requestNumber == 2){
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
