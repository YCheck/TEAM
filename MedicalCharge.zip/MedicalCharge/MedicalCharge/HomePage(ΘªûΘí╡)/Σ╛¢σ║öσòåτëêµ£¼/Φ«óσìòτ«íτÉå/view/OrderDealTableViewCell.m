//
//  OrderDealTableViewCell.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/11.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "OrderDealTableViewCell.h"

@implementation OrderDealTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.cancelButton.layer.borderWidth = 0.5;
    self.cancelButton.layer.borderColor = TextCOLOR666.CGColor;
}

- (void)configureForCell:(NSDictionary *)model andSection:(NSInteger)section{
    _section = section;
}

- (IBAction)cancelButtonAction:(id)sender {
    [self routerEventWithName:CancelButtonAction dataInfo:@{@"section":@(_section)}];
}

- (IBAction)enterButtonAction:(id)sender {
    [self routerEventWithName:EnterButtonAction dataInfo:@{@"section":@(_section)}];
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
