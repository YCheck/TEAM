//
//  OrderManagerTableViewCell.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/11.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CoreObject+CheckIncoming.h"
@interface OrderManagerTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *specification;
@property (weak, nonatomic) IBOutlet UILabel *count;
@property (weak, nonatomic) IBOutlet UILabel *price;
@property (weak, nonatomic) IBOutlet UILabel *number;
@property (weak, nonatomic) IBOutlet UILabel *time;



- (void)configureForCell:(CoreObject_CheckIncoming *)model;

@end
