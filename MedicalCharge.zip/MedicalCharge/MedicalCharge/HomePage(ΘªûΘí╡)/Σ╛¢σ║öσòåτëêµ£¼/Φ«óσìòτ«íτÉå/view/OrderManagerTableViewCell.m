//
//  OrderManagerTableViewCell.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/11.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "OrderManagerTableViewCell.h"

@implementation OrderManagerTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)configureForCell:(CoreObject_CheckIncoming *)model{
    self.name.text = model.name;
    self.specification.text = model.specification;
    self.count.text = [NSString stringWithFormat:@"%@/%@",model.quantity,model.unit];
    self.price.text = model.price;
    self.number.text = model.batchNumber;
    self.time.text = [TimeTransform timeSubstringYMD:model.valid];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
