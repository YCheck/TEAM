//
//  OrderDealTableViewCell.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/11.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
static NSString *const CancelButtonAction = @"CancelButtonAction";
static NSString *const EnterButtonAction = @"EnterButtonAction";
@interface OrderDealTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIButton *cancelButton;
@property (weak, nonatomic) IBOutlet UIButton *enterButton;
@property (weak, nonatomic) IBOutlet UILabel *totalMoney;

@property (nonatomic,assign) NSInteger section;
- (void)configureForCell:(NSDictionary *)model andSection:(NSInteger)section;

@end
