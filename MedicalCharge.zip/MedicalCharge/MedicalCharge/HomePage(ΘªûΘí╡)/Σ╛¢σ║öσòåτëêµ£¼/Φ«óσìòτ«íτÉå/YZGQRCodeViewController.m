//
//  YZGQRCodeViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/11.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGQRCodeViewController.h"
#import "ScanViewController.h"
@interface YZGQRCodeViewController ()

@end

@implementation YZGQRCodeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"二维码";
    
    UIImage *image = [ScanViewController createCodeWithString:self.qrStr size:CGSizeMake(240, 240) CodeFomart:kBarcodeFormatQRCode];
    self.qrCodeImageView.image = image;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
