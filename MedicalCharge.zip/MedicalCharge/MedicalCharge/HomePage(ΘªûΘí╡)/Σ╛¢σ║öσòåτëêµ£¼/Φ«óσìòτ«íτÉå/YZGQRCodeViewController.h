//
//  YZGQRCodeViewController.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/11.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BaseViewController.h"

@interface YZGQRCodeViewController : BaseViewController

@property (weak, nonatomic) IBOutlet UIImageView *qrCodeImageView;


@property (nonatomic,retain) NSString *qrStr;//生成二维码的字符串

@end
