//
//  YZGHomePageViewController.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/2/28.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BaseViewController.h"

@interface YZGHomePageViewController : BaseViewController

@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;

@end
