//
//  YZGHomePageViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/2/28.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGHomePageViewController.h"
#import "HomePageCollectionViewCell.h"
#import "HospitalHeaderView.h"
#import "SupplierHeaderView.h"
#import "YZGCheckIncomingViewController.h"
#import "ScanViewController.h"
#import "YZGMaintenanceManagerViewController.h"
#import "YZGRepairAcceptViewController.h"
#import "YZGDeviceDynamicViewController.h"

#import "YZGOrdermanagerViewController.h"
#import "YZGBasicDataViewController.h"
#import "YZGMyReadySingleViewController.h"
#import "YZGBillManagerViewController.h"
#import "YZGMessageDetailsViewController.h"
#import "CoreObject+Message.h"

#import "YZGOrdermanagerViewController.h"

@interface YZGHomePageViewController ()<UICollectionViewDelegate,UICollectionViewDataSource>

@property (nonatomic,retain) NSDictionary *result;
@property (nonatomic,retain) NSMutableArray *dataSource;

@end

@implementation YZGHomePageViewController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:animated];
    [self getHomePageDataRequest];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:animated];
}

- (NSDictionary *)result{
    if (!_result) {
        _result = [NSDictionary dictionary];
    }
    return _result;
}

- (NSMutableArray *)dataSource{
    if (!_dataSource) {
        if (ROLE == 1) {
            _dataSource = [NSMutableArray arrayWithArray:@[
                                                           @{@"img":@"instorehouse",@"title":@"验收入库",@"number":@"0"},
                                                           @{@"img":@"corefix",@"title":@"扫码报修",@"number":@"0"},
                                                           @{@"img":@"fixmanage",@"title":@"维修管理",@"number":@"0"},
                                                           @{@"img":@"fix",@"title":@"报修验收",@"number":@"0"},
                                                           @{@"img":@"fixstatic",@"title":@"维修统计",@"number":@"0"},
                                                           @{@"img":@"equipmentstue",@"title":@"设备动态",@"number":@"0"}]];
        }else if (ROLE == 2){
            _dataSource = [NSMutableArray arrayWithArray:@[
                                                       @{@"img":@"order",@"title":@"订单管理",@"number":@"0"},
                                                       @{@"img":@"basedata",@"title":@"基础数据",@"number":@"0"},
                                                       @{@"img":@"stockup",@"title":@"备货单",@"number":@"0"},
                                                       @{@"img":@"accountorder",@"title":@"对账单管理",@"number":@"0"},
                                                       @{@"img":@"fixorder",@"title":@"维修单",@"number":@"0"},
                                                       @{@"img":@"permit",@"title":@"证照管理",@"number":@"0"}]];
        }
    }
    
    return _dataSource;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self hideCustomBackButtonItem];
    
    
    [self initCollection];
}

- (void)initCollection{
    
    [self.collectionView registerNib:[HomePageCollectionViewCell ycy_loadNib]
           forCellWithReuseIdentifier:[HomePageCollectionViewCell ycy_className]];
    [self.collectionView registerNib:[HospitalHeaderView ycy_loadNib] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:[HospitalHeaderView ycy_className]];
     
    [self.collectionView registerNib:[SupplierHeaderView ycy_loadNib] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:[SupplierHeaderView ycy_className]];
    
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    if (ROLE == 1) {
        layout.headerReferenceSize = CGSizeMake(YCYScreen_Width, 305);  //设置headerView大小
    }else if (ROLE == 2){
        layout.headerReferenceSize = CGSizeMake(YCYScreen_Width, 270);  //设置headerView大小
    }
    
    layout.footerReferenceSize = CGSizeMake(0, 0);
    [self.collectionView setCollectionViewLayout:layout];
    
    _collectionView.showsVerticalScrollIndicator = NO;
    _collectionView.showsHorizontalScrollIndicator = NO;
    _collectionView.bounces = YES;
    _collectionView.alwaysBounceHorizontal = NO;
    _collectionView.alwaysBounceVertical = YES;
    _collectionView.backgroundColor = LightGrayColor;
    
//    [self initWithTableViewRefreshAnimation];
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.dataSource.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    HomePageCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:[HomePageCollectionViewCell ycy_className] forIndexPath:indexPath];
    [cell configureForCell:self.dataSource[indexPath.item]];
    return cell;
}


- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath{
    
    UICollectionReusableView *reusableView = nil;
    
    if (kind == UICollectionElementKindSectionHeader){
        if (ROLE == 1) {
            HospitalHeaderView *hispitalView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:[HospitalHeaderView ycy_className] forIndexPath:indexPath];
            if (_result) {
                [hispitalView configureForHeaderView:@{@"number1":self.result[@"unAcceptOrder"],@"number2":self.result[@"myRepair"],@"number3":self.result[@"myAudit"],@"messageContent":self.result[@"pushMessageTitle"]}];
            }
            reusableView = hispitalView;
        }else if (ROLE == 2){
            SupplierHeaderView *hispitalView = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:[SupplierHeaderView ycy_className] forIndexPath:indexPath];
            if (_result) {
                [hispitalView configureForHeaderView:@{@"number1":self.result[@"unHandleOrder"],@"number2":self.result[@"unHandleRepair"]}];
            }
            reusableView = hispitalView;
        }
    }
    
    return reusableView;
}

#pragma mark - UICollectionViewDelegateFlowLayout

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    if (ROLE == 1) {
        if (indexPath.item == 0) {
            YZGCheckIncomingViewController *controller = [[YZGCheckIncomingViewController alloc] init];
            [self.navigationController pushViewController:controller animated:YES];
        }else if (indexPath.item == 1){
            ScanViewController *controller = [[ScanViewController alloc] init];
            controller.fromView = 2;
            [self.navigationController pushViewController:controller animated:YES];
        }else if (indexPath.item == 2){
            YZGMaintenanceManagerViewController *controller = [[YZGMaintenanceManagerViewController alloc] init];
            [self.navigationController pushViewController:controller animated:YES];
        }else if (indexPath.item == 3){
            YZGRepairAcceptViewController *controller = [[YZGRepairAcceptViewController alloc] init];
            [self.navigationController pushViewController:controller animated:YES];
        }else if (indexPath.item == 4){
            [XHToast showBottomWithText:@"程序猿哥哥正在努力开发中~"];
        }else if (indexPath.item == 5){
            YZGDeviceDynamicViewController *controller = [[YZGDeviceDynamicViewController alloc] init];
            [self.navigationController pushViewController:controller animated:YES];
        }
    }else if(ROLE == 2){
        if (indexPath.item == 0) {
            YZGOrdermanagerViewController *controller = [[YZGOrdermanagerViewController alloc] init];
            [self.navigationController pushViewController:controller animated:YES];
        }else if (indexPath.item == 1) {
            YZGBasicDataViewController *controller = [[YZGBasicDataViewController alloc] init];
            [self.navigationController pushViewController:controller animated:YES];
        }else if (indexPath.item == 2) {
            YZGMyReadySingleViewController *controller = [[YZGMyReadySingleViewController alloc] init];
            [self.navigationController pushViewController:controller animated:YES];
        }else if (indexPath.item == 3) {
            YZGBillManagerViewController *controller = [[YZGBillManagerViewController alloc] init];
            [self.navigationController pushViewController:controller animated:YES];
        }else if (indexPath.item == 4){
            YZGMaintenanceManagerViewController *controller = [[YZGMaintenanceManagerViewController alloc] init];
            [self.navigationController pushViewController:controller animated:YES];
        }else if (indexPath.item == 5){
            [XHToast showBottomWithText:@"程序猿哥哥正在努力开发中~"];
        }
    }
}

- (void)collectionView:(UICollectionView *)collectionView didDeselectItemAtIndexPath:(NSIndexPath *)indexPath{
    
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    CGSize cellSize = (CGSize){AUTOSIZE_375(100), AUTOSIZE_375(100)};
    return cellSize;
}

//每行之间的距离
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section {
    return 19;
}

//每个item之间的间距
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    
    return 0.0;
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    return UIEdgeInsetsMake(19.f, 19.f, 0.f, 19.f);//每个section之间的  分别 上左下右
}

- (void)routerEventWithName:(NSString *)eventName dataInfo:(NSDictionary *)dataInfo{
    if ([eventName isEqualToString:ChooseButtonAction]) {
        NSInteger index = [dataInfo[@"index"] integerValue];
        if (ROLE == 1) {
            if (index == 1) {
                YZGCheckIncomingViewController *controller = [[YZGCheckIncomingViewController alloc] init];
                [self.navigationController pushViewController:controller animated:YES];
            }else if (index == 2){
                YZGMaintenanceManagerViewController *controller = [[YZGMaintenanceManagerViewController alloc] init];
                [self.navigationController pushViewController:controller animated:YES];
            }else if (index == 10000){
                [XHToast showBottomWithText:@"程序猿哥哥正在努力开发中~"];
//                ScanViewController *controller = [[ScanViewController alloc] init];
//                [self.navigationController pushViewController:controller animated:YES];
            }
        }
    }else if ([eventName isEqualToString:ChooseButtonsAction]) {//供应商端
        NSInteger index = [dataInfo[@"index"] integerValue];
        if (index == 1) {
            YZGOrdermanagerViewController *controller = [[YZGOrdermanagerViewController alloc] init];
            [self.navigationController pushViewController:controller animated:YES];
        }else if (index == 2){
            YZGMaintenanceManagerViewController *controller = [[YZGMaintenanceManagerViewController alloc] init];
            [self.navigationController pushViewController:controller animated:YES];
        }
    }else if ([eventName isEqualToString:ClickNoticeAction]){//医院端 点通知
        CoreObject_Message *message = [[CoreObject_Message alloc] init];
        message.jumpType = [NSString stringWithFormat:@"%@",self.result[@"pushMessageType"]];
        message.msgUrl = self.result[@"pushMessageUrl"];
        message.messageContent = self.result[@"pushMessageTitle"];
        YZGMessageDetailsViewController *controller = [[YZGMessageDetailsViewController alloc] init];
        controller.messageModel = message;
        [self.navigationController pushViewController:controller animated:YES];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --------   网络请求------

- (void)getHomePageDataRequest{
    [CHNetworkingConfig shardInstance].requestType = 1;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypeGet andClass:nil andIsPersistence:NO andNumber:1];
}

#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    if (manager.requestNumber == 1) {
        return @{@"url":GetHomePageAPI,@"params":@{}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([result isKindOfClass:[NSDictionary class]] && [manager.response.content[@"success"] integerValue] != 1) {
        [XHToast showCenterWithText:result[@"msg"]];
    }else{
        if (manager.requestNumber == 1){
            self.result = result[@"data"];
            NSArray *array = [NSArray arrayWithArray:result[@"data"][@"appModules"]];
            for (NSDictionary *dic in array) {
                for (NSDictionary *dict in self.dataSource) {
                    NSMutableDictionary *mutable = [NSMutableDictionary dictionaryWithDictionary:dict];
                    if ([dict[@"title"] isEqualToString:dic[@"name"]]) {
                        mutable[@"number"] = dic[@"quantity"];
                        [self.dataSource replaceObjectAtIndex:[self.dataSource indexOfObject:dict] withObject:mutable];
                        break;
                    }
                }
            }
            
            [self.collectionView reloadData];
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
