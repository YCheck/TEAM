//
//  Macro.h
//  SocialApp
//
//  Created by yangchengyou on 17/2/22.
//  Copyright © 2017年 NULLS. All rights reserved.
//

#ifndef Macro_h
#define Macro_h
//头像占位图
#define HeaderDefaultImage YCYImage(DefaultImageName)
#define DefaultImageName @"uimg"
#define ListPageSize 10
//占位图
#define DefaultImage YCYImage(@"d1_img1")

//系统名称替换
#define InteractiveMessage @"interactive_message"
#define PaySuccessMessage @"paysuccess_message"
#define SystemMessage @"system_message"
//颜色
#define WhiteColor [UIColor whiteColor]
#define NavigationTextColor [UIColor whiteColor]
#define TabbarColor [UIColor whiteColor]
#define BackGroundColor [UIColor ycy_colorWithHexString:@"ffffff"]
#define NavigationCOLOR [UIColor ycy_colorWithHexString:@"ffffff"]
#define MainCOLOR [UIColor ycy_colorWithHexString:@"2ea1fb"]
#define GreenCOLOR [UIColor ycy_colorWithHexString:@"1de9b6"]
#define RedCOLOR [UIColor ycy_colorWithHexString:@"f50057"]
#define LineCOLOR [UIColor ycy_colorWithHexString:@"eeeeee"]
#define LightGrayColor [UIColor ycy_colorWithHexString:@"f7f7f7"]
#define TextCOLORBC [UIColor ycy_colorWithHexString:@"bcbcbc"]
#define TextCOLOR333 [UIColor ycy_colorWithHexString:@"333333"]
#define TextCOLOR666 [UIColor ycy_colorWithHexString:@"666666"]
#define TextCOLOR999 [UIColor ycy_colorWithHexString:@"999999"]

#define ButtonBackColorYellow [UIColor ycy_colorWithHexString:@"edaf50"]
#define ButtonBackColorGray [UIColor ycy_colorWithHexString:@"e8eaeb"]
//字体
#define YCYPFSCMedium(fontsize) [UIFont fontWithName:@"PingFangSC-Medium" size:fontsize]

#define AUTOSIZE_375(height) (YCYScreen_Width/375)*height
//转换
#define StringTransfer(entity) [NSString stringWithFormat:@"%@",entity]


//系统定位信息
#define Longitude [NSString stringWithFormat:@"%@",[NSNumber numberWithDouble:[LocationManager sharedInstance].currentLocation.coordinate.longitude]]
#define Latitude [NSString stringWithFormat:@"%@",[NSNumber numberWithDouble:[LocationManager sharedInstance].currentLocation.coordinate.latitude]]
//ex:@"x,y"
#define Coordinate [NSString stringWithFormat:@"%@,%@",[NSNumber numberWithDouble:[LocationManager sharedInstance].currentLocation.coordinate.longitude], [NSNumber numberWithDouble:[LocationManager sharedInstance].currentLocation.coordinate.latitude]]

//百度地图定位
#define BaiduLatitude [NSString stringWithFormat:@"%.6lf",[BaiDuLocation sharedInstance].currentLocation.coordinate.latitude]
#define BaiduLongitude [NSString stringWithFormat:@"%.6lf",[BaiDuLocation sharedInstance].currentLocation.coordinate.longitude]

#endif /* Macro_h */
