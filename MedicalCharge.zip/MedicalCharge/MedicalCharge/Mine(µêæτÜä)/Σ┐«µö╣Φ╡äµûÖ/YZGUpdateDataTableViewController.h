//
//  YZGUpdateDataTableViewController.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/4.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BaseTableViewController.h"

@interface YZGUpdateDataTableViewController : BaseTableViewController

@property (weak, nonatomic) IBOutlet UITextField *loginName;
@property (weak, nonatomic) IBOutlet UITextField *realName;
@property (weak, nonatomic) IBOutlet UITextField *email;
@property (weak, nonatomic) IBOutlet UITextField *phoneText;
@property (weak, nonatomic) IBOutlet UITextField *oldPhone;
@property (weak, nonatomic) IBOutlet UITextField *newsPhone;
@property (weak, nonatomic) IBOutlet UITextField *code;
@property (weak, nonatomic) IBOutlet UIButton *codeButton;



@end
