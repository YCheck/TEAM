//
//  YZGUpdateDataTableViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/4.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGUpdateDataTableViewController.h"

@interface YZGUpdateDataTableViewController ()<UITextFieldDelegate>

@property (nonatomic,assign) NSInteger rows;

@end

@implementation YZGUpdateDataTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"基本信息修改";
    self.rows = 4;
    WeakSelf
    [self actionCustomRightBtnWithNrlImage:nil htlImage:nil title:@"保存" btnFrame:CGRectMake(0, 0, 70, 44) action:^{
        [weakSelf rightButtonAction];
    }];
    
    [self initWithUserInterface];
}

- (void)initWithUserInterface{
    self.loginName.text = LoginName;
    self.realName.text = RealName;
    self.email.text = Email;
    self.phoneText.text = Phone;
//    if (self.realName.text.length > 0) {
//        self.realName.userInteractionEnabled = NO;
//    }
//    if (self.email.text.length > 0) {
//        self.email.userInteractionEnabled = NO;
//    }
    
}

- (void)rightButtonAction{
    [self udapteDataRequest];
}

- (IBAction)updatePhoneAction:(id)sender {
    if (self.rows == 4) {
        self.rows = 7;
    }else{
        self.rows = 4;
    }
    [self.tableView reloadData];
}

- (IBAction)getCodeButtonAction:(id)sender {
    if (self.newsPhone.text.length == 0) {
        [XHToast showBottomWithText:@"请输入新手机号~"];
        return;
    }else if (self.newsPhone.text.length != 11){
        [XHToast showBottomWithText:@"请输入正确手机号~"];
        return;
    }
    
    self.codeButton.userInteractionEnabled = NO;
    [_codeButton ycy_startTime:59 title:@"重新获取" waitTittle:@"秒后重发"];
    [self performSelector:@selector(resetCodeBtnStatus) withObject:nil afterDelay:59];
    [self getCodeRequest];
}

#pragma mark -- 重置验证码按钮
- (void)resetCodeBtnStatus{
    self.codeButton.userInteractionEnabled = YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self closeKeyBoard];
    return YES;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.rows;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --------   网络请求------

- (void)udapteDataRequest{
    [CHNetworkingConfig shardInstance].requestType = 1;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:1];
}

- (void)getCodeRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:2];
}

#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    
    if (manager.requestNumber == 1) {
        NSDictionary *param = @{@"uid":UserID,@"realName":self.realName.text,@"phone":self.oldPhone.text,@"mobilePhone":self.newsPhone.text,@"email":self.email.text,@"verificationCode":self.code.text};
        return @{@"url":UpdateUserInfoAPI,@"params":param};
    }else if (manager.requestNumber == 2){
        return @{@"url":GetCodeAPI,@"params":@{@"ActionType":@"更换手机",@"MobilePhone":self.newsPhone.text}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([manager.response.content[@"success"] integerValue] != 1) {
        [XHToast showCenterWithText:result[@"msg"]];
    }else{
        if (manager.requestNumber == 1){
            [XHToast showCenterWithText:result[@"msg"]];
            if (self.newsPhone.text.length > 0) {
                PUTNSUserDefault(@"phone", self.newsPhone.text);
            }
            PUTNSUserDefault(@"realName", self.realName.text);
            PUTNSUserDefault(@"email", self.email.text);
            [self.navigationController popViewControllerAnimated:YES];
        }else if(manager.requestNumber == 2){
            
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}

/*
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:<#@"reuseIdentifier"#> forIndexPath:indexPath];
    
    // Configure the cell...
    
    return cell;
}
*/

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
