//
//  YZGUpdatePasswordTableViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/4.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGUpdatePasswordTableViewController.h"

@interface YZGUpdatePasswordTableViewController ()<UITextFieldDelegate>

@end

@implementation YZGUpdatePasswordTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"修改密码";
    
    WeakSelf
    [self actionCustomRightBtnWithNrlImage:nil htlImage:nil title:@"保存" btnFrame:CGRectMake(0, 0, 70, 44) action:^{
        [weakSelf rightButtonAction];
    }];
}

- (IBAction)eyesButton1Action:(id)sender {
    UIButton *button = (UIButton *)sender;
    button.selected = !button.selected;
    self.oldPassword.secureTextEntry = !button.selected;
}

- (IBAction)eyesButton2Action:(id)sender {
    UIButton *button = (UIButton *)sender;
    button.selected = !button.selected;
    self.newsPassword.secureTextEntry = !button.selected;
}

- (IBAction)eyesButton3Action:(id)sender {
    UIButton *button = (UIButton *)sender;
    button.selected = !button.selected;
    self.passwordAgain.secureTextEntry = !button.selected;
}

- (void)rightButtonAction{
    if (self.oldPassword.text.length == 0) {
        [XHToast showBottomWithText:@"请输入原密码~"];
        return;
    }
    if (self.newsPassword.text.length < 6 || self.newsPassword.text.length > 16) {
        [XHToast showBottomWithText:@"请输入6-16位密码~"];
        return;
    }
    if (![self.newsPassword.text isEqualToString:self.passwordAgain.text]) {
        [XHToast showBottomWithText:@"两次输入密码不一致~"];
        return;
    }
    [self updatePasswordRequest];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self closeKeyBoard];
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --------   网络请求------

- (void)updatePasswordRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:1];
}
#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    if (manager.requestNumber == 1) {//登录
        return @{@"url":UpdatePWDAPI,@"params":@{@"OriginalPwd":self.oldPassword.text,@"NewPwd":self.newsPassword.text,@"NewPwd1":self.passwordAgain.text}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([manager.response.content[@"success"] integerValue] != 1) {
        [XHToast showCenterWithText:result[@"msg"]];
    }else{
        if (manager.requestNumber == 1){
            [XHToast showCenterWithText:result[@"msg"]];
            [self.navigationController popViewControllerAnimated:YES];
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}
/*
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:<#@"reuseIdentifier"#> forIndexPath:indexPath];
    
    // Configure the cell...
    
    return cell;
}
*/

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
