//
//  YZGUpdatePasswordTableViewController.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/4.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BaseTableViewController.h"

@interface YZGUpdatePasswordTableViewController : BaseTableViewController

@property (weak, nonatomic) IBOutlet UITextField *oldPassword;
@property (weak, nonatomic) IBOutlet UITextField *newsPassword;
@property (weak, nonatomic) IBOutlet UITextField *passwordAgain;


@end
