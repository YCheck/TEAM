//
//  YZGMineViewController.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/2/28.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BaseViewController.h"
#import "BaseTableViewController.h"
@interface YZGMineViewController : BaseTableViewController

@property (weak, nonatomic) IBOutlet UIImageView *headerImageView;
@property (weak, nonatomic) IBOutlet UIButton *logoutButton;


@end
