//
//  YZGMineViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/2/28.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGMineViewController.h"
#import "MyActionSheet.h"
#import "YZGMyHospitalViewController.h"
#import "AppDelegate.h"

@interface YZGMineViewController ()

@property (nonatomic,retain) NSString *headerPath;
@property (nonatomic,retain) UIImage *hImage;
@property (nonatomic,retain) UIImage *localImage;

@end

@implementation YZGMineViewController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    NSLog(@"---%@",YCYURL(HeaderPath));
    [self.headerImageView py_setImageWithURL:YCYURL(HeaderPath) placeholderImage:HeaderDefaultImage];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self hideCustomBackButtonItem];
    self.navigationItem.title = @"账号信息管理";
    self.logoutButton.layer.borderWidth = 0.5;
    self.logoutButton.layer.borderColor = TextCOLOR666.CGColor;
    
    
}

- (IBAction)logoutButtonAction:(id)sender {
    REMOVENSUserDefault(@"logintoken");
    [(AppDelegate *)[[UIApplication sharedApplication] delegate] setLogin];
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (ROLE == 1) {
        return 1;
    }else if (ROLE == 2){
        return 2;
    }
    return 1;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            WeakSelf
            MyActionSheet *actionSheet = [[MyActionSheet alloc] init];
            [self.view addSubview:actionSheet];
            [actionSheet actionShow];
            actionSheet.choosePhoto = ^(NSDictionary *info) {
                UIImage *image = info[UIImagePickerControllerEditedImage] == nil?info [UIImagePickerControllerOriginalImage]:info[UIImagePickerControllerEditedImage];
                weakSelf.headerImageView.image = image;
                weakSelf.localImage = image;
                [weakSelf uploadImageRequest];
            };
        }
    }else if (indexPath.section == 1){
        YZGMyHospitalViewController *controller = [[YZGMyHospitalViewController alloc] init];
        [self.navigationController pushViewController:controller animated:YES];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --------   网络请求------
- (void)uploadImageRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:1];
}

#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    
    if (manager.requestNumber == 1){
        UIImage *image = self.localImage;
        NSData *data = UIImageJPEGRepresentation(image,0.8);
        NSString *imgBase64 = [data ycy_base64EncodedString];
        return @{@"url":UploadImageAPI,@"params":@{@"uploadType":@"头像上传",@"base64String":imgBase64}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([manager.response.content[@"success"] integerValue] != 1) {
        [XHToast showCenterWithText:result[@"msg"]];
    }else{
       if(manager.requestNumber == 1){
           if ([result[@"data"] count] > 0) {
               NSString *imagePath = result[@"data"][0][@"fileUrl"];
               PUTNSUserDefault(@"headPath", imagePath);
           }else{
               
           }
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
