//
//  YZGMyHospitalViewController.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/4.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BaseViewController.h"

@interface YZGMyHospitalViewController : BaseViewController

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end
