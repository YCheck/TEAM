//
//  MyHospitalTableViewCell.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/4.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "MyHospitalTableViewCell.h"

@implementation MyHospitalTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)configureForCell:(CoreObject_Hospital *)model{
    self.hospitalName.text = model.name;
    self.address.text = model.hospitalAddress;
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
