//
//  CLLocation+Sino.h
//
//  Created by i0xbean@gmail.com on 13-4-26.
//  火星坐标系转换扩展
//
//  earth（国外 WGS84）（地球坐标系）, mars（国内 GCJ-02）（火星坐标系）, bearPaw（百度 BD-09）（百度坐标系） 坐标系间相互转换
//  未包含 mars2earth. 需要这个可参考 http://xcodev.com/131.html

#import <CoreLocation/CoreLocation.h>

@interface CLLocation (Sino)


//这里是不同的地图座标系之间的转换
- (CLLocation*)locationMarsFromEarth;//地球坐标转火星坐标
//- (CLLocation*)locationEarthFromMars; // 未实现

- (CLLocation*)locationBearPawFromMars;//火星坐标转百度
- (CLLocation*)locationMarsFromBearPaw;//百度坐标转火星坐标

@end
