//
//  LocationManager.m
//  GZMCoupon
//
//  Created by Alsor Zhou on 13-5-25.
//  Copyright (c) 2013年 GZMobile. All rights reserved.
//

#import "LocationManager.h"


@implementation LocationManager

@synthesize currentLocation;

+ (LocationManager *)sharedInstance{
    static dispatch_once_t pred;
    __strong static LocationManager *sharedInternal = nil;
    
    dispatch_once(&pred, ^{
        sharedInternal = [[LocationManager alloc] init];
    });
    
	return sharedInternal;
}


- (id)init
{
    self = [super init];
    if (self) {
        locationManager = [[CLLocationManager alloc] init];
    }
    return self;
}

- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    
    if (IsEmpty(locations)) {
        return;
    }
    
    CLLocation *location = locations[0];
    NSString *subtitle = [NSString stringWithFormat:@"%@,%@", [NSNumber numberWithDouble:location.coordinate.latitude], [NSNumber numberWithDouble:location.coordinate.longitude]];
    NSLog(@"location = %@",subtitle);
    // save user locationr
    currentLocation = [location locationMarsFromEarth];
     NSLog(@"BAIDU Location : %@", [NSString stringWithFormat:@"%lf, %lf", currentLocation.coordinate.latitude, currentLocation.coordinate.longitude]);
    CLGeocoder *geoCoder = [[CLGeocoder alloc] init];
    
    [geoCoder reverseGeocodeLocation:location completionHandler:^(NSArray *placemarks, NSError *error) {
        // for (CLPlacemark * placemark in placemarks) {};
        // directly use the first matched city
        if ([placemarks count] > 0) {
            CLPlacemark *placemark = placemarks[0];
            NSMutableString *place = [[NSMutableString alloc] init];
            if (placemark.administrativeArea) {
                [place appendString:placemark.administrativeArea];
                
            }
            if (placemark.locality) {
              [place appendString:placemark.locality];
            }
            if (placemark.subLocality) {
                [place appendString:placemark.subLocality];
            }
            if (placemark.thoroughfare) {
                [place appendString:placemark.thoroughfare];
            }
            if (placemark.subThoroughfare) {
                [place appendString:placemark.subThoroughfare];
            }
            
            NSLog(@"province = %@ city = %@ area = %@",emptyTransform(placemark.addressDictionary[@"State"]),emptyTransform(placemark.locality),emptyTransform(placemark.subLocality));
//            [[NSUserDefaults standardUserDefaults] setObject:nullEmptyTransform(placemark.locality) forKey:@"city"];
//            [[NSUserDefaults standardUserDefaults] setObject:nullEmptyTransform(placemark.locality) forKey:@"ex_city"];
//            [[NSUserDefaults standardUserDefaults] setObject:emptyTransform(placemark.subLocality) forKey:@"area"];
//            [[NSUserDefaults standardUserDefaults] setObject:emptyTransform(place) forKey:@"location"];
//            [[NSUserDefaults standardUserDefaults] setObject:emptyTransform(placemark.thoroughfare) forKey:@"address"];
            if (self.locaitonInfo) {
                self.locaitonInfo(@{@"province":emptyTransform(placemark.addressDictionary[@"State"]),@"city":[NSString stringWithFormat:@"%@",placemark.locality],@"area":emptyTransform(placemark.subLocality)});
            }
        }
    }];
    
    [locationManager stopUpdatingLocation];
}

- (void)requestLocationManagerRelocateWithAccuracy:(CLLocationAccuracy)accuracy
{
    locationManager.desiredAccuracy = accuracy;
    // http://stackoverflow.com/a/24442603/2619161
    // from iOS 8, need authorization for user location
    if ([locationManager respondsToSelector:@selector(requestAlwaysAuthorization)]) {
        [locationManager requestWhenInUseAuthorization];
    }
    
    locationManager.delegate = self;
    
    [locationManager startUpdatingLocation];
    
    
}

- (BOOL)isValidUserLocation:(MKUserLocation*)loc
{
    CLLocationCoordinate2D coordinate = loc.coordinate;
    
    if (coordinate.latitude < 0.0001 || coordinate.longitude < 0.0001) {
        return NO;
    }
    
    return YES;
}
@end
