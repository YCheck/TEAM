//
//  BaiDuLocation.h
//  五粮特曲(业务员)
//
//  Created by yangchengyou on 16/4/1.
//  Copyright © 2016年 YCheng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <BaiduMapAPI_Location/BMKLocationService.h>
#import <BaiduMapAPI_Search/BMKGeocodeSearch.h>

@interface BaiDuLocation : NSObject<BMKLocationServiceDelegate,BMKGeoCodeSearchDelegate>


/**
 反编码结果
 */
@property (nonatomic,retain) BMKReverseGeoCodeResult *result;
@property (nonatomic,retain) BMKLocationService* locService;
@property (nonatomic,retain) BMKGeoCodeSearch *geoCodeSearch;
@property (nonatomic, strong) CLLocation *currentLocation;

+ (BaiDuLocation *)sharedInstance;
- (void)startLocationService;
- (void)stopLocationService;
- (void)destroyEntity;


@end
