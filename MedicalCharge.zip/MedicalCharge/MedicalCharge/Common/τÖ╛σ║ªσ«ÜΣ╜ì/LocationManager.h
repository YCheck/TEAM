//
//  LocationManager.h
//  GZMCoupon
//
//  Created by Alsor Zhou on 13-5-25.
//  Copyright (c) 2013年 GZMobile. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import "GlobalCore.h"
#import "CLLocation+Sino.h"
#import <MapKit/MapKit.h>
typedef void(^locationCompletion)(NSDictionary *locationInfo);

@interface LocationManager : NSObject <CLLocationManagerDelegate>
{
    CLLocationManager *locationManager;
}
+ (LocationManager *)sharedInstance;

@property (nonatomic, strong) CLLocation *currentLocation;//

@property (nonatomic, copy) locationCompletion locaitonInfo;

- (void)requestLocationManagerRelocateWithAccuracy:(CLLocationAccuracy)accuracy;

@end
