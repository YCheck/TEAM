//
//  AddImageView.h
//  Artselleasy
//
//  Created by admin on 15/6/4.
//  Copyright (c) 2015年 admin. All rights reserved.
////如果出现图片在区域外 控件高度不够用了 

#import <UIKit/UIKit.h>
#import "MyActionSheet.h"
@class AddImageView;
@protocol AddImageDelegate <NSObject>

@optional

/**
 图片数量发生变化时   可以做相应操作且调用imagelist可以拿到图片数组

 @param imageCount 现在datasource里面的图片数量
 */
- (void)monitorImageCountValueChangedForCurrentImages:(NSInteger)imageCount;

/**
 本view高度的

 @param height 本视图高度
 */
- (void)monitorImageCountValueChangedForCurrentViewHeight:(CGFloat)height;

/**
 添加照片

 @param addImageView self
 @param images 新增图片数组
 */
- (void)addImagesToAddImageView:(AddImageView *)addImageView images:(NSArray *)images;

/**
 删除照片

 @param addImageView self
 @param currentIndex 当前删除图片的下标
 */
- (void)deleteImageToAddImageView:(AddImageView *)addImageView currentIndex:(NSInteger)currentIndex;

/**
 选择视频

 @param coverImage 缩略图
 @param videoUrl 地址url
 */
- (void)chooseVideoCallBackForCoverImage:(UIImage *)coverImage and:(NSURL *)videoUrl;
/**
 调用actionsheet弹框时调用
 */
-(void)cancelrespond;

@end
@interface AddImageView : UIView
//已有图片url  调用该属性初始化界面会异步加载该url数组
@property (nonatomic,retain) NSMutableArray *imageSource;
//imageView容器
@property (nonatomic,retain) NSMutableArray *imageViewArray;
//提供上传的image  <UIImage *>数组
@property (nonatomic,retain) NSMutableArray *imageList;
//添加按钮
@property (nonatomic,retain) UIButton *addImageBtn;
@property (nonatomic,assign) id<AddImageDelegate> addImageDelegate;
@property (nonatomic,retain) MyActionSheet *actionSheet;

//初始化viewframe
- (instancetype)initWithFrame:(CGRect)frame;


- (void)initWithImage;//设置选择类型(相机 和 相册)
- (void)initWithTakePhoto;//设置选择框类型(只有相机)
@end
