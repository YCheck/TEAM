//
//  UIImageView+AddGesture.h
//  Artselleasy
//
//  Created by admin on 15/6/4.
//  Copyright (c) 2015年 faith. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (AddGesture)
//添加两种手势
- (id)initWithTarget:(id)target panAction:(SEL)action longAction:(SEL)longaction tapAction:(SEL)tapaction;
@end
