//
//  UIImageView+AddGesture.m
//  Artselleasy
//
//  Created by admin on 15/6/4.
//  Copyright (c) 2015年 faith. All rights reserved.
//

#import "UIImageView+AddGesture.h"

@implementation UIImageView (AddGesture)

- (id)initWithTarget:(id)target panAction:(SEL)action longAction:(SEL)longaction tapAction:(SEL)tapaction{
    if (self = [super init]) {
        self.userInteractionEnabled = YES;
        UIPanGestureRecognizer *panGestureRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:target action:action];//拖动
        [self addGestureRecognizer:panGestureRecognizer];
        
        UILongPressGestureRecognizer * longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:target action:longaction];
        longPress.minimumPressDuration = 1.0;
        [self addGestureRecognizer:longPress];
        
        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:target action:tapaction];
        [self addGestureRecognizer:tapGesture];
    }
    return self;
}

@end

