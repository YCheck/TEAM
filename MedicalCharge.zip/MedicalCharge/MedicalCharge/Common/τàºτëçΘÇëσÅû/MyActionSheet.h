//
//  MyActionSheet.h
//  艺术蜥蜴
//
//  Created by admin on 15/3/10.
//  Copyright (c) 2015年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^ChoosePhoto)(NSDictionary *info);

@protocol MyActionSheetDelegate <NSObject>
//回调
- (void)myActionSheetDelegate:(NSDictionary *)dic andSourceType:(UIImagePickerControllerSourceType)sourceType;

@end

@interface MyActionSheet : UIView

@property (nonatomic, assign) BOOL isEdit;//状态是否可以编辑
//@property (nonatomic , retain) UIButton *btn;

//回调方法二选一
@property (nonatomic , assign) id<MyActionSheetDelegate>delegate;
@property (nonatomic, copy) ChoosePhoto choosePhoto;
//调起actionsheet
- (void)actionShow;//拍照  相册
- (void)actionShowPhoto;//拍照

/**
 直接触发 省略actionsheet

 @param index 0 拍照 1 相册
 */
-(void)takePhotoWithIndex:(NSInteger )index;
@end
