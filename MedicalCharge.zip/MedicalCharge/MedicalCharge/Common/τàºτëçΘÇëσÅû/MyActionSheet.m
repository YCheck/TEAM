//
//  MyActionSheet.m
//  艺术蜥蜴
//
//  Created by admin on 15/3/10.
//  Copyright (c) 2015年 admin. All rights reserved.
//

#import "MyActionSheet.h"
@interface MyActionSheet ()<UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@property (nonatomic,assign) NSInteger type;

@end

@implementation MyActionSheet


- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.frame = frame;
    }
    return self;
}

- (void)actionShow{
    UIActionSheet *action = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"拍照",@"选取照片", nil];
    action.tag = 808;
    [action showInView:self];
}

- (void)actionShowPhoto{
    UIActionSheet *action = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"拍照", nil];
    action.tag = 809;
    [action showInView:self];
}

- (void)removeView{
    [self removeFromSuperview];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (actionSheet.tag == 809) {
        if (buttonIndex == 1){
//            [_delegate myActionSheetDelegate:nil andSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
            [self removeFromSuperview];
        }
        else
        {
            [self takePhotoWithIndex:buttonIndex];
        }
    }else{
        if (buttonIndex == 2){
//            [_delegate myActionSheetDelegate:nil andSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
            [self removeFromSuperview];
        }
        else
        {
            [self takePhotoWithIndex:buttonIndex];
        }
    }
    
    
}

//
//#pragma mark - 选取照片和拍照
-(void)takePhotoWithIndex:(NSInteger )index
{
    
    // 判断设备是否支持相册
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary])
    {
        NSLog(@"设备不支持访问相册");
        [[self viewController] dismissViewControllerAnimated:YES completion:nil];
        [self removeFromSuperview];
        return ;
    }
    //判断设备是否支持照相机
    self.type = index;
    UIImagePickerController * mipc = [[UIImagePickerController alloc] init];
    switch (index) {
        case 1:
            mipc.sourceType =  UIImagePickerControllerSourceTypeSavedPhotosAlbum;
            mipc.mediaTypes=[NSArray arrayWithObjects:@"public.image",nil];
            break;
        case 0:
            if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
            {
                NSLog(@"设备不支持访问照相机");
                [[self viewController] dismissViewControllerAnimated:YES completion:nil];
                [self removeFromSuperview];
                      UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示！"
                                                                message:@"设备不支持访问照相机"
                                                               delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
                [alert show];
                return;
            }
            mipc.sourceType =  UIImagePickerControllerSourceTypeCamera;
            mipc.mediaTypes=[NSArray arrayWithObjects:@"public.image",nil];
            break;
        case 2:
            break;
        case 3:
            //选择视频
            mipc.sourceType =  UIImagePickerControllerSourceTypeSavedPhotosAlbum;
            mipc.mediaTypes = [NSArray arrayWithObject:@"public.movie"];//设置媒体类型为public.movie
            break;
        default:
            break;
    }
    mipc.delegate = self;//委托
    mipc.allowsEditing = self.isEdit;//是否可编辑照片
    // 设置可用媒体类型
    [[self viewController] presentViewController:mipc animated:YES completion:^(void){
        //        NSLog(@"1");
        //        NSLog(@"%@",NSHomeDirectory());
    }];
}

- (UIViewController*)viewController {
    for (UIView* next = [self superview]; next; next = next.superview) {
        UIResponder* nextResponder = [next nextResponder];
        if ([nextResponder isKindOfClass:[UIViewController class]]) {
            return (UIViewController*)nextResponder;
        }
    }
    return nil;
}

#pragma mark - <UIImagePickerControllerDelegate>代理方法
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    if ([_delegate respondsToSelector:@selector(myActionSheetDelegate:andSourceType:)]) {
        [_delegate myActionSheetDelegate:info andSourceType:picker.sourceType];
    }
    if (self.choosePhoto) {
        self.choosePhoto(info);
    }
    
    [[self viewController] dismissViewControllerAnimated:YES completion:nil];
    [self removeFromSuperview];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [[self viewController] dismissViewControllerAnimated:YES completion:nil];
    [self removeFromSuperview];
}


@end
