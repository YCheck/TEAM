//
//  AddImageView.m
//  Artselleasy
//
//  Created by admin on 15/6/4.
//  Copyright (c) 2015年 admin. All rights reserved.
//

#import "AddImageView.h"
#import "UIImageView+AddGesture.h"
#import "CycleScrollViewController.h"
#import <Photos/Photos.h>
//#import <TZImagePickerController.h>
//#import <AssetsLibrary/AssetsLibrary.h>
//#import <ImageIO/ImageIO.h>
//#import "NSDictionary+CLLocation.h"
//#import "ServerDate.h"
#define addImageMainHeight     [[UIScreen mainScreen] bounds].size.height
#define addImageMainWidth      [[UIScreen mainScreen] bounds].size.width
#define AUTO_WIDTH(number) number / 375.0 * addImageMainWidth

#define imageWidth AUTO_WIDTH(80)

#define imageHeight AUTO_WIDTH(80)

#define imageTopGap 0.f//控件距离上下左右两边的间隙

#define margin AUTO_WIDTH(8.5) //图片之间满足的最小间距  如果按照margin排列不下  会重新计算间距

//大概算出最大排列个数
#define iCount (int)((self.frame.size.width - 2*imageTopGap )/imageWidth)

#define imageCount (int) 4  //横向最多排列个数

#define imageHCount (int) 3  //纵向最多排列个数

#define imageGap margin  //image间得间隙

//#define imagePortraitGap (self.frame.size.height - 2*imageTopGap - imageHeight * imageHCount)/(imageHCount - 1)  //纵向间隙
#define imagePortraitGap imageGap  //纵向间隙
#define maxImage 9

@interface AddImageView ()<MyActionSheetDelegate,UIActionSheetDelegate>
{
    // 拖动的image的原始center坐标
    CGPoint _dragFromPoint;
    // 要把image拖往的center坐标
    CGPoint _dragToPoint;
    // image拖往的rect
    CGRect _dragToFrame;
    //拖动的image是否可以交换
    BOOL _isDragImageContainedInOtherImage;
    //拖往目标处的imageView
    UIImageView *_pushImageView;
    //被拖动的imageview
    UIImageView *_currentImageView;
    //记录原始tag值
    NSInteger _ImageTag;
    //被替换的image tag值
    NSInteger _changeImageTag;
    //被删除的tag值
    int _deleteViewTag;
    UILabel *maxImageLabel;//中间文字
}
@end

@implementation AddImageView
//set
-(void)setImageSource:(NSMutableArray *)imageSource{
    _imageSource = imageSource;
    NSLog(@"---count = %lu",(unsigned long)_imageSource.count);
    [self initWithImage];
}

- (NSMutableArray *)imageViewArray{
    if (!_imageViewArray) {
        _imageViewArray = [[NSMutableArray alloc] init];
    }
    return _imageViewArray;
}

- (NSMutableArray *)imageList{
    if (!_imageList) {
        _imageList = [[NSMutableArray alloc] init];
    }
    return _imageList;
}

- (instancetype)initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        self.clipsToBounds = YES;
    }
    return self;
}




//初始化图片
- (void)initWithImage{
    [super layoutSubviews];
    [self initWithInterface:0];
}
//初始化
- (void)initWithTakePhoto{
    [self initWithInterface:1];
}

- (void)initWithInterface:(NSInteger)index{
    //初始化方便外部调用
    _actionSheet = [[MyActionSheet alloc] initWithFrame:self.frame];
    _actionSheet.delegate = self;
    _actionSheet.isEdit = NO;
    [self addSubview:_actionSheet];
    
    _isDragImageContainedInOtherImage = NO;
    int count;
    if (_imageSource.count > maxImage) {
        count = maxImage;
    }else{
        count = (int)_imageSource.count;
    }
    
    for (int i = 0; i < count; i ++) {
        [self createImageView:_imageSource[i] andIndex:i];
        if (_imageViewArray.count == count) {
            [self createAddBtn:index];
        }
    }
    
    if (count == 0) {
        [self createAddBtn:index];
    }
}

//addBtn

- (void)createAddBtn:(NSInteger)index{
    _addImageBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _addImageBtn.frame = [self createImageViewFrame:_imageViewArray.count];
    if (index == 0) {
        [_addImageBtn addTarget:self action:@selector(addBtnSelected:) forControlEvents:UIControlEventTouchUpInside];
    }else{
        [_addImageBtn addTarget:self action:@selector(addBtnSelectedForTakephoto:) forControlEvents:UIControlEventTouchUpInside];
    }
//    [_addImageBtn setImage:[UIImage imageNamed:@"add"] forState:UIControlStateNormal];
    [_addImageBtn setBackgroundImage:YCYImage(@"tianjiazhaopian") forState:UIControlStateNormal];
    _addImageBtn.contentMode = UIViewContentModeScaleToFill;
//    _addImageBtn.backgroundColor = YCYHexColor(@"f2f4f5");
//    [_addImageBtn setImage:[UIImage imageNamed:@"添加照片"] forState:UIControlStateHighlighted];
//    [_addImageBtn setTitle:@"添加图片" forState:UIControlStateNormal];
    [self addSubview:_addImageBtn];
    _addImageBtn.clipsToBounds = YES;
}

//刷新btnframe
- (void)refreshAddButtonFrame{
    NSInteger row = (_imageViewArray.count + 1)/imageCount;
    if ((_imageViewArray.count + 1)%imageCount != 0 && _imageViewArray.count <= maxImage) {
        row += 1;
    }
    if ([self.addImageDelegate respondsToSelector:@selector(monitorImageCountValueChangedForCurrentImages:)]) {
        [self.addImageDelegate monitorImageCountValueChangedForCurrentImages:_imageViewArray.count];
    }
    
    if ([self.addImageDelegate respondsToSelector:@selector(monitorImageCountValueChangedForCurrentViewHeight:)]) {
        
        [self.addImageDelegate monitorImageCountValueChangedForCurrentViewHeight:imageHeight * row + (row - 1) * margin];
    }
    
    
    [UIView animateWithDuration:0.3f animations:^{
        _addImageBtn.frame = [self createImageViewFrame:_imageViewArray.count];
    }];
    //判断还能否添加
    if (_imageViewArray.count >= maxImage) {
        _addImageBtn.userInteractionEnabled = NO;
        _addImageBtn.hidden = YES;
    }else{
        _addImageBtn.userInteractionEnabled = YES;
        _addImageBtn.hidden = NO;
    }
    
    if (_imageViewArray.count == 0) {
    }else{
        
    }
}

//imageview
- (void)createImageView:(UIImage *) image andIndex:(NSInteger)index{
    if (_imageViewArray.count + 1 > maxImage) {
        return;
    }
    [self.imageList addObject:image];
    UIImageView *imageView = [[UIImageView alloc] initWithTarget:self panAction:nil longAction:nil tapAction:@selector(tapGestureAction:)];
    imageView.contentMode = UIViewContentModeScaleAspectFill;
    imageView.clipsToBounds = YES;
    imageView.frame = [self createImageViewFrame:index];
    imageView.image = image;
    imageView.tag = index + 1;
    
    //删除按钮
    UIButton *deleteBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    deleteBtn.frame = CGRectMake(imageWidth - 20, 0, 20, 20);
    deleteBtn.imageEdgeInsets = UIEdgeInsetsMake(0, 0, 0, 0);
    [deleteBtn addTarget:self action:@selector(imageRightDeleteBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [deleteBtn setImage:[UIImage imageNamed:@"d2_quxiao"] forState:UIControlStateNormal];
    [imageView addSubview:deleteBtn];
    
    [self addSubview:imageView];
    [self.imageViewArray addObject:imageView];
}

//刷新imageframe
- (void)refreshImageViewFrame:(NSInteger)imageNum{
    if (_deleteViewTag > self.imageViewArray.count) {
        return;
    }
    UIImageView *imageView = (UIImageView *)[self viewWithTag:_deleteViewTag + 1];
    NSLog(@"image = %@",imageView);
    [UIView animateWithDuration:0.3f animations:^{
        imageView.tag = _deleteViewTag;
        imageView.frame = [self createImageViewFrame:_deleteViewTag - 1];
    }];
    _deleteViewTag++;
    
}

//click
- (void)addBtnSelected:(UIButton *)sender{
    //系统actionsheet选择
//    if ([self.addImageDelegate respondsToSelector:@selector(cancelrespond)]) {
//        [self.addImageDelegate cancelrespond];
//    }
//    [_actionSheet actionShow];
//    [self addSubview:_actionSheet];
    //三方相册选择
    TZImagePickerController *imagePickerVc = [[TZImagePickerController alloc] initWithMaxImagesCount:maxImage delegate:nil];
    imagePickerVc.sortAscendingByModificationDate = NO;
    imagePickerVc.allowPickingOriginalPhoto = NO;
    imagePickerVc.allowPickingVideo = NO;
    WeakSelf
    [imagePickerVc setDidFinishPickingPhotosHandle:^(NSArray<UIImage *> *photos, NSArray *assets, BOOL isSelectOriginalPhoto) {
        for (UIImage *image in photos) {
            [weakSelf createImageView:image andIndex:self.imageViewArray.count];
            [weakSelf refreshAddButtonFrame];
        }
        [weakSelf addImageCallback:photos];
    }];
    
    [imagePickerVc setDidFinishPickingVideoHandle:^(UIImage *coverImage, id asset) {//视频
        [weakSelf videoTransfer:asset];
    }];
    
    [self.ycy_viewController presentViewController:imagePickerVc animated:YES completion:nil];
}

- (void)addBtnSelectedForTakephoto:(UIButton *)sender{
    if ([self.addImageDelegate respondsToSelector:@selector(cancelrespond)]) {
        [self.addImageDelegate cancelrespond];
    }
    [_actionSheet actionShowPhoto];
    [self addSubview:_actionSheet];
}

-(void)addImageCallback:(NSArray *)photos{
    if (_addImageDelegate && [_addImageDelegate respondsToSelector:@selector(addImagesToAddImageView:images:)]) {
        [_addImageDelegate addImagesToAddImageView:self images:photos];
    }
}

//回传
- (void)myActionSheetDelegate:(NSDictionary *)dic andSourceType:(UIImagePickerControllerSourceType)sourceType{
    if (dic) {
        
        __block UIImage *image = dic[UIImagePickerControllerOriginalImage];
        [self createImageView:image andIndex:self.imageViewArray.count];
        [self refreshAddButtonFrame];
    }
}

- (void)loadImage:(UIImage *)image andName:(NSString *)mark{
    UIImage *markImage = [self watermarkImage:image withName:mark];
    [self createImageView:markImage andIndex:self.imageViewArray.count];
    [self refreshAddButtonFrame];
}

//计算frame
-(CGRect)createImageViewFrame:(NSInteger)_index{
    int imageH = (int)(_index/imageCount);
    int h = imageHeight + margin;//固定间距大小 margin
    int imageY = imageTopGap + imageH*h;
    int imageW = _index % imageCount;
    int w = imageWidth + margin;//固定间距大小 margin
    int imageX = imageTopGap + imageW * w;
    return CGRectMake(imageX, imageY, imageWidth, imageHeight);
}

#pragma mark - 手势操作

- (BOOL)panGestureAction:(UIPanGestureRecognizer *)recognizer
{
    switch ([recognizer state])
    {
        case UIGestureRecognizerStateBegan:
            [self dragImageBegan:recognizer];
            break;
        case UIGestureRecognizerStateChanged:
            [self dragImageMoved:recognizer];
            break;
        case UIGestureRecognizerStateEnded:
            [self dragImageEnded:recognizer];
            break;
        default: break;
    }
    return YES;
}

- (void)tapGestureAction:(UITapGestureRecognizer *)recognizer{
   int index = (int)recognizer.view.tag - 1;
    CycleScrollViewController *cycleImageScrollView = [[CycleScrollViewController alloc] initWithMixids:self.imageList currentIndex:index];
    [[self viewController] presentViewController:cycleImageScrollView animated:YES completion:nil];
}


- (void)dragImageBegan:(UIPanGestureRecognizer *)recognizer
{
    _currentImageView = (UIImageView *)recognizer.view;
    _dragFromPoint = recognizer.view.center;
    _ImageTag = recognizer.view.tag;
    [UIView animateWithDuration:0.2f animations:^{
        recognizer.view.transform = CGAffineTransformMakeScale(1.05, 1.05);
        recognizer.view.alpha = 0.8;
    }];
}

- (void)dragImageMoved:(UIPanGestureRecognizer *)recognizer
{
    CGPoint translation = [recognizer translationInView:self];
    recognizer.view.center = CGPointMake(recognizer.view.center.x + translation.x,
                                         recognizer.view.center.y + translation.y);
    [recognizer.view.superview bringSubviewToFront:recognizer.view];
    //保持view上
    [recognizer setTranslation:CGPointZero inView:self];
    
    [self rollbackPushedTileIfNecessaryWithPoint:recognizer.view.center];
    [self pushedImageMoveToDragFromPointIfNecessaryWithTileView:(UIImageView *)recognizer.view];
}
- (void)dragImageEnded:(UIPanGestureRecognizer *)recognizer
{
    [UIView animateWithDuration:0.2f animations:^{
        recognizer.view.transform = CGAffineTransformMakeScale(1.f, 1.f);
        recognizer.view.alpha = 1.f;
    }];
    
    [UIView animateWithDuration:0.2f animations:^{
        if (_isDragImageContainedInOtherImage)
            recognizer.view.center = _dragToPoint;
        else
            recognizer.view.center = _dragFromPoint;
    }];
    
    _pushImageView = nil;
    _isDragImageContainedInOtherImage = NO;
    
}
- (void)pushedImageMoveToDragFromPointIfNecessaryWithTileView:(UIImageView *)imageView
{
    
    for (UIImageView *item in self.imageViewArray)
    {
        if (CGRectContainsPoint(item.frame, imageView.center) && item != imageView)
        {
            NSLog(@"--------tag1=%lu----------tag2=%lu---",_currentImageView.tag-1,item.tag - 1);
            [self.imageList exchangeObjectAtIndex:_currentImageView.tag-1 withObjectAtIndex:item.tag-1];
            _dragToPoint = item.center;
            _dragToFrame = item.frame;
            _pushImageView = item;
            _changeImageTag = item.tag;
            _currentImageView.tag = item.tag;
            _pushImageView.tag = _ImageTag;
            
            _isDragImageContainedInOtherImage = YES;
            
            [UIView animateWithDuration:0.2 animations:^{
                item.center = _dragFromPoint;
            }];
            break;
        }
    }
}
//判断是否移出pushimageview frame
- (void)rollbackPushedTileIfNecessaryWithPoint:(CGPoint)point
{
    
    if (_pushImageView && !CGRectContainsPoint(_dragToFrame, point))
    {
        [UIView animateWithDuration:0.2f animations:^{
            _pushImageView.center = _dragToPoint;
        }];
        _pushImageView.tag =_changeImageTag;
        _currentImageView.tag = _ImageTag;
        _dragToPoint = _dragFromPoint;
        _pushImageView = nil;
        _isDragImageContainedInOtherImage = NO;
        NSLog(@"--------tag3=%lu----------tag4=%lu---",_currentImageView.tag-1,_changeImageTag - 1);
        [self.imageList exchangeObjectAtIndex:_currentImageView.tag-1 withObjectAtIndex:_changeImageTag-1];
    }
}




- (BOOL)longGestureAction:(UILongPressGestureRecognizer *)recognizer
{
    if ([recognizer state] == UIGestureRecognizerStateBegan) {
        _deleteViewTag = (int)recognizer.view.tag;
        UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"删除", nil];
        [actionSheet showInView:self];
    }
    return YES;
}

- (void)longGesture:(int)index{
    int imgCount = (int)self.imageViewArray.count + 1;
    NSLog(@"count = %d",imgCount);
    for (int i = index;i < imgCount; i ++) {
        [self performSelector:@selector(refreshImageViewFrame:) withObject:self afterDelay:0.1];
    }
    [self refreshAddButtonFrame];
}

//actionsheetDelegate
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 1){
        return;
    }else{
        UIImageView *recognizImage = (UIImageView *)[self viewWithTag:_deleteViewTag];
        [self.imageViewArray removeObject:recognizImage];
        [self.imageList removeObjectAtIndex:_deleteViewTag-1];
        [recognizImage removeFromSuperview];
        [self longGesture:_deleteViewTag];
    }
}

- (void)imageRightDeleteBtnAction:(UIButton *)sender{
    UIImageView *recognizImage = (UIImageView *)sender.superview;
    _deleteViewTag = (int)recognizImage.tag;
    [self.imageViewArray removeObject:recognizImage];
    [self.imageList removeObjectAtIndex:_deleteViewTag-1];
    [recognizImage removeFromSuperview];
    [self longGesture:_deleteViewTag];
    if (_addImageDelegate && [_addImageDelegate respondsToSelector:@selector(deleteImageToAddImageView:currentIndex:)]) {
        [_addImageDelegate deleteImageToAddImageView:self currentIndex:_deleteViewTag-1];
    }
}
//获取系统时间

// 画水印
-(UIImage *)watermarkImage:(UIImage *)img withName:(NSString *)name
{
    NSLog(@"name = %@",name);
//    NSLog(@"%@,%@",GETNSUserDefault(@"city"),GETNSUserDefault(@"location"));
    NSString *mark = name;
    int w = img.size.width;
    int h = img.size.height;
    UIGraphicsBeginImageContext(img.size);
    [img drawInRect:CGRectMake(0, 0, w, h)];
    NSMutableParagraphStyle* style = [[NSMutableParagraphStyle alloc] init];
    [style setAlignment:NSTextAlignmentRight];
    NSDictionary *attr = @{
                           NSFontAttributeName: [UIFont boldSystemFontOfSize:50],  //设置字体
                           NSForegroundColorAttributeName :[UIColor redColor],     //设置字体颜色
                           NSParagraphStyleAttributeName:style
                           };
//    [mark drawInRect:CGRectMake(0,0 ,50 ,14 ) withAttributes:attr];         //左上角
//    [mark drawInRect:CGRectMake(w - 50, 0,50 ,14 ) withAttributes:attr];      //右上角
    [mark drawInRect:CGRectMake(15, h - 64 ,w-30, 64) withAttributes:attr];  //右下角
//    [mark drawInRect:CGRectMake(0, h - 14 , 50,14 ) withAttributes:attr];    //左下角
    UIImage *aimg = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return aimg;
}
//获取父类
- (UIViewController*)viewController {
    for (UIView* next = [self superview]; next; next = next.superview) {
        UIResponder* nextResponder = [next nextResponder];
        if ([nextResponder isKindOfClass:[UIViewController class]]) {
            return (UIViewController*)nextResponder;
        }
    }
    return nil;
}

- (void)videoTransfer:(PHAsset *)asset{
    NSArray *assetResources = [PHAssetResource assetResourcesForAsset:asset];
    PHAssetResource *resource;
    NSURL *videoURL = nil;
    for (PHAssetResource *assetRes in assetResources) {
        if (assetRes.type == PHAssetResourceTypePairedVideo ||
            assetRes.type == PHAssetResourceTypeVideo) {
            resource = assetRes;
        }
    }
    NSString *fileName = @"tempAssetVideo.mov";
    if (resource.originalFilename) {
        fileName = resource.originalFilename;
    }
    
    if (asset.mediaType == PHAssetMediaTypeVideo || asset.mediaSubtypes == PHAssetMediaSubtypePhotoLive) {
        PHVideoRequestOptions *options = [[PHVideoRequestOptions alloc] init];
        options.version = PHImageRequestOptionsVersionCurrent;
        options.deliveryMode = PHImageRequestOptionsDeliveryModeHighQualityFormat;
        
        NSString *PATH_MOVIE_FILE = [NSTemporaryDirectory() stringByAppendingPathComponent:fileName];
        videoURL = [NSURL fileURLWithPath:PATH_MOVIE_FILE];
    }
    
    if (videoURL) {
        if ([self.addImageDelegate respondsToSelector:@selector(chooseVideoCallBackForCoverImage:and:)]) {
            [self.addImageDelegate chooseVideoCallBackForCoverImage:nil and:videoURL];
        }
    }
}

@end
