//
//  GLScrollView.h
//  图书阅读器
//
//  Created by rimi on 14-4-22.
//  Copyright (c) 2014年 rimi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GLScrollView : UIScrollView



@end
