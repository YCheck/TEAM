//
//  GLUIScrollView.h
//  太平人寿 - 1
//
//  Created by rimi on 14-6-6.
//  Copyright (c) 2014年 rimi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIImageView+WebCache.h"
@interface GLUIScrollView : UIView

@property (nonatomic , strong) NSDictionary *dic;
@property (nonatomic , strong) NSTimer *timer;
@property (nonatomic , strong) UIViewController *VC;
@property (nonatomic, strong) UIView *tabbar;
@property (nonatomic,retain) UINavigationController *navigation;
@property (nonatomic,retain) UIViewController *rootVC;
@property (nonatomic,retain) UIView *animation;

- (id)initWithFrame:(CGRect)frame;
- (void)starTimer;
- (void)gainImage:(NSArray *)imageArray;
- (void)imageViewClickAction:(NSString *)musicName andNavigation:(UINavigationController *)navigation andId:(int )zhanshiId;

@end
