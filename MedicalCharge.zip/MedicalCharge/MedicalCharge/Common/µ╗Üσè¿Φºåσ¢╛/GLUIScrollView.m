//
//  GLUIScrollView.m
//  太平人寿 - 1
//
//  Created by rimi on 14-6-6.
//  Copyright (c) 2014年 rimi. All rights reserved.
//

#import "GLUIScrollView.h"
#import "GLScrollView.h"
#import "CycleScrollViewController.h"
#import "UIImageView+AddGesture.h"

#define AUTOSIZE(height) (Screen_Width/375)*height
#define CircleTime 6.0f

@interface GLUIScrollView ()<UIScrollViewDelegate>
{
    GLScrollView *_scrollView;
    UIPageControl *_pageControl;
    NSInteger _scrollViewIndex;
    NSInteger _i;
    NSArray *_imageArr;
    NSInteger _currentIndex;
    NSMutableArray *_imageViewArray;
    int _zhanshiId;
    NSString *_musicName;
    UILabel *_numLabel;
    NSArray *_smallImageArray;//存放缩略图
    NSArray *_bigImageArray;//存放大图路劲
}
@end

@implementation GLUIScrollView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.frame = frame;
        // Initialization code
    }
    return self;
}
#pragma mark 获取图集
- (void)gainImage:(NSArray *)imageArray
{
    if (imageArray.count > 0) {
        _imageArr = [[NSArray alloc] initWithArray:imageArray];
        [self initWithDataSource];
        [self initWithUserInterface];
    }
    if (_imageArr.count < 2) {
        
    }else{
        [self starTimer];
    }
}
//详情界面用
- (void)imageViewClickAction:(NSString *)musicName andNavigation:(UINavigationController *)navigation andId:(int)zhanshiId
{
    _zhanshiId = zhanshiId;
    self.navigation = navigation;
    _musicName = musicName;
}

- (void)autoChangeScorellView
{
    [_scrollView setContentOffset:CGPointMake(CGRectGetWidth(_scrollView.bounds)*2  , 0) animated:YES];
}
#pragma mark timer
- (void)starTimer
{
    if (!_timer) {
        _timer = [NSTimer scheduledTimerWithTimeInterval:CircleTime target:self selector:@selector(autoChangeScorellView) userInfo:nil repeats:YES];
        [[NSRunLoop currentRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
    }
}

#pragma mark -- 初始化界面
- (void)initWithUserInterface
{
    if (!_scrollView) {
        _scrollView = [[GLScrollView alloc] initWithFrame:self.bounds];
        _scrollView.delegate = self;
        _scrollView.backgroundColor = [UIColor whiteColor];
        _scrollView.pagingEnabled = YES;
        _scrollView.showsHorizontalScrollIndicator = NO;
        [self addSubview:_scrollView];
        [_scrollView setContentOffset:CGPointMake(0, 0)];
        _scrollView.contentSize = CGSizeMake(CGRectGetWidth(_scrollView.bounds) * 3, CGRectGetHeight(_scrollView.bounds));
        
    }
    
    if (_imageArr.count < 2) {
        _scrollView.scrollEnabled = NO;
    }
    NSLog(@"======--=========%li",(unsigned long)_imageArr.count);
    
    //初始化三种图片
    for (int i=0; i<3; i++) {
        NSInteger index = [self indexWithIndex:_currentIndex + i - 1];
        UIImageView *imageView = [[UIImageView alloc] init];
        NSURL *url = YCYURL(_imageArr[index]);
        [imageView py_setImageWithURL:url placeholderImage:YCYImage(@"占位图340x210")];
        imageView.frame = CGRectMake(CGRectGetWidth(_scrollView.bounds) * i, 0, CGRectGetWidth(_scrollView.bounds), CGRectGetHeight(_scrollView.bounds));
        imageView.tag = 100 + index;
        imageView.contentMode = UIViewContentModeScaleAspectFill;
        imageView.clipsToBounds = YES;
        imageView.userInteractionEnabled = YES;
        [_scrollView addSubview:imageView];
        [_imageViewArray addObject:imageView];
        if (i == 1) {
            UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGestureAction:)];
            [imageView addGestureRecognizer:tapGesture];
        }
        
    }
    //设置最初加载显示的是中间的图片
    [self resumeScrollViewContenOffSet:_scrollView];
    _pageControl = [[UIPageControl alloc] initWithFrame:CGRectMake(0, 0,300, 20)];
    _pageControl.center = CGPointMake(CGRectGetMidX(self.bounds), CGRectGetMidY(self.bounds) + 65);
    _pageControl.numberOfPages = _imageArr.count;
    //设置页数指示点显示颜色
    _pageControl.pageIndicatorTintColor = WhiteColor;
    _pageControl.currentPageIndicatorTintColor = MainCOLOR;
    [self addSubview:_pageControl];
    if (_imageArr.count < 2) {
        _pageControl.hidden = YES;
    }else{
        _pageControl.hidden = NO;
    }
}


#pragma mark- 点击左滑按钮
- (void)leftBtnClickAction{
    
    [_scrollView setContentOffset:CGPointMake(0 , 0) animated:YES];
}


#pragma mark- 点击右滑按钮
- (void)rightBtnClickAction{
    [_scrollView setContentOffset:CGPointMake( CGRectGetWidth(_scrollView.bounds) * 2 , 0) animated:YES];
}

#pragma mark -- 判断当前索引
- (NSInteger) indexWithIndex:(NSInteger)index
{
    //判断索引是否为第一还是最后
    int i = (int)_imageArr.count - 1;
    if (index > i) {
        index = 0;
    }else if (index < 0){
        index = i;
    }
    return index;
}

#pragma mark -- 更新ScrollView
- (void)updateScrollView:(UIScrollView *)scrollView
{
    BOOL shoudUpdate = NO;//判断是否更新
    NSLog(@"%f",scrollView.contentOffset.x);
    NSInteger scroOffset = scrollView.contentOffset.x;
    NSInteger secondImageScro = CGRectGetWidth(_scrollView.bounds)*2;
    
    if (scroOffset == secondImageScro) {//左滑
        _currentIndex = [self indexWithIndex:_currentIndex + 1];
        shoudUpdate = YES;
   }else if (scroOffset == 0){//右滑
        _currentIndex = [self indexWithIndex:_currentIndex -1];
        shoudUpdate = YES;
   }
    if (!shoudUpdate) {
        return;
    }
    //重新加载三张图片
    for (int i=0; i<3; i++) {
        NSInteger index = [self indexWithIndex:_currentIndex + i -1];
        UIImageView *imageView = (UIImageView *)_imageViewArray[i];
        NSURL *url = YCYURL(_imageArr[index]);
        [imageView py_setImageWithURL:url placeholderImage:YCYImage(@"占位图340x210")];
        imageView.contentMode = UIViewContentModeScaleAspectFill;
        imageView.clipsToBounds = YES;
        imageView.tag = 100 + index;
        imageView.userInteractionEnabled = YES;
    }
    //设置当前索引
    _numLabel.text = [NSString stringWithFormat:@"%i/%li",_currentIndex + 1,(unsigned long)_imageArr.count];
    _pageControl.currentPage = _currentIndex;
    //复位
    [self resumeScrollViewContenOffSet:scrollView];
}

//url拼接
-(NSURL *)checkImageMode:(NSString *)urlString{
    if (urlString.length < 5) {
        return nil;
    }
    return nil;
}
- (void)initWithDataSource
{
    if (!_imageViewArray) {
        _imageViewArray = [[NSMutableArray alloc] initWithCapacity:3];
        _currentIndex = 0;
    }else{
        for (UIImageView *imageView in _imageViewArray) {
            [imageView removeFromSuperview];
        }
        [_imageViewArray removeAllObjects];
    }
    
    
}

#pragma mark -- scrollView重置偏移度
- (void)resumeScrollViewContenOffSet:(UIScrollView *)scrollView
{
    [_scrollView setContentOffset:CGPointMake(CGRectGetWidth(scrollView.bounds) , 0) animated:NO];
}

//当scrollview滚动的时候调用
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [self updateScrollView:scrollView];
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
        [_timer setFireDate:[NSDate distantFuture]];
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
        [_timer setFireDate:[NSDate dateWithTimeIntervalSinceNow:CircleTime]];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    
}
- (UIViewController*)viewController {
    for (UIView* next = [self superview]; next; next = next.superview) {
        UIResponder* nextResponder = [next nextResponder];
        if ([nextResponder isKindOfClass:[UIViewController class]]) {
            return (UIViewController*)nextResponder;
        }
    }
    return nil;
}

-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    
}


- (void)tapGestureAction:(UITapGestureRecognizer *)recognizer{
//    int index = (int)recognizer.view.tag - 100;
//    CycleScrollViewController *cycleImageScrollView = [[CycleScrollViewController alloc] initWithMixids:_bigImageArray currentIndex:index];
//    [[self viewController] presentViewController:cycleImageScrollView animated:YES completion:nil];
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */


@end
