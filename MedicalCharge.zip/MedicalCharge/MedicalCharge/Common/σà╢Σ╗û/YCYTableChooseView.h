//
//  YCYTableChooseView.h
//  SocialApp
//
//  Created by yangchengyou on 17/2/22.
//  Copyright © 2017年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol YCYTableChooseViewDelegate <NSObject,UITableViewDelegate>

- (void)ycyTableChooseView:(UIView *)multView didSelectRow:(NSInteger)index andSelectData:(id)selectData;

@end
@interface YCYTableChooseView : UIView

@property (nonatomic,assign) id<YCYTableChooseViewDelegate> delegate;


/**
 选择列表

 @param array 数据源 如 @[@"标题",@"标题"]
 @param view 根据此view来确定所显示列表的位置  （取view的x，y，width属性）
 @return 选项列表
 */
- (instancetype)initDataSource:(NSArray *)array andRelativeView:(UIView *)view;


/**
 显示该view
 */
- (void)showInView;
@end
