//
//  YCYMultipleSelectionView.m
//  PintuangouPro
//
//  Created by yangchengyou on 17/1/22.
//  Copyright © 2017年 zipingfang. All rights reserved.
//

#import "YCYMultipleSelectionTextView.h"

#define cellHeight 41 //每排高
#define ShowViewW 141 //弹框width
#define TopSpace 3 //距离navigation
#define ArrowsH 6 //箭头的高
#define ArrowsW 6//箭头的K宽
@interface YCYMultipleSelectionTextView ()
{
    UIButton *_maskView;//蒙版
    NSString *_titleName;
}
@property (nonatomic,retain) NSMutableArray *dataSource;

@end
@implementation YCYMultipleSelectionTextView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (instancetype)initDataSource:(NSArray *)array andDefaultSelectedTitle:(NSString *)title{
    _titleName = title;
    CGRect frame = CGRectMake((YCYScreen_Width - ShowViewW)/2, 64, ShowViewW,cellHeight * array.count + ArrowsH + TopSpace);
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor clearColor];
        self.dataSource = [[NSMutableArray alloc] initWithArray:array];
        
        UIImageView *imageView = [[UIImageView alloc] init];
        imageView.frame = CGRectMake(0, 3, self.ycy_width, self.ycy_height - 3);
        //        imageView.layer.borderWidth = 1;
        //        imageView.layer.borderColor = LineCOLOR.CGColor;
        imageView.backgroundColor = [UIColor clearColor];
        imageView.image = [UIImage imageNamed:@"b3_xialabeijing"];
        [self addSubview:imageView];
        
//        UIView *rootBG = [[UIView alloc] initWithFrame:CGRectMake(0, ArrowsH + TopSpace,ShowViewW,cellHeight * array.count)];
//        rootBG.backgroundColor = [UIColor blackColor];
//        rootBG.alpha = 0.6;
//        [self addSubview:rootBG];
//        rootBG.layer.cornerRadius = 5;
    }
    return self;
}

- (void)showInView{
    UIView *rootView = [[UIApplication sharedApplication] keyWindow].rootViewController.view;
    
    
    _maskView = [UIButton buttonWithType:UIButtonTypeCustom];
    _maskView.frame = [UIScreen mainScreen].bounds;
    [_maskView setTitle:@"" forState:UIControlStateNormal];
    [_maskView addTarget:self action:@selector(closeThisView:) forControlEvents:UIControlEventTouchUpInside];
    _maskView.backgroundColor = [UIColor clearColor];
    _maskView.alpha = 1;
    [rootView addSubview:_maskView];
    
    [rootView addSubview:self];
    if (_dataSource.count < 1) {
        return;
    }
    int y = ArrowsH + TopSpace;
    for (int i = 0; i < _dataSource.count; i ++) {
//        UIImageView *headerImage = [[UIImageView alloc] init];
//        headerImage.frame = CGRectMake(19,y, 15, 15);
//        headerImage.image = [UIImage imageNamed:_dataSource[_dataSource.count/2  + i]];
//        [self addSubview:headerImage];
        
        UILabel *title = [[UILabel alloc] init];
        title.frame = CGRectMake(0, y, ShowViewW, cellHeight);
        title.textColor = TextCOLOR333;
        title.font = YCYFont(15);
        title.textAlignment = NSTextAlignmentCenter;
        title.text = _dataSource[i];
        [self addSubview:title];
        
        if ([_dataSource[i] isEqualToString:_titleName]) {
            title.textColor = TextCOLOR333;
        }
        
        UIButton *selectBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        selectBtn.frame = CGRectMake(0,cellHeight * i + ArrowsH + TopSpace,self.frame.size.width, cellHeight);
        selectBtn.tag = i + 20000;
        [selectBtn setTitle:@"" forState:UIControlStateNormal];
        selectBtn.titleLabel.font = YCYFont(14);
        [selectBtn setTitleColor:[UIColor ycy_colorWithHex:0xdf3032] forState:UIControlStateNormal];
        [selectBtn addTarget:self action:@selector(selectedBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:selectBtn];
        
        y +=  cellHeight;
        
        if (i < _dataSource.count -1) {
            UIView *lineView = [[UIView alloc] init];
            lineView.frame = CGRectMake(0, cellHeight * (i + 1) + ArrowsH + TopSpace, self.frame.size.width ,1);
            lineView.backgroundColor = LineCOLOR;
            [self addSubview:lineView];
        }
        
    }
}

- (void)selectedBtnAction:(UIButton *)sender{
    
    if ([_delegate respondsToSelector:@selector(ycyMultipleSelectionTextView:didSelectRow:)]) {
        [_delegate ycyMultipleSelectionTextView:self didSelectRow:sender.tag - 20000];
    }
    _delegate = nil;
    [_maskView removeFromSuperview];
    [self removeFromSuperview];
}

- (void)closeThisView:(UIButton *)sender{
    if ([_delegate respondsToSelector:@selector(closeViewForClickSpaceView)]) {
        [_delegate closeViewForClickSpaceView];
    }
    _delegate = nil;
    [_maskView removeFromSuperview];
    [self removeFromSuperview];
}

@end
