//
//  YCYPhotoSortView.h
//  SocialApp
//
//  Created by yangchengyou on 17/2/23.
//  Copyright © 2017年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YCYPhotoSortView : UIView


/**
 调用此方法初始化images
 */
- (void)initWithInterface;

/**
 初始化

 @param frame frame
 @param images images
 @return self
 */
//- (instancetype)initWithFrame:(CGRect)frame andImages:(NSArray *)images;

/**
 排序方法 1张 一个   2-4张 两排两个 5-9 三个2-3排 返回控件高度

 @param superViewWidth 要承载这些图的view宽
 @param images 图片数组
 @param mediaType 1 图片 2 视频 3 文字
 @param space 图片之间间隔
 */
- (NSInteger)getShowViewHeightForSuperViewWidth:(NSInteger)superViewWidth andImageCount:(NSArray *)images andMediaType:(NSInteger)mediaType andImageSpace:(NSInteger)space;



@end
