//
//  YCYMultipleSelectionView.m
//  PintuangouPro
//
//  Created by yangchengyou on 17/1/22.
//  Copyright © 2017年 zipingfang. All rights reserved.
//

#import "YCYMultipleSelectionView.h"

#define cellHeight 45.0

@interface YCYMultipleSelectionView ()
{
    UIButton *_maskView;//蒙版
}
@property (nonatomic,retain) NSMutableArray *dataSource;

@end
@implementation YCYMultipleSelectionView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (instancetype)initDataSource:(NSArray *)array{
    CGRect frame = CGRectMake(YCYScreen_Width - 130 -16, 64 + 3 , 130, cellHeight * array.count/2 + 5);
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor clearColor];
        self.dataSource = [[NSMutableArray alloc] initWithArray:array];
        UIImageView *imageView = [[UIImageView alloc] init];
        imageView.frame = CGRectMake(0, 5, self.ycy_width, self.ycy_height - 5);
//        imageView.layer.borderWidth = 1;
//        imageView.layer.borderColor = LineCOLOR.CGColor;
        imageView.backgroundColor = [UIColor clearColor];
        imageView.image = [UIImage imageNamed:@"b1_tanchuang"];
        [self addSubview:imageView];
    }
    return self;
}

- (void)showInView{
    UIView *rootView = [[UIApplication sharedApplication] keyWindow].rootViewController.view;
    
    
    _maskView = [UIButton buttonWithType:UIButtonTypeCustom];
    _maskView.frame = [UIScreen mainScreen].bounds;
    [_maskView setTitle:@"" forState:UIControlStateNormal];
    [_maskView addTarget:self action:@selector(closeThisView:) forControlEvents:UIControlEventTouchUpInside];
    _maskView.backgroundColor = [UIColor clearColor];
    _maskView.alpha = 0.4;
    [rootView addSubview:_maskView];
    
    [rootView addSubview:self];
    if (_dataSource.count < 2) {
        return;
    }
    int y = 5 + 15;
    for (int i = 0; i < _dataSource.count/2; i ++) {
        UIImageView *headerImage = [[UIImageView alloc] init];
        headerImage.frame = CGRectMake(10,y, 15, 15);
        headerImage.image = [UIImage imageNamed:_dataSource[_dataSource.count/2  + i]];
        [self addSubview:headerImage];
        
        UILabel *title = [[UILabel alloc] init];
        title.frame = CGRectMake(CGRectGetMaxX(headerImage.frame) + 13, y, 80, 15);
        title.textColor = TextCOLOR666;
        title.font = YCYFont(15);
        title.text = _dataSource[i];
        [self addSubview:title];
        
        UIButton *selectBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        selectBtn.frame = CGRectMake(0,cellHeight * i + 5,self.frame.size.width, cellHeight);
        selectBtn.tag = i + 20000;
        [selectBtn setTitle:@"" forState:UIControlStateNormal];
        selectBtn.titleLabel.font = [UIFont systemFontOfSize:15];
        [selectBtn setTitleColor:[UIColor ycy_colorWithHex:0xdf3032] forState:UIControlStateNormal];
        [selectBtn addTarget:self action:@selector(selectedBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:selectBtn];
        
        y +=  cellHeight;
        
        if (i < _dataSource.count/2 -1) {
            UIView *lineView = [[UIView alloc] init];
            lineView.frame = CGRectMake(0, cellHeight * (i + 1) + 5, self.frame.size.width,1);
            lineView.backgroundColor = LineCOLOR;
            [self addSubview:lineView];
        }
    }
}

- (void)selectedBtnAction:(UIButton *)sender{
    
    if ([_delegate respondsToSelector:@selector(ycyMultipleSelectionView:didSelectRow:)]) {
        [_delegate ycyMultipleSelectionView:self didSelectRow:sender.tag - 20000];
    }
    _delegate = nil;
    [_maskView removeFromSuperview];
    [self removeFromSuperview];
}

- (void)closeThisView:(UIButton *)sender{
    _delegate = nil;
    [_maskView removeFromSuperview];
    [self removeFromSuperview];
}

@end
