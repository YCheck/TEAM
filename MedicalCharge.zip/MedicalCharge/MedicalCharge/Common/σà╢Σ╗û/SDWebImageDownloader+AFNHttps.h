//
//  SDWebImageDownloader+AFNHttps.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/28.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "SDWebImageDownloader.h"

@interface SDWebImageDownloader (AFNHttps)<NSURLSessionDelegate>

@end
