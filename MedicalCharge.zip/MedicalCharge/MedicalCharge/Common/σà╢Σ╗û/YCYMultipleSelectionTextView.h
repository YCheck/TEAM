//
//  YCYMultipleSelectionView.h
//  PintuangouPro
//
//  Created by yangchengyou on 17/1/22.
//  Copyright © 2017年 zipingfang. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol YCYMultipleSelectionTextViewDelegate <NSObject,UITableViewDelegate>

- (void)closeViewForClickSpaceView;//点击空白处回收

- (void)ycyMultipleSelectionTextView:(UIView *)multView didSelectRow:(NSInteger)index;

@end
@interface YCYMultipleSelectionTextView : UIView

@property (nonatomic,assign) id<YCYMultipleSelectionTextViewDelegate> delegate;

/**
 初始化

 @param array 数据源   格式如：（@"标题",@"标题"...   @"图片名",...）
 @return 多选窗口
 */
- (instancetype)initDataSource:(NSArray *)array andDefaultSelectedTitle:(NSString *)title;

- (void)showInView;

@end
