//
//  YCYPhotoSortView.m
//  SocialApp
//
//  Created by yangchengyou on 17/2/23.
//  Copyright © 2017年 NULLS. All rights reserved.
//

#import "YCYPhotoSortView.h"
#import "CycleScrollViewController.h"
#import <MediaPlayer/MediaPlayer.h>
@interface YCYPhotoSortView ()
{
    NSInteger _imageW;
    NSInteger _viewH; //
    NSInteger _imageH;
    NSInteger _space;
    NSArray *_images;
    NSInteger _mediaType;
}
@end

@implementation YCYPhotoSortView

- (instancetype)init{
    if (self = [super init]) {
        _viewH = 0;
        _imageW = 0;
        _imageH = 0;
        _space = 0;
        _images = [NSArray array];
        _mediaType = 1;
    }
    return self;
}

- (void)initWithInterface{
    if (_mediaType == 2) {
        if (_imageH == 0) {
            return;
        }
        
        NSString *imageUrl = [_images[0] stringByReplacingOccurrencesOfString:@".mp4" withString:@".jpg"];
        
        UIImageView *imageView = [[UIImageView alloc] init];
        imageView.frame = CGRectMake(0, 0, _imageW, _imageH);
        [imageView py_setImageWithURL:YCYImageURL(imageUrl) placeholderImage:DefaultImage];
        imageView.contentMode = UIViewContentModeScaleAspectFill;
        imageView.clipsToBounds = YES;
        [self addSubview:imageView];
//     dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
//            //获取视频的thumbnail
//            MPMoviePlayerController *player = [[MPMoviePlayerController alloc]initWithContentURL:YCYImageURL(_images[0])];
//            UIImage  *thumbnail = [player thumbnailImageAtTime:1.0 timeOption:MPMovieTimeOptionNearestKeyFrame];
//            player = nil;
//            if (thumbnail != nil) {
//                // 在主线程中完成UI操作
//                dispatch_async(dispatch_get_main_queue(), ^{
//                    imageView.image = thumbnail;
//                });
//            }else{
//
//            }
//        });
        
        UIButton *playBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        playBtn.frame = CGRectMake(0, 0, 50, 50);
        [playBtn setImage:YCYImage(@"b4_shipin2") forState:UIControlStateNormal];
        playBtn.center = imageView.center;
        [playBtn addTarget:self action:@selector(playVideo) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:playBtn];
        
    }else{
        NSInteger x = 0,y = 0;NSInteger imageCount = _images.count<10?_images.count:9;
        for (int i = 0; i < imageCount; i ++) {
            UIImageView *imageView = [[UIImageView alloc] init];
            imageView.tag = i + 1;
            imageView.frame = CGRectMake(x, y, _imageW, _imageH);
            imageView.contentMode = UIViewContentModeScaleAspectFill;
            imageView.clipsToBounds = YES;
//            imageView.backgroundColor = [UIColor lightGrayColor];
            imageView.userInteractionEnabled = YES;
            [imageView py_setImageWithURL:YCYImageURL(_images[i]) placeholderImage:YCYDefaultImage];
            //        NSLog(@"-----%@",YCYImageURL(_images[i]));
            [self addSubview:imageView];
            //添加单击手势
            UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGestureAction:)];
            [imageView addGestureRecognizer:tapGesture];
            
            if (imageCount == 2) {
                x += _space + _imageH;
            }else if (imageCount == 3){
                x += _space + _imageH;
            }else if (imageCount >3 && imageCount < 5){
                x += _space + _imageH;
                if (i == 1) {
                    x = 0;
                    y += _space + _imageH;
                }
            }else if (imageCount >= 5 && imageCount < 7){
                x += _space + _imageH;
                if (i == 2) {
                    x = 0;
                    y += _space + _imageH;
                }
            }else if (imageCount >= 7){
                x += _space + _imageH;
                if (i == 2) {
                    x = 0;
                    y += _space + _imageH;
                }else if (i == 5){
                    x = 0;
                    y += _space + _imageH;
                }
            }
        }
    }
}

- (void)tapGestureAction:(UITapGestureRecognizer *)recognizer{
    int index = (int)recognizer.view.tag - 1;

    NSMutableArray *imageArray = [NSMutableArray array];
    for (NSString *imageUrl in _images) {
        [imageArray addObject:YCYImageURLStr(imageUrl)];
    }
    
    CycleScrollViewController *cycleImageScrollView = [[CycleScrollViewController alloc] initWithMixids:imageArray currentIndex:index];
    [[self viewController] presentViewController:cycleImageScrollView animated:YES completion:nil];
}

- (NSInteger)getShowViewHeightForSuperViewWidth:(NSInteger)superViewWidth andImageCount:(NSArray *)images andMediaType:(NSInteger)mediaType andImageSpace:(NSInteger)space{
    
    NSInteger imageCount = images.count;
    _mediaType = mediaType;
    _images = images;
    _space = space;
    if (imageCount == 0) {
        return _viewH;
    }
    if (imageCount == 1 && ([images[0] isEqualToString:@""] || images[0] == nil)) {
        return _viewH;
    }
    if (imageCount == 1) {
        _imageH = superViewWidth;
        _viewH = _imageH;
        _imageW = superViewWidth;
    }if (imageCount == 2) {
        _imageH = (superViewWidth - space)/2;
        _viewH = _imageH;
        _imageW = _imageH;
    }else if (imageCount == 3) {
        _imageH = (superViewWidth - 2 * space)/3;
        _viewH = _imageH;
        _imageW = _imageH;
    }else if(imageCount >3 && imageCount < 5){
        _imageH = (superViewWidth - space)/2;
        _viewH = _imageH * 2 + space;
        _imageW = _imageH;
    }else if(imageCount >= 5 && imageCount < 7){
        _imageH = (superViewWidth - 2 * space)/3;
        _viewH = _imageH * 2 + space;
        _imageW = _imageH;
    }else if(imageCount >= 7){
        _imageH = (superViewWidth - 2 * space)/3;
        _viewH = _imageH * 3 + 2 * space;
        _imageW = _imageH;
    }
    
    return _viewH;
}

- (void)playVideo{
    MPMoviePlayerViewController *mPMoviePlayerViewController;
    mPMoviePlayerViewController = [[MPMoviePlayerViewController alloc]initWithContentURL:YCYImageURL(_images[0])];
    [[self viewController] presentViewController:mPMoviePlayerViewController animated:YES completion:nil];
}

//获取父类
- (UIViewController*)viewController {
    for (UIView* next = [self superview]; next; next = next.superview) {
        UIResponder* nextResponder = [next nextResponder];
        if ([nextResponder isKindOfClass:[UIViewController class]]) {
            return (UIViewController*)nextResponder;
        }
    }
    return nil;
}

@end
