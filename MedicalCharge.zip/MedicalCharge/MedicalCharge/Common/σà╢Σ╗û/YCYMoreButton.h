//
//  YCYMoreButton.h
//  Social
//
//  Created by yangchengyou on 2018/2/7.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol YCYMoreButtonDelegate <NSObject,UITableViewDelegate>

- (void)ycyMoreButtonView:(UIView *)multView didSelectRow:(NSInteger)index andSelectData:(id)selectData;

@end

@interface YCYMoreButton : UIView

@property (nonatomic,assign) id<YCYMoreButtonDelegate> delegate;


/**
 选择列表
 
 @param array 数据源 如 @[@"标题",@"标题"]
 @param view 根据此view来确定所显示列表的位置  （取view的x，y，width属性）
 @return 选项列表
 */
- (instancetype)initDataSource:(NSArray *)array andRelativeView:(UIView *)view andIsRightTop:(BOOL)isTop;

/**
 显示该view
 */
- (void)showInView;

@end
