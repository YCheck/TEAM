//
//  ClaimsTableViewCell.m
//  SocialApp
//
//  Created by yangchengyou on 17/2/23.
//  Copyright © 2017年 NULLS. All rights reserved.
//

#import "ClaimsTableViewCell.h"

@implementation ClaimsTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)configureForCell:(NSDictionary *)dic{
    self.titleLabel.text = dic[@"remarks"];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
