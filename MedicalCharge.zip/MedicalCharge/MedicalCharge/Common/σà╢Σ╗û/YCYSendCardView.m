//
//  YCYSendCardView.m
//  Social
//
//  Created by yangchengyou on 2017/11/20.
//  Copyright © 2017年 NULLS. All rights reserved.
//

#import "YCYSendCardView.h"
@interface YCYSendCardView()<UITextViewDelegate>
{
    BOOL _isCloseBtn;
    BOOL _isCancelBtn;
    NSString *_title;
//    CoreObject_Friend *_friendModel;
    UIButton *_bgBtn;
    NSInteger _contentHeight;
    UITextField *_textField;
}
@property (nonatomic,retain) UITextView *textView;//输入框

@end
@implementation YCYSendCardView

- (instancetype)initWithTarget:(id<YCYSendCardViewDelegate>)delegate andContent:(NSDictionary *)friendModel{
    //    _contentHeight = [content ycy_heightWithFont:YCYFont(15) constrainedToWidth:310];
    NSInteger height = 230;
    
    CGRect frame = CGRectMake(15,(YCYScreen_Height - height)/2, YCYScreen_Width - 30,height);
    if (self = [super initWithFrame:frame]) {
        [self ycy_cornerRadius:4 strokeSize:0 color:nil];
        self.backgroundColor = [UIColor whiteColor];
        self.clipsToBounds = YES;
        self.delegate = delegate;
//        _friendModel = friendModel;
    }
    return self;
}

- (void)showView{
    [self showWindow];
}


- (void)showWindow{
    UIView *rootView = YCYWindow;
    //    rootView.hidden = NO;
    
    _bgBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    _bgBtn.tag=12121313;
    _bgBtn.frame = rootView.bounds;
    [_bgBtn setTitle:@"" forState:UIControlStateNormal];
    [_bgBtn addTarget:self action:@selector(closeSelfView) forControlEvents:UIControlEventTouchUpInside];
    [_bgBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    _bgBtn.backgroundColor=[[UIColor blackColor]colorWithAlphaComponent:0.3];
    [rootView addSubview:_bgBtn];
    
    UIImageView *headerImage = [[UIImageView alloc] init];
    headerImage.frame = CGRectMake(22, 30, 50, 50);
    headerImage.layer.cornerRadius = 2;
    headerImage.backgroundColor = [UIColor lightGrayColor];
    headerImage.clipsToBounds = YES;
    headerImage.contentMode = UIViewContentModeScaleAspectFill;
//    [headerImage py_setImageWithURL:YCYImageURL(_friendModel.face) placeholderImage:HeaderDefaultImage];
    [self addSubview:headerImage];
    
    UILabel *titleLabel = [[UILabel alloc]init];
    titleLabel.frame = CGRectMake(CGRectGetMaxX(headerImage.frame) + 10, 30, self.ycy_width - 100, 24);
    titleLabel.font = YCYFont(17);
    titleLabel.textColor = TextCOLOR333;
    titleLabel.textAlignment=NSTextAlignmentLeft;
    titleLabel.numberOfLines = 1;
//    titleLabel.text = _friendModel.comment;
    [self addSubview:titleLabel];
    
    UILabel *nickname = [[UILabel alloc]init];
    nickname.frame = CGRectMake(CGRectGetMaxX(headerImage.frame) + 10, CGRectGetMaxY(titleLabel.frame) + 4, self.ycy_width - 100, 21);
    nickname.font = YCYFont(15);
    nickname.textColor = TextCOLOR999;
    nickname.textAlignment=NSTextAlignmentLeft;
    nickname.numberOfLines = 1;
//    nickname.text = _friendModel.nickname;
    [self addSubview:nickname];
    
    UITextView *textView = [[UITextView alloc] init];
    textView.frame = CGRectMake(22, CGRectGetMaxY(headerImage.frame) + 20, self.ycy_width - 44, 60);
    textView.placeholder = @"给用户留言";
    textView.textColor = TextCOLOR666;
    textView.layer.borderWidth = 1;
    textView.font = YCYFont(15);
    textView.returnKeyType = UIReturnKeyDone;
    textView.tintColor = TextCOLOR666;
    textView.delegate = self;
    textView.layer.borderColor = YCYHexColor(@"dddddd").CGColor;
    [self addSubview:textView];
    self.textView = textView;
    
    //    UIView *lineView = [[UIView alloc] init];
    //    lineView.frame = CGRectMake(0, CGRectGetMaxY(textView.frame) + 27, self.ycy_width, 0.5);
    //    lineView.backgroundColor = YCYHexColor(@"aaaaaa");
    //    [self addSubview:lineView];
    
    UIButton *closeBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    closeBtn.frame = CGRectMake(0, self.ycy_height - 50, self.ycy_width/2 - 0.5, 50);
    [closeBtn addTarget:self action:@selector(closeSelfView) forControlEvents:UIControlEventTouchUpInside];
    [closeBtn setTitle:@"取消" forState:UIControlStateNormal];
    [closeBtn setTitleColor:TextCOLOR333 forState:UIControlStateNormal];
    closeBtn.titleLabel.font = YCYFont(17);
    closeBtn.backgroundColor = YCYHexColor(@"f7f7f7");
    //    [closeBtn setImage:YCYImage(@"close-big-icon") forState:UIControlStateNormal];
    [self addSubview:closeBtn];
    
    UIButton *sureBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    sureBtn.frame = CGRectMake(self.ycy_width/2 + 0.5, self.ycy_height - 50, self.ycy_width/2 - 0.5, 50);
    [sureBtn addTarget:self action:@selector(clickSureBtn:) forControlEvents:UIControlEventTouchUpInside];
    [sureBtn setTitle:@"发送" forState:UIControlStateNormal];
    [sureBtn setTitleColor:TextCOLOR333 forState:UIControlStateNormal];
    sureBtn.titleLabel.font = YCYFont(17);
    sureBtn.backgroundColor = YCYHexColor(@"eeeeee");
    [self addSubview:sureBtn];
    
    [rootView addSubview:self];
    
}

- (void)closeSelfView{
    
    [_bgBtn removeFromSuperview];
    self.textView.delegate = nil;
    [self removeFromSuperview];
}

- (void)clickSureBtn:(UIButton *)sender{
    if ([_delegate respondsToSelector:@selector(ycySendCardViewForRemark:andSelectedIndex:)]){
        [self.delegate ycySendCardViewForRemark:self.textView.text andSelectedIndex:1];
    }
    [self disMissView];
}


//- (void)clickSaveBtn:(UIButton *)sender{
//    if ([_delegate respondsToSelector:@selector(showHUDViewSelectedIndex:)]) {
//        [self.delegate showHUDViewSelectedIndex:1];
//    }
//    [self disMissView];
//}

- (void)disMissView{
    [self closeSelfView];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    if ([text isEqualToString:@"\n"]){
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}

- (void)textViewDidChange:(UITextView *)textView{
    if (self.textView.text.length > 30) {
        self.textView.text = [self.textView.text substringToIndex:30];
    }
}

@end
