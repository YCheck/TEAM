//
//  YCYMakingCardMoneyView.m
//  Social
//
//  Created by yangchengyou on 2017/12/5.
//  Copyright © 2017年 NULLS. All rights reserved.
//

#import "YCYMakingCardMoneyView.h"
@interface YCYMakingCardMoneyView()<UITextViewDelegate>
{
    BOOL _isCloseBtn;
    BOOL _isCancelBtn;
    NSString *_title;
    NSString *_content;
    UIButton *_bgBtn;
    NSInteger _contentHeight;
    UITextField *_textField;
}
@property (nonatomic,retain) UITextView *textView;//输入框

@end
@implementation YCYMakingCardMoneyView

- (instancetype)initWithTarget:(id<YCYMakingCardMoneyViewDelegate>)delegate andContent:(NSString *)content{
    //    _contentHeight = [content ycy_heightWithFont:YCYFont(15) constrainedToWidth:310];
    NSInteger height = 180;
    
    CGRect frame = CGRectMake(15,(YCYScreen_Height - height)/2, YCYScreen_Width - 30,height);
    if (self = [super initWithFrame:frame]) {
        [self ycy_cornerRadius:4 strokeSize:0 color:nil];
        self.backgroundColor = [UIColor whiteColor];
        self.clipsToBounds = YES;
        self.delegate = delegate;
        _content = content;
    }
    return self;
}

- (void)showView{
    [self showWindow];
}


- (void)showWindow{
    UIView *rootView = YCYWindow;
    //    rootView.hidden = NO;
    
    _bgBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    _bgBtn.tag=12121313;
    _bgBtn.frame = rootView.bounds;
    [_bgBtn setTitle:@"" forState:UIControlStateNormal];
    [_bgBtn addTarget:self action:@selector(closeSelfView) forControlEvents:UIControlEventTouchUpInside];
    [_bgBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    _bgBtn.backgroundColor=[[UIColor blackColor]colorWithAlphaComponent:0.3];
    [rootView addSubview:_bgBtn];
    
    UILabel *titleLabel = [[UILabel alloc]init];
    titleLabel.frame = CGRectMake(15, 15, self.ycy_width - 30, 24);
    titleLabel.font = YCYFont(17);
    titleLabel.textColor = TextCOLOR333;
    titleLabel.textAlignment=NSTextAlignmentCenter;
    titleLabel.numberOfLines = 0;
    titleLabel.text = self.titleString;
    [self addSubview:titleLabel];
    
    UITextView *textView = [[UITextView alloc] init];
    textView.frame = CGRectMake(24, CGRectGetMaxY(titleLabel.frame) + 15, self.ycy_width - 48, 50);
    textView.placeholder = self.placeHolder;
    if (!self.placeHolder) {
        textView.textAlignment = NSTextAlignmentCenter;
    }else{
        textView.textAlignment = NSTextAlignmentLeft;
    }
    textView.text = _content;
    textView.textColor = TextCOLOR666;
    textView.textContainerInset = UIEdgeInsetsMake(15, 0, 0, 0);
    textView.layer.borderWidth = 1;
    textView.font = YCYFont(15);
    textView.returnKeyType = UIReturnKeyDone;
    textView.tintColor = TextCOLOR666;
    textView.delegate = self;
    textView.userInteractionEnabled = self.userInputEnable;
    textView.layer.borderColor = YCYHexColor(@"dddddd").CGColor;
    [textView resignFirstResponder];
    [self addSubview:textView];
    self.textView = textView;
    
    //    UIView *lineView = [[UIView alloc] init];
    //    lineView.frame = CGRectMake(0, CGRectGetMaxY(textView.frame) + 27, self.ycy_width, 0.5);
    //    lineView.backgroundColor = YCYHexColor(@"aaaaaa");
    //    [self addSubview:lineView];
    
    UIButton *closeBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    closeBtn.frame = CGRectMake(0, self.ycy_height - 50, self.ycy_width/2 - 0.5, 50);
    [closeBtn addTarget:self action:@selector(closeSelfView) forControlEvents:UIControlEventTouchUpInside];
    [closeBtn setTitle:@"取消" forState:UIControlStateNormal];
    [closeBtn setTitleColor:TextCOLOR333 forState:UIControlStateNormal];
    closeBtn.titleLabel.font = YCYFont(17);
    closeBtn.backgroundColor = YCYHexColor(@"f7f7f7");
    //    [closeBtn setImage:YCYImage(@"close-big-icon") forState:UIControlStateNormal];
    [self addSubview:closeBtn];
    
    UIButton *sureBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    sureBtn.frame = CGRectMake(self.ycy_width/2 + 0.5, self.ycy_height - 50, self.ycy_width/2 - 0.5, 50);
    [sureBtn addTarget:self action:@selector(clickSureBtn:) forControlEvents:UIControlEventTouchUpInside];
    
    if (!self.sureButtonString) {
        [sureBtn setTitle:@"打赏" forState:UIControlStateNormal];
    }else{
        [sureBtn setTitle:self.sureButtonString forState:UIControlStateNormal];
    }
    [sureBtn setTitleColor:TextCOLOR333 forState:UIControlStateNormal];
    sureBtn.titleLabel.font = YCYFont(17);
    sureBtn.backgroundColor = YCYHexColor(@"eeeeee");
    [self addSubview:sureBtn];
    
    [rootView addSubview:self];
    
}

- (void)closeSelfView{
    
    [_bgBtn removeFromSuperview];
    self.textView.delegate = nil;
    [self removeFromSuperview];
}

- (void)clickSureBtn:(UIButton *)sender{
    if ([_delegate respondsToSelector:@selector(ycyMakingCardMoneyView:andSelectedIndex:)]) {
        [self.delegate ycyMakingCardMoneyView:self.textView.text andSelectedIndex:1];
    }
    [self disMissView];
}



//- (void)clickSaveBtn:(UIButton *)sender{
//    if ([_delegate respondsToSelector:@selector(showHUDViewSelectedIndex:)]) {
//        [self.delegate showHUDViewSelectedIndex:1];
//    }
//    [self disMissView];
//}

- (void)disMissView{
    [self closeSelfView];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    if ([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}

- (void)textViewDidChange:(UITextView *)textView{
    if (self.textView.text.length > 20) {
        self.textView.text = [self.textView.text substringToIndex:20];
    }
}

@end
