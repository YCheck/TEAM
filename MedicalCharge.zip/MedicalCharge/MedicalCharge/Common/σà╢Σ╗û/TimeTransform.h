//
//  TimeTransform.h
//  Artselleasy
//
//  Created by admin on 15/6/11.
//  Copyright (c) 2015年 faith. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TimeTransform : NSObject
+(NSString *)overTime:(id)longTime;
+ (NSTimeInterval)nowTimeInterval;


+(NSString *)dateToTimeHM:(id)longTime;
+(NSString *)auctionTimeYMDHMS:(id)longTime;
+(NSString *)dateToTimeYMDHM:(id)longTime;
+(NSString *)dateToTimeYMD:(id)longTime;
+(NSString *)dateToTimeD:(id)longTime;
//返回中文年月日
+(NSString *)dateToTimeForChineseYMD:(id)longTime;
+(NSString *)dateToTimeForChineseYM:(id)longTime;
+(NSString *)dateToTimeForChineseCurrentWeek:(id)longTime;//返回本周1--本周末日期

//传入date
+(NSString *)getHMStringForDate:(NSDate *)date;
+(NSString *)getHMSStringForDate:(NSDate *)date;
+(NSString *)getYMDStringForDate:(NSDate *)date;

+(NSString *)dateToTimeYMDWeek:(id)longTime;//返回年月日+星期*
//返回当前年份
+(NSString *)nowYear;
//返回当前月份
+(NSString *)nowMonth;
//返回年月日
+(NSString *)nowYMDHM;
//返回年月日
+(NSString *)nowYMD;
//返回时间
+(NSString *)nowHM;
//字符串转时间
+ (NSTimeInterval)timeStringTransformTimeInterval:(NSString *)str;
//字符串转时间
+ (NSTimeInterval)timeStringYMDHMSTransformTimeInterval:(NSString *)str;

/**
 时间差 (分钟)

 @param startTime 开始时间（秒）
 @param endTime 结束时间（秒）
 @return 时间差  分钟
 */
+ (NSTimeInterval)timeDifferenceStartTime:(id)startTime endTime:(id)endTime;

/**
 时间字符串样式转换yyyy-m-dd  ->    yyyy-mm-dd

 @param dateStr 时间字符串
 @return 时间格式转换
 */
+ (NSString *)dateFormatterTransform:(NSString *)dateStr;

//如果显示在一天内 显示xx分钟之前  一天后显示日期

/**
 如果显示在一天内 显示xx分钟之前  一天后显示日期
 
 @param longTime 时间戳 秒
 @return 时间格式
 */
+ (NSString *)dynamicTimeStrFromTimeInterval:(id)longTime;

+ (NSString *)timeSubstringYMD:(NSString *)timeString;

@end
