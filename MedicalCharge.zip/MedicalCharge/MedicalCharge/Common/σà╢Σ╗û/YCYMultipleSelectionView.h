//
//  YCYMultipleSelectionView.h
//  PintuangouPro
//
//  Created by yangchengyou on 17/1/22.
//  Copyright © 2017年 zipingfang. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol YCYMultipleSelectionViewDelegate <NSObject,UITableViewDelegate>

- (void)ycyMultipleSelectionView:(UIView *)multView didSelectRow:(NSInteger)index;

@end
@interface YCYMultipleSelectionView : UIView

@property (nonatomic,assign) id<YCYMultipleSelectionViewDelegate> delegate;

/**
 初始化

 @param array 数据源   格式如：（@"标题",@"标题"...   @"图片名",...）
 @return 多选窗口
 */
- (instancetype)initDataSource:(NSArray *)array;

- (void)showInView;

@end
