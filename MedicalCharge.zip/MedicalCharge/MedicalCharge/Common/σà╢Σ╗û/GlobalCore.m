//
//  GlobalCore.m
//  Weibo
//
//  Created by junmin liu on 10-9-29.
//  Copyright 2010 Openlab. All rights reserved.
//

#import "GlobalCore.h"
#import <UIKit/UIKit.h>

//@implementation GlobalCore

// No-ops for non-retaining objects.
//static const void* RetainNoOp(CFAllocatorRef allocator, const void *value) { return value; }
//static void ReleaseNoOp(CFAllocatorRef allocator, const void *value) { }

BOOL IsStringWithAnyText(id object) {
	return [object isKindOfClass:[NSString class]] && [(NSString*)object length] > 0;
}

//如果为空 返回yes
BOOL IsEmpty(id object) {
    return object == nil
    || ([object isKindOfClass:[NSNull class]])
    || ([object respondsToSelector:@selector(length)]
        && [(NSData *)object length] == 0)
    || ([object respondsToSelector:@selector(count)]
        && [(NSArray *)object count] == 0)
    || ([object isKindOfClass:[NSString class]]
        && [object isEqualToString:@"<null>"]);
}

NSString* emptyTransform(NSString *str){
    NSString *empty = @"";
    if ((id)str == [NSNull null] || str == nil || [str isEqualToString:@"(null)"] || [str isEqualToString:@"<null>"]) {
        empty = @"";
    }else{
        empty = str;
    }
    return empty;
}

BOOL IsLocationNotification(){
    CLAuthorizationStatus status = [CLLocationManager authorizationStatus];
    return kCLAuthorizationStatusDenied == status || kCLAuthorizationStatusRestricted == status;
}

time_t convertTimeStamp(NSString *stringTime) {
	// Convert timestamp string to UNIX time
    //
	time_t createdAt = 0;
    struct tm created;
    time_t now;
    time(&now);
    
    if (stringTime) {
		if (strptime([stringTime UTF8String], "%a %b %d %H:%M:%S %z %Y", &created) == NULL) {
			strptime([stringTime UTF8String], "%a, %d %b %Y %H:%M:%S %z", &created);
		}
		createdAt = mktime(&created);
	}
	return createdAt;
}

#pragma mark -
#pragma mark Path
///////////////////////////////////////////////////////////////////////////////////////////////////
BOOL IsBundleURL(NSString* URL) {
	return [URL hasPrefix:@"bundle://"];
}

///////////////////////////////////////////////////////////////////////////////////////////////////
BOOL IsDocumentsURL(NSString* URL) {
	return [URL hasPrefix:@"documents://"];
}

BOOL IsHttpURL(NSString* URL) {
	return [URL hasPrefix:@"http://"] || [URL hasPrefix:@"https://"];
}

///////////////////////////////////////////////////////////////////////////////////////////////////
NSString* PathForBundleResource(NSString* relativePath) {
	NSString* resourcePath = [[NSBundle mainBundle] resourcePath];
	return [resourcePath stringByAppendingPathComponent:relativePath];
}

///////////////////////////////////////////////////////////////////////////////////////////////////
NSString* PathForDocumentsResource(NSString* relativePath) {
	static NSString* documentsPath = nil;
	if (!documentsPath) {
		NSArray* dirs = NSSearchPathForDirectoriesInDomains(
															NSDocumentDirectory, NSUserDomainMask, YES);
		documentsPath = [dirs objectAtIndex:0];
	}
	return [documentsPath stringByAppendingPathComponent:relativePath];
}
