//
//  YCYMoreButton.m
//  Social
//
//  Created by yangchengyou on 2018/2/7.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YCYMoreButton.h"
#define cellHeight 45 //每排高
#define ShowViewW 120 //弹框width
#define TopSpace 3 //距离navigation
#define ArrowsH 6 //箭头的高
#define ArrowsW 6//箭头的K宽
@interface YCYMoreButton ()
{
    UIButton *_maskView;//蒙版
    NSString *_titleName;
}

@property (nonatomic,retain) NSMutableArray *dataSource;

@end
@implementation YCYMoreButton

- (instancetype)initDataSource:(NSArray *)array andRelativeView:(UIView *)view andIsRightTop:(BOOL)isTop{
    CGRect frame = [view convertRect:YCYWindow.frame toView:nil];
    NSInteger count = array.count;
    NSInteger yOrigin = frame.origin.y + view.ycy_height/4 * 3;
    if (isTop) {
        yOrigin = CGRectGetMaxY(frame) + 3;
    }
    CGRect rframe = CGRectMake(frame.origin.x - 90,yOrigin,ShowViewW,cellHeight * count  + ArrowsH + TopSpace);
    if (self = [super initWithFrame:rframe]){
        self.backgroundColor = [UIColor clearColor];
        self.dataSource = [[NSMutableArray alloc] initWithArray:array];
        
        UIImageView *imageView = [[UIImageView alloc] init];
        imageView.frame = CGRectMake(0, 3, self.ycy_width, self.ycy_height - 3);
        //        imageView.layer.borderWidth = 1;
        //        imageView.layer.borderColor = LineCOLOR.CGColor;
        imageView.backgroundColor = [UIColor clearColor];
        imageView.image = [UIImage imageNamed:@"moreView"];
        [self addSubview:imageView];
    }
    return self;
}

- (void)showInView{
    UIView *rootView = [[UIApplication sharedApplication] keyWindow].rootViewController.view;
    
    _maskView = [UIButton buttonWithType:UIButtonTypeCustom];
    _maskView.frame = [UIScreen mainScreen].bounds;
    [_maskView setTitle:@"" forState:UIControlStateNormal];
    [_maskView addTarget:self action:@selector(closeThisView:) forControlEvents:UIControlEventTouchUpInside];
    _maskView.backgroundColor = [UIColor clearColor];
    _maskView.alpha = 1;
    [rootView addSubview:_maskView];
    
    [rootView addSubview:self];
    if (_dataSource.count < 1) {
        return;
    }
    int y = ArrowsH + TopSpace;
    for (int i = 0; i < _dataSource.count; i ++) {
        //        UIImageView *headerImage = [[UIImageView alloc] init];
        //        headerImage.frame = CGRectMake(19,y, 15, 15);
        //        headerImage.image = [UIImage imageNamed:_dataSource[_dataSource.count/2  + i]];
        //        [self addSubview:headerImage];
        
        UILabel *title = [[UILabel alloc] init];
        title.frame = CGRectMake(0, y, ShowViewW, cellHeight);
        title.textColor = TextCOLOR333;
        title.font = YCYFont(15);
        title.textAlignment = NSTextAlignmentCenter;
        title.text = _dataSource[i];
        [self addSubview:title];
        
        if ([_dataSource[i] isEqualToString:_titleName]) {
            title.textColor = TextCOLOR333;
        }
        
        UIButton *selectBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        selectBtn.frame = CGRectMake(0,cellHeight * i + ArrowsH + TopSpace,self.frame.size.width, cellHeight);
        selectBtn.tag = i + 20000;
        [selectBtn setTitle:@"" forState:UIControlStateNormal];
        selectBtn.titleLabel.font = YCYFont(14);
        [selectBtn setTitleColor:[UIColor ycy_colorWithHex:0xdf3032] forState:UIControlStateNormal];
        [selectBtn addTarget:self action:@selector(selectedBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:selectBtn];
        
        y +=  cellHeight;
        
        if (i < _dataSource.count -1) {
            UIView *lineView = [[UIView alloc] init];
            lineView.frame = CGRectMake(0, cellHeight * (i + 1) + ArrowsH + TopSpace, self.frame.size.width ,1);
            lineView.backgroundColor = LineCOLOR;
            [self addSubview:lineView];
        }
        
    }
}

- (void)selectedBtnAction:(UIButton *)sender{
    
    if ([_delegate respondsToSelector:@selector(ycyMoreButtonView:didSelectRow:andSelectData:)]) {
        
        [_delegate ycyMoreButtonView:self didSelectRow:sender.tag - 20000 andSelectData:nil];
    }
    _delegate = nil;
    [_maskView removeFromSuperview];
    [self removeFromSuperview];
}

- (void)closeThisView:(UIButton *)sender{
    _delegate = nil;
    [_maskView removeFromSuperview];
    [self removeFromSuperview];
}

@end
