//
//  YCYChooseMaintenancePersonnel.h
//  ManagerApp
//
//  Created by yangchengyou on 17/8/31.
//  Copyright © 2017年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol YCYAuthenticationInformationDelegate <NSObject>

- (void)ycyYCYAuthenticationInformation:(NSString *)content andSelectedIndex:(NSInteger)index;

@end
@interface YCYAuthenticationInformation : UIView
@property (nonatomic,assign) id<YCYAuthenticationInformationDelegate> delegate;
@property (nonatomic,retain) UIColor *contentColor;


/**
 hud
 
 @param delegate delegate
 @param content content
 @return hud
 */
- (instancetype)initWithTarget:(id<YCYAuthenticationInformationDelegate>)delegate andContent:(NSString *)content;
- (void)showView;

- (void)disMissView;
@end
