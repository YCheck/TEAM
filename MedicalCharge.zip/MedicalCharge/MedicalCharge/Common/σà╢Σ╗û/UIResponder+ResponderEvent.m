//
//  UIResponder+ResponderEvent.m
//  ManagerApp
//
//  Created by yangchengyou on 17/9/1.
//  Copyright © 2017年 NULLS. All rights reserved.
//

#import "UIResponder+ResponderEvent.h"

@implementation UIResponder (ResponderEvent)
-(void) routerEventWithName:(NSString *)eventName dataInfo:(NSDictionary *)dataInfo{
    [[self nextResponder] routerEventWithName:eventName dataInfo:dataInfo];
}
@end
