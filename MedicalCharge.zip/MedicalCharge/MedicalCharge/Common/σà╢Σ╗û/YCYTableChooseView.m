//
//  YCYTableChooseView.m
//  SocialApp
//
//  Created by yangchengyou on 17/2/22.
//  Copyright © 2017年 NULLS. All rights reserved.
//

#import "YCYTableChooseView.h"
#import "ClaimsTableViewCell.h"
#define cellHeight 30 //每排高
#define ShowViewW 270 //弹框width
#define ShowViewH 190 //弹框height
#define TopSpace 0 //距离navigation
#define ArrowsH 0 //箭头的高
#define ArrowsW 0//箭头的K宽
@interface YCYTableChooseView ()<UITableViewDelegate,UITableViewDataSource>
{
    UIButton *_maskView;//蒙版
}
@property (nonatomic,retain) NSMutableArray *dataSource;
@property (nonatomic,retain) UITableView *tableView;

@end
@implementation YCYTableChooseView

- (instancetype)initDataSource:(NSArray *)array andRelativeView:(UIView *)view{
    //
    CGRect frame = [view convertRect:YCYWindow.frame toView:nil];
//    NSInteger count = array.count > 3? 3:array.count;
    NSInteger originY = 0;
    NSInteger sum = frame.origin.y - YCYScreen_Height/2;
    if (sum > 0) {
        originY = frame.origin.y - ShowViewH;
    }else{
        originY = frame.origin.y + 35;
    }
    
    CGRect rframe = CGRectMake((YCYScreen_Width - ShowViewW)/2,originY,ShowViewW,ShowViewH);
    if (self = [super initWithFrame:rframe]){
        self.backgroundColor = [UIColor clearColor];
        self.layer.borderWidth = 1;
        self.layer.borderColor = LineCOLOR.CGColor;
        self.dataSource = [[NSMutableArray alloc] initWithArray:array];
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0,0, self.ycy_width, 0.1)];
        [UIView animateWithDuration:0.2 animations:^{
            _tableView.frame = self.bounds;
        }];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.estimatedRowHeight = 40.0f;
        _tableView.rowHeight = UITableViewAutomaticDimension;
//        _tableView.separatorInset = UIEdgeInsetsMake(0, 0, 0, 0);
        [self addSubview:_tableView];
        [self.tableView registerNib:[ClaimsTableViewCell ycy_nib] forCellReuseIdentifier:[ClaimsTableViewCell ycy_className]];
        _tableView.bounces = NO;
    }
    return self;
}

- (void)showInView{
    if (_dataSource.count == 0) {
        [XHToast showBottomWithText:@"没有找到相应的数据~"];
        return;
    }
    UIView *rootView = [[UIApplication sharedApplication] keyWindow].rootViewController.view;
    
    _maskView = [UIButton buttonWithType:UIButtonTypeCustom];
    _maskView.frame = [UIScreen mainScreen].bounds;
    [_maskView setTitle:@"" forState:UIControlStateNormal];
    [_maskView addTarget:self action:@selector(closeThisView:) forControlEvents:UIControlEventTouchUpInside];
    _maskView.backgroundColor = [UIColor blackColor];
    _maskView.alpha = 0.2;
    [rootView addSubview:_maskView];
    
    [rootView addSubview:self];
}


- (void)closeThisView:(UIButton *)sender{
    _delegate = nil;
    _maskView.alpha = 0;
    [UIView animateWithDuration:0.1 animations:^{
        _tableView.frame = CGRectMake(0, 0, self.ycy_width, 0);
    } completion:^(BOOL finished) {
        [_maskView removeFromSuperview];
        [_tableView removeFromSuperview];
        [self removeFromSuperview];
    }];
}
#pragma mark UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    ClaimsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[ClaimsTableViewCell ycy_className] forIndexPath:indexPath];
    if (!cell) {
        cell = [[ClaimsTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:[ClaimsTableViewCell ycy_className]];
    }
    cell.titleLabel.text = self.dataSource[indexPath.row][@"title"];
    cell.contentLabel.text = self.dataSource[indexPath.row][@"content"];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
//    ClaimsTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
//    cell.selectedImage.hidden = NO;
    if ([_delegate respondsToSelector:@selector(ycyTableChooseView:didSelectRow:andSelectData:)]){
        [_delegate ycyTableChooseView:self didSelectRow:indexPath.row andSelectData:_dataSource[indexPath.row]];
    }
    
    [self closeThisView:nil];
}

//- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
//    return cellHeight;
//}

@end
