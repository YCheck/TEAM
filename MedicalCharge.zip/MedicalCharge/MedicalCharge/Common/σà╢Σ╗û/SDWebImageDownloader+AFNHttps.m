//
//  SDWebImageDownloader+AFNHttps.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/28.
//  Copyright © 2018年 NULLS. All rights reserved.
//
#import <AFNetworking.h>
#import <SDWebImageDownloader.h>
#import "SDWebImageDownloader+AFNHttps.h"

@implementation SDWebImageDownloader (AFNHttps)

+(AFSecurityPolicy *)customSecurityPolicy {
    
    //先导入证书到项目
    
    NSString *cerPath = [CHNetworkingConfig shardInstance].certificatePath;//证书的路径
    cerPath = [[NSBundle mainBundle] pathForResource:@"certificate" ofType:@"cer"];
    NSData *cerData = [NSData dataWithContentsOfFile:cerPath];
    
    //AFSSLPinningModeCertificate使用证书验证模式
    
    AFSecurityPolicy *securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeCertificate];
    
    //如果是需要验证自建证书，需要设置为YES
    
    securityPolicy.allowInvalidCertificates = NO;
    
    //validatesDomainName 是否需要验证域名，默认为YES；
    
    securityPolicy.validatesDomainName = NO;
//    NSSet * cerDataSet = [[NSSet alloc] initWithObjects:cerData,nil];
    
    securityPolicy.pinnedCertificates = @[cerData];
    
    return securityPolicy;
}

//- (void)URLSession:(NSURLSession *)session didReceiveChallenge:(NSURLAuthenticationChallenge *)challenge
//
// completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition disposition, NSURLCredential * _Nullable credential))completionHandler {
//
//    NSLog(@"证书认证");
//
//    SecTrustRef serverTrust = [[challenge protectionSpace] serverTrust];
//    BOOL isSD = [[SDWebImageDownloader customSecurityPolicy] evaluateServerTrust:serverTrust forDomain:nil];
//    NSLog(@"00000----------  %li",isSD);
//    NSURLCredential *credential = [NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust];
//    completionHandler(NSURLSessionAuthChallengePerformDefaultHandling,credential);
//
//    return [[challenge sender] useCredential:credential forAuthenticationChallenge: challenge];
//}

@end
