//
//  UIImageView+PYCache.m
//  EasyToVote
//
//  Created by gu on 16/9/19.
//  Copyright © 2016年 yp. All rights reserved.
//

#import "UIImageView+PYCache.h"
#import <SDImageCache.h>
#import <SDImageCacheConfig.h>
@implementation UIImageView (PYCache)

- (void)py_setImageWithURL:(NSURL *)url {
    [self py_setImageWithURL:url placeholderImage:nil];
}

- (void)py_setImageWithURL:(NSURL *)url placeholderImage:(UIImage *)placeholder {
    [self py_setImageWithURL:url placeholderImage:placeholder completed:nil];
}

- (void)py_setImageWithURL:(NSURL *)url placeholderImage:(UIImage *)placeholder completed:(void(^)(UIImage *cacheImage))completedBlock {
    self.image = placeholder;
    NSString *urlStr = [NSString stringWithFormat:@"%@",url];
    [[SDImageCache sharedImageCache] queryCacheOperationForKey:urlStr done:^(UIImage * _Nullable image, NSData * _Nullable data, SDImageCacheType cacheType) {
        if (image) {
            self.image = image;
            if (completedBlock) {
                completedBlock(image);
            }
        }else
        {
            self.image = placeholder;
            dispatch_async(dispatch_get_global_queue(0, 0), ^{
                NSData *data = [NSData dataWithContentsOfURL:url];
                UIImage *image = [UIImage imageWithData:data];
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (image) {
                        [[SDImageCache sharedImageCache] storeImage:image forKey:urlStr toDisk:YES completion:nil];
                        self.image = image;
                    }
                    if (completedBlock) {
                        completedBlock(image);
                    }
                });
                
            });
        }
    }];
}

@end
