//
//  YCYMakingCardMoneyView.h
//  Social
//
//  Created by yangchengyou on 2017/12/5.
//  Copyright © 2017年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol YCYMakingCardMoneyViewDelegate <NSObject>

- (void)ycyMakingCardMoneyView:(NSString *)content andSelectedIndex:(NSInteger)index;

@end
@interface YCYMakingCardMoneyView : UIView
@property (nonatomic,retain) NSString *placeHolder;
@property (nonatomic,retain) NSString *titleString;
@property (nonatomic,retain) NSString *sureButtonString;
@property (nonatomic,assign) BOOL userInputEnable;//手否可以输入
@property (nonatomic,assign) id<YCYMakingCardMoneyViewDelegate> delegate;
@property (nonatomic,retain) UIColor *contentColor;

/**
 hud
 
 @param delegate delegate
 @param content content
 @return hud
 */
- (instancetype)initWithTarget:(id<YCYMakingCardMoneyViewDelegate>)delegate andContent:(NSString *)content;
- (void)showView;

- (void)disMissView;
@end
