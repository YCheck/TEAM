//
//  UIImageView+PYCache.h
//  EasyToVote
//
//  Created by gu on 16/9/19.
//  Copyright © 2016年 yp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (PYCache)

- (void)py_setImageWithURL:(NSURL *)url;
- (void)py_setImageWithURL:(NSURL *)url placeholderImage:(UIImage *)placeholder;
- (void)py_setImageWithURL:(NSURL *)url placeholderImage:(UIImage *)placeholder completed:(void(^)(UIImage *cacheImage))completedBlock;

@end
