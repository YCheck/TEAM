//
//  YCYSendCardView.h
//  Social
//
//  Created by yangchengyou on 2017/11/20.
//  Copyright © 2017年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "CoreObject+Friend.h"
@protocol YCYSendCardViewDelegate <NSObject>

- (void)ycySendCardViewForRemark:(NSString *)content andSelectedIndex:(NSInteger)index;

@end
@interface YCYSendCardView : UIView

@property (nonatomic,assign) id<YCYSendCardViewDelegate> delegate;
@property (nonatomic,retain) UIColor *contentColor;


/**
 hud
 
 @param delegate delegate
 @param friendModel friendModel
 @return hud
 */
- (instancetype)initWithTarget:(id<YCYSendCardViewDelegate>)delegate andContent:(NSDictionary *)friendModel;
- (void)showView;

- (void)disMissView;

@end
