//
//  ClaimsTableViewCell.h
//  SocialApp
//
//  Created by yangchengyou on 17/2/23.
//  Copyright © 2017年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ClaimsTableViewCell : UITableViewCell



@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;

- (void)configureForCell:(NSDictionary *)dic;

@end
