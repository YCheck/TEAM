//
//  YZGSearchView.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/16.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
@class YZGSearchView;
@protocol YZGSearchViewDelegate <NSObject>

- (void)yzg_searchView:(YZGSearchView *)searchView searchContent:(NSString *)content andCollation:(NSInteger)sort;

@end

@interface YZGSearchView : UIView <UITextFieldDelegate>

@property (nonatomic,assign) id<YZGSearchViewDelegate> delegate;

@property (strong, nonatomic) IBOutlet UIView *view;


@property (weak, nonatomic) IBOutlet UIButton *timeButton;
@property (weak, nonatomic) IBOutlet UIButton *nameButton;
@property (weak, nonatomic) IBOutlet UIView *searchView;
@property (weak, nonatomic) IBOutlet UITextField *textField;
@property (weak, nonatomic) IBOutlet UIButton *searchButton;


@end
