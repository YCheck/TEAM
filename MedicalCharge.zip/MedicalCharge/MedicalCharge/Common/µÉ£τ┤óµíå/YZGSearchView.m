//
//  YZGSearchView.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/16.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGSearchView.h"

@implementation YZGSearchView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

//- (instancetype)init{
//    if (self == [super init]) {
//        self = [[[NSBundle mainBundle] loadNibNamed:@"YZGSearchView" owner:self options:nil] lastObject];
//    }
//    return self;
//}


- (instancetype) initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        [[NSBundle mainBundle] loadNibNamed:@"YZGSearchView" owner:self options:nil];
        self.frame = self.view.frame;
        [self addSubview:self.view];
    }
    return self;
}

- (void)awakeFromNib{
    [super awakeFromNib];
    
    self.searchView.layer.borderWidth = 0.5;
    self.searchView.layer.borderColor = LineCOLOR.CGColor;
    
    [self.timeButton setImage:YCYImage(@"desc") forState:UIControlStateNormal];
    [self.timeButton setImage:YCYImage(@"asc") forState:UIControlStateSelected];
    [self.timeButton setTitleColor:TextCOLOR666 forState:UIControlStateNormal];
    [self.timeButton setTitleColor:TextCOLOR333 forState:UIControlStateSelected];
    [self.timeButton ycy_setImagePosition:YCYImagePositionLeft spacing:5];
    
//    [self.nameButton setImage:YCYImage(@"desc") forState:UIControlStateNormal];
//    [self.nameButton setImage:YCYImage(@"asc") forState:UIControlStateSelected];
//    [self.nameButton setTitleColor:TextCOLOR666 forState:UIControlStateNormal];
//    [self.nameButton setTitleColor:TextCOLOR333 forState:UIControlStateSelected];
//    [self.nameButton ycy_setImagePosition:YCYImagePositionLeft spacing:5];
    
}

- (IBAction)timeButtonAction:(id)sender {
    self.timeButton.selected = !self.timeButton.selected;
    self.nameButton.selected = NO;
    [self searchAction];
}


- (IBAction)nameButtonAction:(id)sender {
    self.timeButton.selected = NO;
    self.nameButton.selected = YES;
    [self searchAction];
}

- (IBAction)searchButtonAction:(id)sender {
    [self endEditing:YES];
    [self searchAction];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self endEditing:YES];
    [self searchAction];
    return YES;
}

- (void)searchAction{
    
    NSInteger sort = 0;
    if (self.timeButton.selected == YES) {
        sort = 1;
    }else if (self.nameButton.selected == YES){
        sort = 2;
    }
    
    if (_delegate && [_delegate respondsToSelector:@selector(yzg_searchView:searchContent:andCollation:)]) {
        [_delegate yzg_searchView:self searchContent:self.textField.text andCollation:sort];
    }
}

@end
