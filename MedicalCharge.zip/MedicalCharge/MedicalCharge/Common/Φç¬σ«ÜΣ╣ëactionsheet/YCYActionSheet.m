//
//  YCYActionSheet.m
//  OFF GRID
//
//  Created by sunny on 2017/5/8.
//  Copyright © 2017年 NULLS. All rights reserved.
//

#import "YCYActionSheet.h"

#define ActionHeight 50.0f
#define closeBtnTag 12121313
@interface YCYActionSheet ()
{
    NSArray *_titles;
    UIButton *_bgBtn;
}
@end

@implementation YCYActionSheet

- (instancetype)initWithTarget:(id<YCYActionSheetDelegate>)delegate andTitles:(NSArray *)titles{
    CGFloat height = (titles.count + 1) * ActionHeight + 6;
    CGRect frame = CGRectMake(0, YCYScreen_Height - height, YCYScreen_Width, height);
    
    if ([super initWithFrame:frame] == self) {
        _titles = titles;
        self.backgroundColor = YCYHexColor(@"dddddd");
        self.delegate = delegate;
        
    }
    return self;
}


- (void)showView{
    [self showWindow];
}


- (void)showWindow{
    UIView *rootView = YCYWindow;
    
    _bgBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    _bgBtn.tag = closeBtnTag;
    _bgBtn.frame=rootView.bounds;
    [_bgBtn setTitle:@"" forState:UIControlStateNormal];
    [_bgBtn addTarget:self action:@selector(closeSelf) forControlEvents:UIControlEventTouchUpInside];
    [_bgBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    _bgBtn.alpha = 0.6;
//    _bgBtn.backgroundColor=[[UIColor blackColor]colorWithAlphaComponent:0.5];
    _bgBtn.backgroundColor = YCYHexColor(@"999999");
    [rootView addSubview:_bgBtn];
    int y = ActionHeight - 1;
    for (int i = 0; i < _titles.count; i ++) {
        UIButton *closeBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        closeBtn.frame = CGRectMake(0,i * ActionHeight, self.ycy_width, ActionHeight);
        closeBtn.backgroundColor = WhiteColor;
        [closeBtn addTarget:self action:@selector(clickBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        closeBtn.tag = i + 1000;
        [closeBtn setTitle:_titles[i] forState:UIControlStateNormal];
        closeBtn.titleLabel.font = YCYFont(16);
        [closeBtn setTitleColor:TextCOLOR333 forState:UIControlStateNormal];
        //    [savebtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        //    [savebtn ycy_cornerRadius:8 strokeSize:0 color:nil];
        //    savebtn.backgroundColor=HexColor(@"3c2626");
//        [closeBtn setImage:YCYImage(@"close-big-icon") forState:UIControlStateNormal];
        [self addSubview:closeBtn];
        
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, y, self.ycy_width, 1)];
        lineView.backgroundColor = YCYHexColor(@"e1e1e1");
        [self addSubview:lineView];
        
        y += ActionHeight;
        
    }
    
    
    UIButton *closeBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    closeBtn.frame = CGRectMake(0, self.ycy_height - ActionHeight, self.ycy_width , ActionHeight);
    [closeBtn addTarget:self action:@selector(closeSelfView) forControlEvents:UIControlEventTouchUpInside];
//    [closeBtn setImage:YCYImage(@"close-btn") forState:UIControlStateNormal];
    closeBtn.backgroundColor = WhiteColor;
    if (!self.cancelTitle) {
        [closeBtn setTitle:@"取消" forState:UIControlStateNormal];
    }else{
        [closeBtn setTitle:self.cancelTitle forState:UIControlStateNormal];
    }
    
    [closeBtn setTitleColor:TextCOLOR333 forState:UIControlStateNormal];
    closeBtn.titleLabel.font = YCYFont(16);
    [self addSubview:closeBtn];
    
    [rootView addSubview:self];
    
}

- (void)clickBtnAction:(UIButton *)sender{
    if ([self.delegate respondsToSelector:@selector(ycyActionSheet:andSelectedIndex:)]) {
        [self.delegate ycyActionSheet:self andSelectedIndex:sender.tag - 1000];
    }
    [_bgBtn removeFromSuperview];
    [self removeFromSuperview];
}

- (void)closeSelfView{
    if ([self.delegate respondsToSelector:@selector(ycyActionSheet:andSelectedIndex:)]) {
        [self.delegate ycyActionSheet:self andSelectedIndex:_titles.count];
    }
    [_bgBtn removeFromSuperview];
    [self removeFromSuperview];
}

- (void)closeSelf{
    [_bgBtn removeFromSuperview];
    [self removeFromSuperview];
}

@end
