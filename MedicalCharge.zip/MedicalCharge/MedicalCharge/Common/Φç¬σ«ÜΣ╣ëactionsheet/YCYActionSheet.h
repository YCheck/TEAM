//
//  YCYActionSheet.h
//  OFF GRID
//
//  Created by sunny on 2017/5/8.
//  Copyright © 2017年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
@class YCYActionSheet;
@protocol YCYActionSheetDelegate <NSObject>

- (void)ycyActionSheet:(YCYActionSheet *)actionSheet andSelectedIndex:(NSInteger)selectIndex;// 0 1  2

@end
@interface YCYActionSheet : UIView

@property (nonatomic,retain) NSString *cancelTitle;//返回按钮文字
@property (nonatomic,weak) id<YCYActionSheetDelegate> delegate;

- (instancetype)initWithTarget:(id<YCYActionSheetDelegate>)delegate andTitles:(NSArray *)titles;
- (void)showView;

@end
