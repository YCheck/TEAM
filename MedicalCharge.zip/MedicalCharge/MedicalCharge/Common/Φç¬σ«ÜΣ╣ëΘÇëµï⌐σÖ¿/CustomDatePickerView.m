//
//  YearsPickerView.m
//  艺术蜥蜴
//
//  Created by admin on 15/4/14.
//  Copyright (c) 2015年 admin. All rights reserved.
//

#import "CustomDatePickerView.h"
#import "TimeTransform.h"
#define Height 260

@interface CustomDatePickerView ()
{
    UIButton *_bgBtn;
}
@end

@implementation CustomDatePickerView

- (instancetype)initWithTarget:(id<CustomDatePickerDelegate>)delegate{
    CGRect frame = CGRectMake(0,YCYScreen_Height - Height, YCYScreen_Width,Height);
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor whiteColor];
        self.datePickerDelegate = delegate;
    }
    return self;
}

- (void)setTitleName:(NSString *)titleName{
    _titleName = titleName;
}

- (void)showView{
    UIView *rootView = YCYWindow;
    
    _bgBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    _bgBtn.tag=12121313;
    _bgBtn.frame = rootView.bounds;
    [_bgBtn setTitle:@"" forState:UIControlStateNormal];
    [_bgBtn addTarget:self action:@selector(cancelDatePicker) forControlEvents:UIControlEventTouchUpInside];
    [_bgBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    _bgBtn.backgroundColor=[[UIColor blackColor] colorWithAlphaComponent:0.4];
    [rootView addSubview:_bgBtn];
    
    _datePicker1 = [[UIDatePicker alloc] initWithFrame:CGRectMake(-5, self.frame.size.height - 216, YCYScreen_Width*0.68, 216)];
    _datePicker1.backgroundColor = [UIColor clearColor];
    [_datePicker1 addTarget:self action:@selector(dateChanged:) forControlEvents:UIControlEventValueChanged ];
    _datePicker1.datePickerMode = UIDatePickerModeDate;
    _datePicker1.locale = [[NSLocale alloc]
                           initWithLocaleIdentifier:@"zh_CN"];
    [self addSubview:_datePicker1];
    
    _datePicker2 = [[UIDatePicker alloc] initWithFrame:CGRectMake(YCYScreen_Width*0.58, self.frame.size.height - 216, YCYScreen_Width*0.4, 216)];
    _datePicker2.backgroundColor = [UIColor clearColor];
    [_datePicker2 addTarget:self action:@selector(dateChanged:) forControlEvents:UIControlEventValueChanged ];
    _datePicker2.locale = [[NSLocale alloc]
                         initWithLocaleIdentifier:@"zh_CN"];
    _datePicker2.datePickerMode = UIDatePickerModeTime;
    [self addSubview:_datePicker2];
    
    _whiteView = [[UIView alloc] initWithFrame:CGRectMake(0, _maskView.frame.size.height, YCYScreen_Width, 44)];
    _whiteView.backgroundColor = [UIColor whiteColor];
    [self addSubview:_whiteView];
    
    UIButton *closeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    closeBtn.frame = CGRectMake(0, 17, 70, 27);
    [closeBtn setTitle:@"取消" forState:UIControlStateNormal];
    [closeBtn setTitleColor:TextCOLOR666 forState:UIControlStateNormal];
    closeBtn.titleLabel.font = YCYFont(15);
    [closeBtn addTarget:self action:@selector(cancelDatePicker) forControlEvents:UIControlEventTouchUpInside];
    [_whiteView addSubview:closeBtn];
    
    UILabel *title = [[UILabel alloc] init];
    title.frame = CGRectMake(0, 20, YCYScreen_Width, 18);
    title.font = YCYFont(18);
    title.textColor = MainCOLOR;
    if (_titleName) {
        title.text = _titleName;
    }else{
        title.text = @"请选择时间";
    }
    
    title.textAlignment = NSTextAlignmentCenter;
    [_whiteView addSubview:title];
    
    UIButton *sureBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    sureBtn.frame = CGRectMake(_whiteView.frame.size.width - 70,17, 70, 27);
    [sureBtn setTitle:@"确认" forState:UIControlStateNormal];
    [sureBtn setTitleColor:TextCOLOR666 forState:UIControlStateNormal];
    sureBtn.titleLabel.font = YCYFont(15);
    [sureBtn addTarget:self action:@selector(sureBtnPressed) forControlEvents:UIControlEventTouchUpInside];
    [_whiteView addSubview:sureBtn];
    
    [rootView addSubview:self];
}

- (void)sureBtnPressed{
    NSString *time1 = [TimeTransform getYMDStringForDate:_datePicker1.date];
    NSString *time2 = [TimeTransform getHMSStringForDate:_datePicker2.date];
    [self.datePickerDelegate datePickerView:self didValueChanged:YCYAppendString(YCYAppendString(time1, @" "),time2)];
    [self cancelDatePicker];
}

- (void)dateChanged:(UIDatePicker *)datePicker{
    
    NSString *time1 = [TimeTransform getYMDStringForDate:_datePicker1.date];
    NSString *time2 = [TimeTransform getHMSStringForDate:_datePicker2.date];
    [self.datePickerDelegate datePickerView:self didValueChanged:YCYAppendString(YCYAppendString(time1, @" "),time2)];
}

- (void)cancelDatePicker{
    self.datePickerDelegate = nil;
    [_bgBtn removeFromSuperview];
    [_whiteView removeFromSuperview];
    [_datePicker1 removeFromSuperview];
    [_datePicker2 removeFromSuperview];
    [self removeFromSuperview];
}

@end
