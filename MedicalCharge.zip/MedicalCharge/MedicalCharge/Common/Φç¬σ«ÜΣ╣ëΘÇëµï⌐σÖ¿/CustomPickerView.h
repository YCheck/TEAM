//
//  CustomPickerView.h
//  Artselleasy
//
//  Created by admin on 15/6/15.
//  Copyright (c) 2015年 faith. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol CustomPickerDelegate <NSObject>

/**
 返回选择结果

 @param str 组装好的字符串
 @param ids 数组  分别存放对应id
 @param info info @{@"name":@"",@"id":@""}
 */
- (void)customPickerViewValueChanged:(NSString *)str andIds:(NSArray *)ids andOtherData:(NSDictionary *)info;

@end
@interface CustomPickerView : UIView<UIPickerViewDataSource,UIPickerViewDelegate>{
    UIPickerView *_pickerView;
    NSInteger _row1;
    NSInteger _row2;
    NSInteger _row3;
    UIView *_maskView;
    UIView *_whiteView;

}
@property (nonatomic,retain) NSString *titleString;//标题
@property (nonatomic,retain) NSArray *dataSources;
//根据列数传入数据源
@property (nonatomic,retain) NSArray *itemsArray1;
@property (nonatomic,retain) NSArray *itemsArray2;
@property (nonatomic,retain) NSArray *itemsArray3;

@property (nonatomic,assign) NSInteger selectRow;
@property (nonatomic,assign) id<CustomPickerDelegate> pickerDelegate;



/**
 picker

 @param delegate delegate
 @param number 显示几列 赞只支持3列
 @return pickerview
 */
- (instancetype)initWithTarget:(id<CustomPickerDelegate>)delegate andColumn:(NSInteger)number;
- (void)showView;
- (void)cancelPickerView;


@end
