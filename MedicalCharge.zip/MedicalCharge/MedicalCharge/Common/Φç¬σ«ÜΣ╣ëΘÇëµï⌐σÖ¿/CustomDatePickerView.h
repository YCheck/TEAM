//
//  YearsPickerView.h
//  艺术蜥蜴
//
//  Created by admin on 15/4/14.
//  Copyright (c) 2015年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>
@class CustomDatePickerView;
@protocol CustomDatePickerDelegate <NSObject>

- (void)datePickerView:(CustomDatePickerView *)pickerView didValueChanged:(NSString *)dateString;

@end

@interface CustomDatePickerView : UIView
{
    UIView *_maskView;
    UIView *_whiteView;
}


@property (nonatomic,assign) id<CustomDatePickerDelegate> datePickerDelegate;
@property (nonatomic,retain) UIDatePicker *datePicker1;
@property (nonatomic,retain) UIDatePicker *datePicker2;
@property (nonatomic,retain) NSString *titleName;

- (instancetype)initWithTarget:(id<CustomDatePickerDelegate>)delegate;
- (void)showView;
- (void)cancelDatePicker;
@end
