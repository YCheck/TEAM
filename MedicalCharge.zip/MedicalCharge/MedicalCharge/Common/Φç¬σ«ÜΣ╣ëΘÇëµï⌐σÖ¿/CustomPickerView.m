//
//  CustomPickerView.m
//  Artselleasy
//
//  Created by admin on 15/6/15.
//  Copyright (c) 2015年 faith. All rights reserved.
//

#import "CustomPickerView.h"

#define Height 260

@interface CustomPickerView ()
{
    NSInteger _column;//列
    UIButton *_bgBtn;
}
@end

@implementation CustomPickerView


- (instancetype)initWithTarget:(id<CustomPickerDelegate>)delegate andColumn:(NSInteger)number{
    CGRect frame = CGRectMake(0,YCYScreen_Height - Height, YCYScreen_Width,Height);
    if (self = [super initWithFrame:frame]) {
        _column = number;
        self.backgroundColor = [UIColor whiteColor];
        self.pickerDelegate = delegate;
    }
    return self;
}

- (void)showView{
    
    
    UIView *rootView = YCYWindow;
    
    _bgBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    _bgBtn.tag=12121313;
    _bgBtn.frame = rootView.bounds;
    [_bgBtn setTitle:@"" forState:UIControlStateNormal];
    [_bgBtn addTarget:self action:@selector(cancelPickerView) forControlEvents:UIControlEventTouchUpInside];
    [_bgBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    _bgBtn.backgroundColor=[[UIColor blackColor]colorWithAlphaComponent:0.4];
    [rootView addSubview:_bgBtn];
    
    _pickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(0, self.frame.size.height - 216, YCYScreen_Width, 216)];
    _pickerView.delegate = self;
    _pickerView.dataSource = self;
    _pickerView.backgroundColor = [UIColor whiteColor];
    [self addSubview:_pickerView];
//    [_pickerView selectRow:5 inComponent:0 animated:YES];
    
    
    _whiteView = [[UIView alloc] initWithFrame:CGRectMake(0, _maskView.frame.size.height, YCYScreen_Width, 44)];
    _whiteView.backgroundColor = [UIColor whiteColor];
    [self addSubview:_whiteView];
    
    UIButton *closeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    closeBtn.frame = CGRectMake(0, 17, 70, 27);
    [closeBtn setTitle:@"取消" forState:UIControlStateNormal];
    [closeBtn setTitleColor:TextCOLOR666 forState:UIControlStateNormal];
    closeBtn.titleLabel.font = YCYFont(15);
    [closeBtn addTarget:self action:@selector(cancelPickerView) forControlEvents:UIControlEventTouchUpInside];
    [_whiteView addSubview:closeBtn];
    
    UILabel *title = [[UILabel alloc] init];
    title.frame = CGRectMake(0, 20, YCYScreen_Width, 18);
    title.font = YCYFont(18);
    title.textColor = MainCOLOR;
    title.text = self.titleString;
    title.textAlignment = NSTextAlignmentCenter;
    [_whiteView addSubview:title];
    
    UIButton *sureBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    sureBtn.frame = CGRectMake(_whiteView.frame.size.width - 70,17, 70, 27);
    [sureBtn setTitle:@"确认" forState:UIControlStateNormal];
    [sureBtn setTitleColor:TextCOLOR666 forState:UIControlStateNormal];
    sureBtn.titleLabel.font = YCYFont(15);
    [sureBtn addTarget:self action:@selector(sureBtnPressed) forControlEvents:UIControlEventTouchUpInside];
    [_whiteView addSubview:sureBtn];
    
    [rootView addSubview:self];
    
}

- (void)sureBtnPressed{
    
    
    switch (_column) {
        case 1:
            if ([self.pickerDelegate respondsToSelector:@selector(customPickerViewValueChanged:andIds:andOtherData:)]) {
                if (self.itemsArray1.count == 0) {
                    [XHToast showBottomWithText:@"数据不完善~"];
                    [self cancelPickerView];
                    return;
                }
                [self.pickerDelegate customPickerViewValueChanged:self.itemsArray1[_row1][@"name"] andIds:@[self.itemsArray1[_row1][@"id"]] andOtherData:@{@"name":self.itemsArray1[_row1][@"name"],@"id":self.itemsArray1[_row1][@"id"]}];
            }
            
            break;
        case 2:
            if ([self.pickerDelegate respondsToSelector:@selector(customPickerViewValueChanged:andIds:andOtherData:)]) {
                if (self.itemsArray1.count == 0 || self.itemsArray2.count == 0 ) {
                    [self cancelPickerView];
                    return;
                }
                [self.pickerDelegate customPickerViewValueChanged:YCYAppendString(self.itemsArray1[_row1][@"name"], self.itemsArray2[_row2][@"name"]) andIds:@[self.itemsArray1[_row1][@"id"],self.itemsArray2[_row2][@"id"]] andOtherData:@{@"position":[NSString stringWithFormat:@"%@ %@",self.itemsArray1[_row1][@"name"],self.itemsArray2[_row2][@"name"]]}];
            }
            
            break;
        case 3:
            
            if ([self.pickerDelegate respondsToSelector:@selector(customPickerViewValueChanged:andIds:andOtherData:)]) {
                if (self.itemsArray1.count == 0 || self.itemsArray2.count == 0 || self.itemsArray3.count == 0) {
                    [XHToast showBottomWithText:@"该路线下无站点~"];
                    [self cancelPickerView];
                    return;
                }
                [self.pickerDelegate customPickerViewValueChanged:YCYAppendString(YCYAppendString(self.itemsArray1[_row1][@"name"], self.itemsArray2[_row2][@"name"]), self.itemsArray3[_row3][@"name"]) andIds:@[self.itemsArray1[_row1][@"id"], self.itemsArray2[_row2][@"id"], self.itemsArray3[_row3][@"id"]] andOtherData:@{@"position":[NSString stringWithFormat:@"%@ %@ %@",self.itemsArray1[_row1][@"name"],self.itemsArray2[_row2][@"name"],self.itemsArray3[_row3][@"name"]]}];
            }
            
            break;
        default:
            break;
    }
    [self cancelPickerView];
}

- (void)cancelPickerView{
    [_bgBtn removeFromSuperview];
    [_whiteView removeFromSuperview];
    [_pickerView removeFromSuperview];
    [self removeFromSuperview];
}


- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return _column;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    NSInteger result = 0;
    switch (component) {
        case 0:
            result = self.itemsArray1.count;//根据数组的元素个数返回几行数据
            if (_column == 2) {
                if (self.itemsArray1.count > 0) {
                    self.itemsArray2 = self.itemsArray1[0][@"securities"];
                }
                
            }else if (_column == 3){
                if (self.itemsArray1.count > 0) {
                    self.itemsArray2 = self.itemsArray1[0][@"stations"];
                }
            }
            
            break;
        case 1:
            result = self.itemsArray2.count;
            if (_column == 3) {
                if (self.itemsArray2.count > 0) {
                    self.itemsArray3 = self.itemsArray2[0][@"securities"];
                }
            }
            break;
        case 2:
            result = self.itemsArray3.count;
            break;
        default:
            break;
    }
    return result;
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    UILabel *lbl = (UILabel *)view;
    
    if (lbl == nil) {
        
        lbl = [[UILabel alloc]init];
        
        //在这里设置字体相关属性
        
        lbl.font = [UIFont systemFontOfSize:14];
        
        lbl.textColor = TextCOLOR333;
        
        [lbl setTextAlignment:1];
        
        [lbl setBackgroundColor:[UIColor clearColor]];
        
    }
    
    //重新加载lbl的文字内容
    
    lbl.text = [self pickerView:pickerView titleForRow:row forComponent:component];
    
    return lbl;
}

- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component {
    return _pickerView.frame.size.width/_column;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    switch (component) {
        case 0:
            _row1 = row;
            //如果要联动可以在这里刷新第二个数组数据
            
            if (_column == 2) {
                self.itemsArray2 = @[];
                if (self.itemsArray1.count > 0) {
                    self.itemsArray2 = self.itemsArray1[row][@"securities"];
                }
                [pickerView reloadComponent:1];
            }else if (_column == 3){
                self.itemsArray2 = @[];
                if (self.itemsArray1.count > 0) {
                    self.itemsArray2 = self.itemsArray1[row][@"stations"];
                    self.itemsArray3 = @[];
                    if (self.itemsArray2.count > 0) {
                        self.itemsArray3 = self.itemsArray2[0][@"securities"];
                    }
                }
                [pickerView reloadComponent:1];
                [pickerView reloadComponent:2];
            }
            
            break;
        case 1:
            _row2 = row;
            if (_column == 3) {
                self.itemsArray3 = @[];
                if (self.itemsArray2.count > 0) {
                    self.itemsArray3 = self.itemsArray2[row][@"securities"];
                }
                [pickerView reloadComponent:2];
            }
            
            break;
        case 2:
            _row3 = row;
            break;
        default:
            break;
    }
//    [self.pickerDelegate customPickerViewValueChanged:self.dataSources[row]];
}

//返回当前行的内容,此处是将数组中数值添加到滚动的那个显示栏上
-(NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    NSString * title = nil;
    switch (component) {
        case 0:
            title = self.itemsArray1[row][@"name"];
            break;
        case 1:
            title = self.itemsArray2[row][@"name"];
            break;
        case 2:
            title = self.itemsArray3[row][@"name"];
            break;
        default:
            break;
    }
    
    return title;
}

@end
