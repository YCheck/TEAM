//
//  WorkMatterTableViewCell.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/2.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "WorkMatterTableViewCell.h"

@implementation WorkMatterTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)configureForCell:(NSDictionary *)model{
    self.numberLabel.layer.cornerRadius = 11;
    self.numberLabel.clipsToBounds = YES;
    
    self.titleLabel.text = model[@"name"];
    self.numberLabel.text = [NSString stringWithFormat:@"%@",model[@"quantity"]];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
