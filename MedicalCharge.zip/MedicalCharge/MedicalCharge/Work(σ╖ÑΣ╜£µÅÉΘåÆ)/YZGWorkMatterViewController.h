//
//  YZGWorkMatterViewController.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/2/28.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BaseViewController.h"

@interface YZGWorkMatterViewController : BaseViewController
@property (weak, nonatomic) IBOutlet UILabel *remindLabel;

@end
