//
//  YZGWorkMatterViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/2/28.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGWorkMatterViewController.h"
#import "YZGWorkListViewController.h"
#import "ZFChart.h"
@interface YZGWorkMatterViewController ()<ZFPieChartDataSource, ZFPieChartDelegate>

@property (nonatomic, strong) ZFPieChart * pieChart;

@property (nonatomic, assign) CGFloat height;
@property (nonatomic, retain) NSMutableArray *colorArray;
@property (nonatomic, retain) NSMutableArray *dataSource;
@property (nonatomic, retain) NSMutableArray *titleArray;//标题
@property (nonatomic, retain) NSMutableArray *quantityArray;//数量
@property (weak, nonatomic) IBOutlet UIButton *lookButton;

@end

@implementation YZGWorkMatterViewController

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleDefault;
}

- (NSMutableArray *)dataSource{
    if (!_dataSource) {
        _dataSource = [NSMutableArray array];
    }
    return _dataSource;
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self getWorkListRequest];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"工作提醒";
    [self hideCustomBackButtonItem];
    
}

- (void)initWithUserInterface{
    
    [self initWithDataSource];
    
    self.pieChart = [[ZFPieChart alloc] initWithFrame:CGRectMake(0, 80, SCREEN_WIDTH, 300)];
    self.pieChart.dataSource = self;
    self.pieChart.delegate = self;
    self.pieChart.piePatternType = kPieChartPatternTypeCircle;
    [self.pieChart strokePath];
    [self.view addSubview:self.pieChart];
    
    self.remindLabel.hidden = YES;
    self.lookButton.layer.borderWidth = 1;
    self.lookButton.layer.borderColor = TextCOLOR333.CGColor;
}

- (void)initWithDataSource{
    self.quantityArray = [NSMutableArray array];
    self.titleArray = [NSMutableArray array];
    for (int i = 0; i < self.dataSource.count; i ++) {
        NSDictionary *dic = self.dataSource[i];
        [self.titleArray addObject:dic[@"name"]];
        [self.quantityArray addObject:[NSString stringWithFormat:@"%@",dic[@"quantity"]]];
    }
    if (self.colorArray.count == 0) {
        self.colorArray = [NSMutableArray array];
        for (int i = 0; i < self.dataSource.count; i ++) {
            [self.colorArray addObject:[UIColor ycy_randomColor]];
        }
        [self initColorMean];
    }
}

- (void)initColorMean{
    
    int x = 20,y = 20;
    for (int i = 0; i < self.colorArray.count; i ++) {
        UIView *colorView = [[UIView alloc] initWithFrame:CGRectMake(x, y, 10, 10)];
        colorView.backgroundColor = self.colorArray[i];
        [self.view addSubview:colorView];
        
        UILabel *title = [[UILabel alloc] init];
        title.frame = CGRectMake(CGRectGetMaxX(colorView.frame) + 8, y - 1, 200, 12);
        title.text = self.titleArray[i];
        title.textColor = TextCOLOR333;
        title.font = YCYFont(10);
        [self.view addSubview:title];
        
        
        
        if (i == 2) {
            x = 180;y = 20;
        }else{
            y += 18;
        }
    }
}

- (IBAction)lookAllButtonAction:(id)sender {
    YZGWorkListViewController *controller = [[YZGWorkListViewController alloc] init];
    controller.dataSource = self.dataSource;
    [self.navigationController pushViewController:controller animated:YES];
}


#pragma mark - ZFPieChartDataSource

- (NSArray *)valueArrayInPieChart:(ZFPieChart *)chart{
    return self.quantityArray;
}

- (NSArray *)colorArrayInPieChart:(ZFPieChart *)chart{
    return self.colorArray;
}

#pragma mark - ZFPieChartDelegate

- (void)pieChart:(ZFPieChart *)pieChart didSelectPathAtIndex:(NSInteger)index{
    NSLog(@"第%ld个",(long)index);
}

- (CGFloat)allowToShowMinLimitPercent:(ZFPieChart *)pieChart{
    return 5.f;
}

- (CGFloat)radiusForPieChart:(ZFPieChart *)pieChart{
    return 120.f;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --------   网络请求------
- (void)getWorkListRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:1];
}
#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    if (manager.requestNumber == 1) {
        
        return @{@"url":WorkTipListAPI,@"params":@{}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([result isKindOfClass:[NSDictionary class]] && [manager.response.content[@"success"] integerValue] != 1) {
            [XHToast showCenterWithText:result[@"msg"]];
    }else{
        if (manager.requestNumber == 1){
            
            [self.dataSource removeAllObjects];
            [self.dataSource addObjectsFromArray:result[@"data"]];
            [self initWithUserInterface];
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
