//
//  YZGWorkListViewController.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/2.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BaseViewController.h"

@interface YZGWorkListViewController : BaseViewController
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic,retain) NSArray *dataSource;

@end
