//
//  NetworkURLHeader.h
//  PintuangouPro
//
//  Created by yangchengyou on 17/1/17.
//  Copyright © 2017年 zipingfang. All rights reserved.
//

#ifndef NetworkURLHeader_h
#define NetworkURLHeader_h

//三方key
static NSString * const kUMShareAppKey = @"5a93dd28b27b0a33c100005d"; // 友盟应用Key
static NSString * const kUMShareUrl = @"https://www.pgyer.com/04Y4"; // 这个是蒲公英下载的地址

static NSString * const kWeChatAppKey = @"wxbfe2bfb27a83dfcb"; // 微信应用Key
static NSString * const kWeChatAppSecret = @"f3e200c0796ed88b1933a90d404ffb60"; // 账号上查看 并且忘记也只有重置

static NSString * const kQQAppId = @""; // QQ应用id
static NSString * const kQQAppKey = @"6544863fccd42b02d040048006d7dda6"; // QQ应用Key

static NSString * const kSinaAppKey = @""; // 新浪微博应用Key
static NSString * const kSinaAppSecret = @"07f0308268aeecc0b9ef2b04c9688762"; // 新浪微博应用Secret
static NSString * const kSinaRedirectURI = @"https://api.weibo.com/oauth2/default.html"; // 新浪微博回调地址

static NSString * const kBaiduMapAppkey = @"ymKZGlEzpCHTX1sku5AdL57WMQ8OXqG1";//百度地图key
static NSString * const kGoogleMapAppkey = @"";//谷歌地图key

//@"1135170117115181#social"
static NSString * const EaseAppkey = @"1186170930178675#shejiaoapp";//环信key

static NSString * const BugTagsAppkey = @"e4b53759c960918990eb6c68afa32717";//环信key

static  NSString *jPushAPP_KEY = @"d19a679753e1c20eec5b6bde";// heibe
static NSString *channel = @"Publish channel";
static BOOL isProduction = YES;// 是否生产环境. 如果为开发状态,设置为 NO; 如果为生产状态,应改为 YES.

#define DEVICEUUID GETNSUserDefault(@"uuid")

// 1 医院 2 供应商
#define ROLE [GETNSUserDefault(@"role") integerValue]
#define IsEngineer [GETNSUserDefault(@"isEngineer") boolValue]
#define Token GETNSUserDefault(@"logintoken") == nil? @"":GETNSUserDefault(@"logintoken")
#define HeaderPath GETNSUserDefault(@"headPath") == nil? @"":GETNSUserDefault(@"headPath")
#define UserID GETNSUserDefault(@"userId") == nil? @"":GETNSUserDefault(@"userId")
#define Phone GETNSUserDefault(@"phone") == nil? @"":GETNSUserDefault(@"phone")
#define NickName GETNSUserDefault(@"nickname") == nil? @"":GETNSUserDefault(@"nickname")
#define LoginName GETNSUserDefault(@"loginname") == nil? @"":GETNSUserDefault(@"loginname")//登录名  工号
#define DepartmentName GETNSUserDefault(@"department") == nil? @"":GETNSUserDefault(@"department")//所属科室
#define Sex GETNSUserDefault(@"sex") == nil? @"":GETNSUserDefault(@"sex")
#define Company GETNSUserDefault(@"company") == nil? @"":GETNSUserDefault(@"company")//所属单位
#define RealName GETNSUserDefault(@"realName") == nil? @"":GETNSUserDefault(@"realName")//真实名称
#define Email GETNSUserDefault(@"email") == nil? @"":GETNSUserDefault(@"email")//邮箱

#define PageSize 10
//#define MainURL @"http://192.168.2.109:44398/services/v1/"
//#define ImageMainURL @"http://www.yizhangguan.cn/services/v1/"
//#define MainURL @"http://www.yizhangguan.cn/services/v1/"
#define ImageMainURL @"http://211.149.182.191/services/v1/"
#define MainURL @"http://211.149.182.191/services/v1/"

//登录接口
#define LoginAPI [NSString stringWithFormat:@"%@%@",MainURL,@"login"]
//注册接口
#define RegisterAPI [NSString stringWithFormat:@"%@%@",MainURL,@"register"]
//注册协议
#define RegisterProtocolAPI [NSString stringWithFormat:@"%@%@",MainURL,@"GetRegistAgreeUrl"]
//忘记密码
#define ForgetPasswordAPI [NSString stringWithFormat:@"%@%@",MainURL,@"findpwd"]
//修改密码
#define UpdatePasswordAPI [NSString stringWithFormat:@"%@%@",MainURL,@"/member/passwd"]
//获取验证码
#define GetCodeAPI [NSString stringWithFormat:@"%@%@",MainURL,@"getvercode"]

//获取用户信息
#define GetMemberInfoAPI [NSString stringWithFormat:@"%@%@",MainURL,@"/member/info"]
//修改用户信息
#define UpdateMemberInfoAPI [NSString stringWithFormat:@"%@%@",MainURL,@"/member/updateInfo"]
//获取指定类型用户
#define GetMemberListAPI [NSString stringWithFormat:@"%@%@",MainURL,@"/member/memberList"]
//获取当前用户下所有用户信息
#define GetCurrentUserMemberListAPI [NSString stringWithFormat:@"%@%@",MainURL,@"/member/subordinateMember"]
//获取医院列表
#define GetHospitalListAPI [NSString stringWithFormat:@"%@%@",MainURL,@"GetHospitalList"]
#define AboutUsAPI [NSString stringWithFormat:@"%@%@",MainURL,@"/member/about/list"]
//意见反馈
#define FeedbackAPI [NSString stringWithFormat:@"%@%@",MainURL,@"/member/feedback/commit"]
//=================================home==========================
//首页数据
#define GetHomePageAPI [NSString stringWithFormat:@"%@%@",MainURL,@"home"]


//---------------------------------医院版-----------------
//==============验收入库
//验收入库列表
#define CheckInComingListAPI [NSString stringWithFormat:@"%@%@",MainURL,@"SearchPurchaseOrderList"]
//验收入库--订单详情
#define CheckOrderDetailsAPI [NSString stringWithFormat:@"%@%@",MainURL,@"GetPurchaseOrder"]
//验收入库扫码--订单详情
#define CheckOrderDetailsForScanAPI [NSString stringWithFormat:@"%@%@",MainURL,@"GetQrPurchaseOrder"]

//验收订单--提交
#define CommitOrderAPI [NSString stringWithFormat:@"%@%@",MainURL,@"HospitalAccePurchaseOrder"]
//==============扫码报修
//扫码报修
#define ScanCodeRepairAPI [NSString stringWithFormat:@"%@%@",MainURL,@"ScanCodeRepair"]


//===============维修管理
//维修管理--列表
#define MaintenanceListAPI [NSString stringWithFormat:@"%@%@",MainURL,@"SearchRepairOrderList"]
//维修管理--扫码
#define ScanCodeAPI [NSString stringWithFormat:@"%@%@",MainURL,@"ScanCodeAction"]

//报修--选择设备列表
#define DeviceListAPI [NSString stringWithFormat:@"%@%@",MainURL,@"SearchMaterial"]
//固定资产报修--获取单号
#define DeviceRepairAPI [NSString stringWithFormat:@"%@%@",MainURL,@"ScanCodeRepair"]
//手动报修--获取单号
#define OperationRepairAPI [NSString stringWithFormat:@"%@%@",MainURL,@"GetRepairNumber"]
//报修-保存报修单
#define CommitRepairAPI [NSString stringWithFormat:@"%@%@",MainURL,@"RepairApply"]
//报修-工程师开始计时
#define MaintenanceTimingAPI [NSString stringWithFormat:@"%@%@",MainURL,@"ScanCodeTiming"]
//维修详情
#define MaintenanceDetailAPI [NSString stringWithFormat:@"%@%@",MainURL,@"GetRepairAllDetails"]
//维修登记
#define MaintenanceRegisterAPI [NSString stringWithFormat:@"%@%@",MainURL,@"GetGuidCheckIn"]
//维修登记扫码进入
#define MaintenanceRegisterScanAPI [NSString stringWithFormat:@"%@%@",MainURL,@"GetNumberCheckIn"]
//保存维修登记
#define SaveMaintenanceRegisterScanAPI [NSString stringWithFormat:@"%@%@",MainURL,@"ScanCodeCheckIn"]
//=================报修验收
//报修验收-列表
#define RepairOrderListAPI [NSString stringWithFormat:@"%@%@",MainURL,@"SearchRepairOrderList"]
//扫码验收
#define ScanCheckAPI [NSString stringWithFormat:@"%@%@",MainURL,@"GetNumberReapirAcceptance"]
//验收信息
#define AcceptOrderDetailAPI [NSString stringWithFormat:@"%@%@",MainURL,@"GetGuidReapirAcceptance"]
//维修单验收
#define RepairAcceptAPI [NSString stringWithFormat:@"%@%@",MainURL,@"ScanCodeReapirAcceptance"]
//查看维修处理记录
#define ProcessListAPI [NSString stringWithFormat:@"%@%@",MainURL,@"GetRepairProcessList"]
//查看配件明细
#define PartsListAPI [NSString stringWithFormat:@"%@%@",MainURL,@"GetReplacingFittingList"]
//查看费用明细
#define FeeListAPI [NSString stringWithFormat:@"%@%@",MainURL,@"GetGyRepairfeeList"]

//=================设备动态
//设备动态列表
#define DeviceDynamicListAPI [NSString stringWithFormat:@"%@%@",MainURL,@"SearchMaterial"]
//修改设备状态
#define UpdateDeviceStatusAPI [NSString stringWithFormat:@"%@%@",MainURL,@"UpdqteMaterial"]
//设备基本信息
#define DeviceDetailsAPI [NSString stringWithFormat:@"%@%@",MainURL,@"GetMaterial"]
//设备维修记录
#define DeviceMaintenanceRecordAPI [NSString stringWithFormat:@"%@%@",MainURL,@"SearchRepairOrderList"]
//---------------------------------供应商-----------------
//============订单管理
//取消订单
#define CancelOrderAPI [NSString stringWithFormat:@"%@%@",MainURL,@"CancelPurchaseOrder"]
//录入订单信息
#define AddOrderMessageAPI [NSString stringWithFormat:@"%@%@",MainURL,@"AddPurchaseOrderQuantity"]
//============基础数据
//我的基础数据
#define MyBasicMessageAPI [NSString stringWithFormat:@"%@%@",MainURL,@"SearchBasicDataList"]
//医院基础数据
#define HospitalBasicMessageAPI [NSString stringWithFormat:@"%@%@",MainURL,@"SearchBasicHospitData"]
//推送数据
#define PushBasicDataAPI [NSString stringWithFormat:@"%@%@",MainURL,@"GetPushBasicData"]
//提交推送数据
#define CommitPushBasicDataAPI [NSString stringWithFormat:@"%@%@",MainURL,@"GetPushAdd"]
//我所供应的医院
#define MyHospitalListAPI [NSString stringWithFormat:@"%@%@",MainURL,@"SearchSupplierHospitalRelation"]
//=============备货单
//备货单列表
#define SpareOrderListAPI [NSString stringWithFormat:@"%@%@",MainURL,@"SearchSpareOrderList"]
//录入备货单
#define AddSpareOrderAPI [NSString stringWithFormat:@"%@%@",MainURL,@"AddSpareOrder"]
//取消备货单
#define CancelSpareOrderAPI [NSString stringWithFormat:@"%@%@",MainURL,@"CancelSpareOrder"]
//备货单详情
#define SpareOrderDetailsAPI [NSString stringWithFormat:@"%@%@",MainURL,@"GetSpareOrder"]
//=============对账单管理
//对账单请求汇总
#define BillRequestListAPI [NSString stringWithFormat:@"%@%@",MainURL,@"SearchReconciliation"]
//已请求对账单
#define BillManagerListAPI [NSString stringWithFormat:@"%@%@",MainURL,@"SearchReconciliationRecord"]
//确认账单
#define ConfirmBillAPI [NSString stringWithFormat:@"%@%@",MainURL,@"BillConfirm"]
//添加账单
#define AddBillAPI [NSString stringWithFormat:@"%@%@",MainURL,@"AddReconciliation"]
//获取默认时间
#define GetDefaultTimeAPI [NSString stringWithFormat:@"%@%@",MainURL,@"GetLastTime"]

//=================================WorkTip==========================
//工作提醒
#define WorkTipListAPI [NSString stringWithFormat:@"%@%@",MainURL,@"GetWorkTip"]

//=================================消息管理==========================
//消息管理
#define MessageListAPI [NSString stringWithFormat:@"%@%@",MainURL,@"SearchMessage"]
//消息详情
#define MessageDetailsAPI [NSString stringWithFormat:@"%@%@",MainURL,@"GetMessage"]


//========================我的==================
//我的信息
#define MyUserInfo [NSString stringWithFormat:@"%@%@",MainURL,@"common/member/index"]
//更新个人信息
#define UpdateUserInfoAPI [NSString stringWithFormat:@"%@%@",MainURL,@"updateuser"]
//修改密码
#define UpdatePWDAPI [NSString stringWithFormat:@"%@%@",MainURL,@"changepwd"]


//=================================公共接口===================

//添加相关字典信息
#define AddDictionaryAPI [NSString stringWithFormat:@"%@%@",MainURL,@"AddDictionary"]
//根据dictype获取相关信息
#define GetListForDicTypeAPI [NSString stringWithFormat:@"%@%@",MainURL,@"GetDictionaryList"]
//上传图片
#define UploadImageAPI [NSString stringWithFormat:@"%@%@",MainURL,@"UploadFile"]
//上传视频
#define UploadVideoAPI [NSString stringWithFormat:@"%@%@",MainURL,@"common/uploads/uploadVideo"]


#endif /* NetworkURLHeader_h */
