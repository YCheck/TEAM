//
//  HospitalListTableViewCell.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/1.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CoreObject+Hospital.h"

@interface HospitalListTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *name;

- (void)configureForCell:(CoreObject_Hospital *)model andKeyword:(NSString *)keyword;

@end
