//
//  HospitalListTableViewCell.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/1.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "HospitalListTableViewCell.h"

@implementation HospitalListTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)configureForCell:(CoreObject_Hospital *)model andKeyword:(NSString *)keyword{
    NSString *lastText = model.name;
    
    NSRange range = [lastText rangeOfString:keyword];
    
    NSMutableAttributedString *string=[[NSMutableAttributedString alloc]initWithString:lastText];
    [string setAttributes:@{NSForegroundColorAttributeName:MainCOLOR,NSFontAttributeName:YCYFont(15)} range:NSMakeRange(range.location, range.length)];
    self.name.attributedText = string;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
