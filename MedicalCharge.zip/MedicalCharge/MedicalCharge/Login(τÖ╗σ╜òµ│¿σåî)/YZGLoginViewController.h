//
//  YZGLoginViewController.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/2/28.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BaseViewController.h"

@interface YZGLoginViewController : BaseViewController

@property (weak, nonatomic) IBOutlet UIView *hospitalView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *hospitalHight;

@property (weak, nonatomic) IBOutlet UITextField *userName;
@property (weak, nonatomic) IBOutlet UITextField *hospitalName;
@property (weak, nonatomic) IBOutlet UITextField *password;



@end
