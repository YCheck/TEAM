//
//  YZGHospitalListViewController.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/1.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BaseViewController.h"

@protocol YZGHospitalListViewControllerDelegate <NSObject>

- (void)chooseHospitalName:(NSString *)name andHospitalId:(NSString *)hId;

@end

@interface YZGHospitalListViewController : BaseViewController

@property (nonatomic,weak) id<YZGHospitalListViewControllerDelegate> delegate;

@property (weak, nonatomic) IBOutlet UITextField *searchText;

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic, copy) NSString *province;
@property (nonatomic, copy) NSString *city;
@property (nonatomic, copy) NSString *county;


@end


