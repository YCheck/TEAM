//
//  YZGForgetPWDViewController.h
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/2.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "BaseViewController.h"

@interface YZGForgetPWDViewController : BaseViewController
@property (weak, nonatomic) IBOutlet UITextField *phone;
@property (weak, nonatomic) IBOutlet UITextField *code;
@property (weak, nonatomic) IBOutlet UITextField *password;
@property (weak, nonatomic) IBOutlet UITextField *passwordAgain;


@property (weak, nonatomic) IBOutlet UIButton *codeButton;

@end
