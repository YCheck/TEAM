//
//  YZGForgetPWDViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/2.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGForgetPWDViewController.h"

@interface YZGForgetPWDViewController ()

@end

@implementation YZGForgetPWDViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"忘记密码";
}

- (IBAction)eyesButton1Action:(id)sender {
    UIButton *button = (UIButton *)sender;
    button.selected = !button.selected;
    self.password.secureTextEntry = !button.selected;
}

- (IBAction)eyesButtonAction:(id)sender {
    UIButton *button = (UIButton *)sender;
    button.selected = !button.selected;
    self.passwordAgain.secureTextEntry = !button.selected;
}

- (IBAction)sendCodeAction:(id)sender {
    if (self.phone.text.length == 0) {
        [XHToast showBottomWithText:@"请输入手机号~"];
        return;
    }else if (self.phone.text.length != 11){
        [XHToast showBottomWithText:@"请输入正确手机号~"];
        return;
    }
    
    self.codeButton.userInteractionEnabled = NO;
    [_codeButton ycy_startTime:59 title:@"重新获取" waitTittle:@"秒后重发"];
    [self performSelector:@selector(resetCodeBtnStatus) withObject:nil afterDelay:59];
    [self getCodeRequest];
}

#pragma mark -- 重置验证码按钮
- (void)resetCodeBtnStatus{
    self.codeButton.userInteractionEnabled = YES;
}

- (IBAction)resetButtonAction:(id)sender {
    if (self.password.text.length == 0) {
        [XHToast showBottomWithText:@"请输入密码~"];
        return;
    }
    if (self.password.text.length < 6 || self.password.text.length > 16) {
        [XHToast showBottomWithText:@"请输入6-16位密码~"];
        return;
    }
    if (![self.password.text isEqualToString:self.passwordAgain.text]) {
        [XHToast showBottomWithText:@"两次输入密码不一致~"];
        return;
    }
    if (self.phone.text.length == 0) {
        [XHToast showBottomWithText:@"请输入手机号~"];
        return;
    }
    if (self.code.text.length == 0) {
        [XHToast showBottomWithText:@"请输入验证码~"];
        return;
    }
    
    [self forgetPWDRequest];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --------   网络请求------

- (void)forgetPWDRequest{
    [CHNetworkingConfig shardInstance].requestType = 1;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:1];
}

- (void)getCodeRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:2];
}

#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    
    if (manager.requestNumber == 1) {
        
        NSDictionary *param = @{@"loginPassword":self.password.text,@"loginPassword1":self.passwordAgain.text,@"mobilePhone":self.phone.text,@"verificationCode":self.code.text};
        return @{@"url":ForgetPasswordAPI,@"params":param};
    }else if (manager.requestNumber == 2) {
        return @{@"url":GetCodeAPI,@"params":@{@"ActionType":@"找回密码",@"MobilePhone":self.phone.text}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([manager.response.content[@"success"] integerValue] != 1) {
        [XHToast showCenterWithText:result[@"msg"]];
    }else{
        if (manager.requestNumber == 1){
            [XHToast showBottomWithText:@"密码找回成功~"];
            [self.navigationController popViewControllerAnimated:YES];
        }else if(manager.requestNumber == 2){
            
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
