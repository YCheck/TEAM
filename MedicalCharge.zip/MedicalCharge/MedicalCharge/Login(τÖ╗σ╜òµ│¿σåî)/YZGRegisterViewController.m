//
//  YZGRegisterViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/1.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGRegisterViewController.h"
#import "YZGHospitalListViewController.h"
#import "HZAreaPickerView.h"
#import "YZGProtocolViewController.h"
@interface YZGRegisterViewController ()<UITextFieldDelegate,HZAreaPickerDelegate,YZGHospitalListViewControllerDelegate>

@property (strong, nonatomic) HZAreaPickerView *locatePicker;
@property (nonatomic,assign) NSInteger userType;//用户类型 1医院 2供应商
@property (nonatomic, copy) NSString *province;
@property (nonatomic, copy) NSString *city;
@property (nonatomic, copy) NSString *county;

@end

@implementation YZGRegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setWhiteNavigation];
    self.province = GETNSUserDefault(@"province");
    self.city = GETNSUserDefault(@"city");
    self.county = GETNSUserDefault(@"area");
    self.addressLabel.text = [NSString stringWithFormat:@"%@%@%@",self.province,self.city,self.county];
    self.userType = 1;
}

#pragma mark -- 选择所属医院
- (IBAction)chooseAddressAction:(id)sender {
    YZGHospitalListViewController *controller = [[YZGHospitalListViewController alloc] init];
    controller.delegate = self;
    controller.province = self.province;
    controller.city = self.city;
    controller.county = self.county;
    [self.navigationController pushViewController:controller animated:YES];
}

#pragma mark - - YZGHospitalListViewControllerDelegate
- (void)chooseHospitalName:(NSString *)name andHospitalId:(NSString *)hId{
    self.hospitalName.text = name;
}

#pragma mark -- 注册
- (IBAction)registerButtonAction:(id)sender {
    
    if (self.agreeButton.selected == NO) {
        [XHToast showBottomWithText:@"请阅读医掌管平台服务协议~"];
        return;
    }
    if (self.userType == 1) {
        if (self.hospitalName.text.length == 0) {
            [XHToast showBottomWithText:@"请选择所属医院~"];
            return;
        }
    }else if (self.userType == 2){
        if (self.companyName.text.length == 0) {
            [XHToast showBottomWithText:@"请输入公司名称~"];
            return;
        }
    }
    
    if (self.userName.text.length == 0) {
        [XHToast showBottomWithText:@"请输入用户名~"];
        return;
    }
    if (self.password.text.length == 0) {
        [XHToast showBottomWithText:@"请输入密码~"];
        return;
    }
    if (self.password.text.length < 6 || self.password.text.length > 16) {
        [XHToast showBottomWithText:@"请输入6-16位密码~"];
        return;
    }
    if (![self.password.text isEqualToString:self.passwordAgain.text]) {
        [XHToast showBottomWithText:@"两次输入密码不一致~"];
        return;
    }
    if (self.phone.text.length == 0) {
        [XHToast showBottomWithText:@"请输入手机号~"];
        return;
    }
    if (self.code.text.length == 0) {
        [XHToast showBottomWithText:@"请输入验证码~"];
        return;
    }
    
    [self registerRequest];
}

#pragma mark -- 获取验证码
- (IBAction)getCodeAction:(id)sender {
    if (self.phone.text.length == 0) {
        [XHToast showBottomWithText:@"请输入手机号~"];
        return;
    }else if (self.phone.text.length != 11){
        [XHToast showBottomWithText:@"请输入正确手机号~"];
        return;
    }
    
    self.codeButton.userInteractionEnabled = NO;
    [_codeButton ycy_startTime:59 title:@"重新获取" waitTittle:@"秒后重发"];
    [self performSelector:@selector(resetCodeBtnStatus) withObject:nil afterDelay:59];
    [self getCodeRequest];
}

#pragma mark -- 重置验证码按钮
- (void)resetCodeBtnStatus{
    self.codeButton.userInteractionEnabled = YES;
}

#pragma mark -- 修改地理位置
- (IBAction)updateLocation:(id)sender {
    [self cancelLocatePicker];
    self.locatePicker = [[HZAreaPickerView alloc] initWithStyle:HZAreaPickerWithStateAndCityAndDistrict delegate:self];
    [self.locatePicker showInView:[self.view superview]];
}

#pragma mark - HZAreaPickerDelegate
- (void)pickerDidChaneStatus:(HZAreaPickerView *)picker{
    self.addressLabel.text = [NSString stringWithFormat:@"%@%@%@",picker.locate.state,picker.locate.city,picker.locate.district];
    
    self.province = picker.locate.state;
    self.city = picker.locate.city;
    self.county = picker.locate.district;
}

-(void)cancelLocatePicker
{
    [self.locatePicker cancelPicker];
    self.locatePicker.delegate = nil;
    self.locatePicker = nil;
}

- (IBAction)eyesButton1Action:(id)sender {
    UIButton *button = (UIButton *)sender;
    button.selected = !button.selected;
    self.password.secureTextEntry = !button.selected;
}

- (IBAction)eyesButtonAction:(id)sender {
    UIButton *button = (UIButton *)sender;
    button.selected = !button.selected;
    self.passwordAgain.secureTextEntry = !button.selected;
}

#pragma mark -- 角色切换 11 12
- (IBAction)roleChooseAction:(id)sender {
    
    UIButton *button = (UIButton *)sender;
    
    for (int i = 11; i < 13; i ++) {
        UIButton *btn =(UIButton *)[self.view viewWithTag:i];
        btn.selected = NO;
    }
    
    button.selected = YES;
    
    if (button.tag == 11) {
        self.locationView.hidden = NO;
        self.companyTop.constant = 50;
        self.hospitalView.hidden = NO;
    }else{
        self.locationView.hidden = YES;
        self.companyTop.constant = 30;
        self.hospitalView.hidden = YES;
    }
    
    self.userType = button.tag - 10;
}

- (IBAction)protocolAction:(id)sender {
    YZGProtocolViewController *controller = [[YZGProtocolViewController alloc] init];
    [self.navigationController pushViewController:controller animated:YES];
}

- (IBAction)agreeButtonAction:(id)sender {
    self.agreeButton.selected = !self.agreeButton.selected;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self closeKeyBoard];
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --------   网络请求------

- (void)registerRequest{
    [CHNetworkingConfig shardInstance].requestType = 1;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:1];
}

- (void)getCodeRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:2];
}

#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    
    if (manager.requestNumber == 1) {
        NSString *name = @"";
        if (self.userType == 1) {
            name = self.hospitalName.text;
        }else if (self.userType == 2){
            name = self.companyName.text;
        }
        
        NSDictionary *param = @{@"userType":@(self.userType),@"name":name,@"loginName":self.userName.text,@"loginPassword":self.password.text,@"loginPassword1":self.passwordAgain.text,@"mobilePhone":self.phone.text,@"verificationCode":self.code.text,@"isAgreeAgreement":@(YES)};
        return @{@"url":RegisterAPI,@"params":param};
    }else if (manager.requestNumber == 2) {
        return @{@"url":GetCodeAPI,@"params":@{@"ActionType":@"注册验证",@"MobilePhone":self.phone.text}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([manager.response.content[@"success"] integerValue] != 1) {
        [XHToast showCenterWithText:result[@"msg"]];
    }else{
        if (manager.requestNumber == 1){
            if (self.userType == 1) {
                PUTNSUserDefault(@"hospitalLoginName", self.userName.text);
            }else if (self.userType == 2){
                PUTNSUserDefault(@"supplierLoginName", self.userName.text);
            }
            [self.navigationController popViewControllerAnimated:YES];
        }else if(manager.requestNumber == 2){
            
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
