//
//  YZGHospitalListViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/3/1.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGHospitalListViewController.h"
#import "HospitalListTableViewCell.h"
#import "CoreObject+Hospital.h"

@interface YZGHospitalListViewController ()<UITextFieldDelegate,UITableViewDelegate>

// 当前的数据源
@property (nonatomic, strong) NSMutableArray *dataSource;
// 当前的数据视图模型
@property (nonatomic,retain) TableViewDataSource_section *arrayDataSource;

@end

@implementation YZGHospitalListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initTableView];
    [self getHospitalListRequest];
}

- (void)initTableView{
    self.dataSource = [[NSMutableArray alloc] init];
    
    [self.tableView registerNib:[HospitalListTableViewCell ycy_nib] forCellReuseIdentifier:[HospitalListTableViewCell ycy_className]];
    
    TableViewCellConfigureBlock configureCell = ^(HospitalListTableViewCell *cell, CoreObject_Hospital *model) {
//        [cell configureForCell:model];
        [cell configureForCell:model andKeyword:self.searchText.text];
    };
    self.arrayDataSource = [[TableViewDataSource_section alloc] initWithItems:_dataSource
                                                               cellIdentifier:[HospitalListTableViewCell ycy_className]
                                                        configureCellBlock:configureCell];
    
    self.tableView.dataSource = self.arrayDataSource;
    self.tableView.tableFooterView = [UIView new];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    CoreObject_Hospital *hospital = self.dataSource[indexPath.section];
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(chooseHospitalName:andHospitalId:)]) {
        [self.delegate chooseHospitalName:hospital.name andHospitalId:hospital.gid];
    }
    [self.navigationController popViewControllerAnimated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 44;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self closeKeyBoard];
    [self getHospitalListRequest];
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --------   网络请求------

- (void)getHospitalListRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:[CoreObject_Hospital class] andIsPersistence:NO andNumber:1];
}
#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    if (manager.requestNumber == 1) {
//        NSString *url = [NSString stringWithFormat:@"%@/%@",GetHospitalListAPI,self.searchText.text];
//
//        NSString *encodeUrl = [url stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
        
        return @{@"url":GetHospitalListAPI,@"params":@{@"province":emptyTransform(self.province),@"city":emptyTransform(self.city),@"county":emptyTransform(self.county),@"keyword":self.searchText.text}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([result isKindOfClass:[NSDictionary class]] && [manager.response.content[@"success"] integerValue] != 1) {
//        [XHToast showCenterWithText:result[@"msg"]];
    }else{
        if (manager.requestNumber == 1){
//
//            NSArray *models = [CoreObject_Hospital mj_objectArrayWithKeyValuesArray:result];
            
            [self.dataSource removeAllObjects];
            [self.dataSource addObjectsFromArray:manager.model];
            [self.tableView reloadData];
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
