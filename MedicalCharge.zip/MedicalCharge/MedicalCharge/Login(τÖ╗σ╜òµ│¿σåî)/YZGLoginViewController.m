//
//  YZGLoginViewController.m
//  MedicalCharge
//
//  Created by yangchengyou on 2018/2/28.
//  Copyright © 2018年 NULLS. All rights reserved.
//

#import "YZGLoginViewController.h"
#import "YZGRegisterViewController.h"
#import "YZGForgetPWDViewController.h"
#import "AppDelegate.h"
#import "YZGHospitalListViewController.h"
@interface YZGLoginViewController ()<YZGHospitalListViewControllerDelegate,UITextFieldDelegate>

@property (nonatomic,assign) NSInteger userType;

@end

@implementation YZGLoginViewController

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:animated];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:animated];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.hospitalName.text = GETNSUserDefault(@"hospital");
    self.userName.text = GETNSUserDefault(@"hospitalLoginName");
    self.userType = 1;
}

#pragma mark -- 选择所属医院
- (IBAction)chooseAddressAction:(id)sender {
    YZGHospitalListViewController *controller = [[YZGHospitalListViewController alloc] init];
    controller.delegate = self;
    controller.province = GETNSUserDefault(@"province");
    controller.city = GETNSUserDefault(@"city");
    controller.county = GETNSUserDefault(@"area");
    [self.navigationController pushViewController:controller animated:YES];
}

#pragma mark - - YZGHospitalListViewControllerDelegate
- (void)chooseHospitalName:(NSString *)name andHospitalId:(NSString *)hId{
    self.hospitalName.text = name;
}

- (IBAction)loginButtonAction:(id)sender {
    if (self.userType == 1) {
        if (self.hospitalName.text.length == 0) {
            [XHToast showBottomWithText:@"请选择所属医院~"];
            return;
        }
    }
    
    if (self.userName.text.length == 0) {
        [XHToast showBottomWithText:@"请输入用户名~"];
        return;
    }
    if (self.password.text.length == 0) {
        [XHToast showBottomWithText:@"请输入密码~"];
        return;
    }
    if (self.password.text.length < 6 || self.password.text.length > 16) {
        [XHToast showBottomWithText:@"请输入6-16位密码~"];
        return;
    }
    
    [self loginRequest];
}

- (IBAction)eyesButtonAction:(id)sender {
    UIButton *button = (UIButton *)sender;
    button.selected = !button.selected;
    self.password.secureTextEntry = !button.selected;
}


- (IBAction)registerButtonAction:(id)sender {
    YZGRegisterViewController *controller = [[YZGRegisterViewController alloc] init];
    [self.navigationController pushViewController:controller animated:YES];
}


- (IBAction)forgetButtonAction:(id)sender {
    YZGForgetPWDViewController *controller = [[YZGForgetPWDViewController alloc] init];
    [self.navigationController pushViewController:controller animated:YES];
}

#pragma mark -- 角色切换 11 12
- (IBAction)roleChooseAction:(id)sender {
    
    UIButton *button = (UIButton *)sender;
    
    for (int i = 11; i < 13; i ++) {
        UIButton *btn =(UIButton *)[self.view viewWithTag:i];
        btn.selected = NO;
    }
    
    button.selected = YES;
    
    if (button.tag == 11) {
        self.hospitalView.hidden = NO;
        self.hospitalHight.constant = 50;
    }else{
        self.hospitalView.hidden = YES;
        self.hospitalHight.constant = 0;
    }
    self.userType = button.tag - 10;
    if (self.userType == 1) {
        self.hospitalName.text = GETNSUserDefault(@"hospital");
        self.userName.text = GETNSUserDefault(@"hospitalLoginName");
    }else if (self.userType == 2){
        self.userName.text = GETNSUserDefault(@"supplierLoginName");
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self closeKeyBoard];
    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark --------   网络请求------

- (void)loginRequest{
    [CHNetworkingConfig shardInstance].requestType = 2;
    [CHNetWorking ch_GetRequestWithDeleagteTarget:self andRequestType:CHAPIManagerRequestTypePost andClass:nil andIsPersistence:NO andNumber:1];
}
#pragma mark -- 请求代理 -- 参数配置  成功失败回调
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    if (manager.requestNumber == 1) {//登录
        NSString *name = self.hospitalName.text;
        if (self.userType == 2) {
            name = @"";
        }
        return @{@"url":LoginAPI,@"params":@{@"UserType":@(self.userType),@"Name":name,@"LoginName":self.userName.text,@"LoginPassword":self.password.text}};
    }
    return nil;
}

- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    [super ch_requestCallAPISuccess:manager];
    NSDictionary *result = manager.response.content;
    if ([manager.response.content[@"success"] integerValue] != 1) {
        [XHToast showCenterWithText:result[@"msg"]];
    }else{
        if (manager.requestNumber == 1){
            PUTNSUserDefault(@"role", StringValue(self.userType));
            PUTNSUserDefault(@"logintoken", result[@"data"][@"tokenData"][@"access_token"]);
            PUTNSUserDefault(@"userId", result[@"data"][@"user"][@"uid"]);
            PUTNSUserDefault(@"headPath", result[@"data"][@"user"][@"headImg"]);
            PUTNSUserDefault(@"realName", result[@"data"][@"user"][@"realName"]);
            PUTNSUserDefault(@"nickname", result[@"data"][@"user"][@"loginName"]);
            PUTNSUserDefault(@"loginname", result[@"data"][@"user"][@"loginName"]);
            PUTNSUserDefault(@"phone", result[@"data"][@"user"][@"mobilePhone"]);
            
            PUTNSUserDefault(@"department", emptyTransform(result[@"data"][@"user"][@"departmentName"]));
            PUTNSUserDefault(@"company", result[@"data"][@"user"][@"name"]);
            PUTNSUserDefault(@"isEngineer", result[@"data"][@"user"][@"isEngineer"]);
            PUTNSUserDefault(@"email", result[@"data"][@"user"][@"email"]);
            if (self.userType == 1) {
                PUTNSUserDefault(@"hospitalLoginName", self.userName.text);
                PUTNSUserDefault(@"hospital", result[@"data"][@"user"][@"name"]);
            }else if (self.userType == 2){
                PUTNSUserDefault(@"supplierLoginName", self.userName.text);
            }
            
            [(AppDelegate *)[[UIApplication sharedApplication] delegate] setMain];
        }
    }
}

- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    [super ch_requestCallApiFail:manager];
    [XHToast showCenterWithText:@"网络错误~"];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
