//
//  BaseViewController.m
//  OFF GRID
//
//  Created by yangchengyou on 17/4/24.
//  Copyright © 2017年 NULLS. All rights reserved.
//

#import "BaseViewController.h"
#import <objc/runtime.h>
#import <MapKit/MapKit.h>
#import "AppDelegate.h"
//#import "LoginViewController.h"

@interface BaseViewController ()<UIScrollViewDelegate,UIGestureRecognizerDelegate,UIActionSheetDelegate>
{
    NSDictionary *_mapInfo;//记录终点坐标
}
@property (nonatomic,retain) UITableView *tableView;//配置全局的刷新

@end

@implementation BaseViewController

#pragma mark --返回按钮标题
- (NSString *)ycy_navigationItemBackBarButtonTitle{
    return @"";
}


- (void)clickReturnTopViewBtnAction{
    _coverToolBarView.hidden = YES;
}

#pragma mark -- 系统自带的返回手势代理
- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer{
    if (self.navigationController.viewControllers.count == 1)
    {
        return NO;
    }else
        return YES;
}
    
- (void)viewDidLoad {
    [super viewDidLoad];
    
    //添加右滑返回手势
    self.navigationController.interactivePopGestureRecognizer.delegate = self;
    
    self.navigationController.navigationBar.translucent = NO;
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.view.backgroundColor = BackGroundColor;
    self.navigationController.navigationBar.hidden=NO;
    self.navigationItem.hidesBackButton = YES;
    //navigation 文字颜色大小
    NSMutableDictionary *titleTextAttributes = [NSMutableDictionary dictionary];
    [titleTextAttributes setObject:[UIFont systemFontOfSize:18] forKey:NSFontAttributeName];
    [titleTextAttributes setObject:TextCOLOR333 forKey:NSForegroundColorAttributeName];
    [self.navigationController.navigationBar setTitleTextAttributes:titleTextAttributes];
    
    //隐藏shadowimage线（需先设置backgroundimage）--rootviewcontroller也设置了颜色
    self.navigationController.navigationBar.barTintColor = NavigationCOLOR;
    self.navigationController.navigationBar.backgroundColor=NavigationCOLOR;
    [self.navigationController.navigationBar setBackgroundImage:[self createImageWithColor:NavigationCOLOR] forBarMetrics:UIBarMetricsDefault];
    self.navigationController.navigationBar.shadowImage = [self createImageWithColor:LineCOLOR];
    
    //tabbar设置shawow
    self.tabBarController.tabBar.shadowImage = [self createImageWithColor:LineCOLOR];
    self.tabBarController.tabBar.backgroundColor = TabbarColor;
    self.tabBarController.tabBar.backgroundImage = [self createImageWithColor:TabbarColor];
    
    //返回按钮
    WeakSelf
    [self actionCustomLeftBtnWithNrlImage:@"backImg" htlImage:nil title:@"" btnFrame:CGRectMake(0, 0, 44, 44) action:^{
        [weakSelf.navigationController popViewControllerAnimated:YES];
    }];
    
    //tableview背景色
    if (_tableView) {
        self.tableView.backgroundColor = LightGrayColor;
    }
}

#pragma mark -- 换导航栏颜色
- (void)setWhiteNavigation{
    //返回按钮
    WeakSelf
    [self actionCustomLeftBtnWithNrlImage:@"backImg" htlImage:nil title:@"" btnFrame:CGRectMake(0, 0, 44, 44) action:^{
        [weakSelf.navigationController popViewControllerAnimated:YES];
    }];
    
    //navigation 文字颜色大小
    NSMutableDictionary *titleTextAttributes = [NSMutableDictionary dictionary];
    [titleTextAttributes setObject:[UIFont boldSystemFontOfSize:18] forKey:NSFontAttributeName];
    [titleTextAttributes setObject:TextCOLOR333 forKey:NSForegroundColorAttributeName];
    [self.navigationController.navigationBar setTitleTextAttributes:titleTextAttributes];
    
    //隐藏shadowimage线（需先设置backgroundimage）--rootviewcontroller也设置了颜色
    self.navigationController.navigationBar.barTintColor = WhiteColor;
    self.navigationController.navigationBar.backgroundColor = WhiteColor;
    [self.navigationController.navigationBar setBackgroundImage:[self createImageWithColor:WhiteColor] forBarMetrics:UIBarMetricsDefault];
    self.navigationController.navigationBar.shadowImage = [self createImageWithColor:LineCOLOR];
}

- (void)showLogoToTitleView{
    UIView *view = [[UIView alloc] init];
    view.backgroundColor = [UIColor clearColor];
    
    UIImageView *titleImage = [[UIImageView alloc] init];
    titleImage.image = YCYImage(@"logo");
    titleImage.frame = CGRectMake(0, 0, 94, 25);
    titleImage.center = view.center;
    [view addSubview:titleImage];
    self.navigationItem.titleView = view;
}

- (void)addNavigationActionForLeftButton:(UIButton *)leftButton andRight:(UIButton *)rightButton{

    CGFloat spaceWidth = (YCYScreen_Width - 32- 80 - 94)/2;
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    UIButton*leftSpacing = [UIButton buttonWithType:UIButtonTypeCustom];
    leftSpacing.frame = CGRectMake(0, 0, spaceWidth, 44);
    leftSpacing.backgroundColor = [UIColor clearColor];
    [leftSpacing addTarget:self action:@selector(spacerClickAction) forControlEvents:UIControlEventTouchUpInside];
    leftSpacing.backgroundColor = [UIColor clearColor];
    UIBarButtonItem *leftSpacingBar = [[UIBarButtonItem alloc] initWithCustomView:leftSpacing];
    self.navigationItem.leftBarButtonItems = @[leftItem,leftSpacingBar];
    
    
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithCustomView:rightButton];
    UIButton*rightSpacing = [UIButton buttonWithType:UIButtonTypeCustom];
    rightSpacing.frame = CGRectMake(0, 0, spaceWidth + 30, 44);
    rightSpacing.backgroundColor = [UIColor clearColor];
    [rightSpacing addTarget:self action:@selector(spacerClickAction) forControlEvents:UIControlEventTouchUpInside];
    rightSpacing.backgroundColor = [UIColor clearColor];
    UIBarButtonItem *rightSpacingBar = [[UIBarButtonItem alloc] initWithCustomView:rightSpacing];
    
    self.navigationItem.rightBarButtonItems = @[rightItem,rightSpacingBar];
}

#pragma mark -- 点击导航空白处
- (void)spacerClickAction{
    //系统自带点击状态栏回顶部
    [self.tableView ycy_scrollToTopAnimated:YES];
}

- (BOOL)judgeLogin{
    NSString *token = GETNSUserDefault(@"token");
    if (token.length == 0) {
        
        return NO;
    }
    return YES;
}

- (void)closeKeyBoard{
    [self.view endEditing:YES];
}

/**
 数据加载动画配置
 */
- (void)initWithTableViewRefreshAnimation{
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(uploadHeader)];
    self.tableView.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(uploadFooter)];
//    self.tableView.mj_footer.automaticallyHidden = YES;
}

#pragma mark -- 关闭刷新状态
- (void)closeRefreshStatus{
    [self.tableView.mj_header endRefreshing];
    [self.tableView.mj_footer endRefreshing];
}

/**
 下拉刷新
 */
- (void)uploadHeader{
    
}

/**
 上拉加载
 */
- (void)uploadFooter{
    
}

  
#pragma mark -- 颜色转image
- (UIImage*)createImageWithColor:(UIColor*)color
    {
        CGRect rect=CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
        UIGraphicsBeginImageContext(rect.size);
        CGContextRef context = UIGraphicsGetCurrentContext();
        CGContextSetFillColorWithColor(context, [color CGColor]);
        CGContextFillRect(context, rect);
        UIImage *theImage = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        return theImage;
}

#pragma mark -- 隐藏返回按钮
- (void)hideCustomBackButtonItem{
    self.navLeftBtn.hidden = YES;
}

- (void)showNavigationShadowImage{
    self.navigationController.navigationBar.shadowImage = [self createImageWithColor:YCYHexColor(@"e1e1e1")];
}

- (void)hideNavigationShadowImage{
    self.navigationController.navigationBar.shadowImage = [UIImage new];
}
    
#pragma mark -actionCustomLeftBtnWithNrlImage
- (void)actionCustomLeftBtnWithNrlImage:(NSString *)nrlImage htlImage:(NSString *)hltImage
                                  title:(NSString *)title
                               btnFrame:(CGRect)frame
                                 action:(void(^)())btnClickBlock {
    self.navLeftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.navLeftBtn setBackgroundColor:[UIColor clearColor]];
    objc_setAssociatedObject(self.navLeftBtn, &btnClickAction, btnClickBlock, OBJC_ASSOCIATION_COPY);
    [self actionCustomNavBtn:self.navLeftBtn nrlImage:nrlImage htlImage:hltImage title:title btnFrame:frame ];
    self.navLeftBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    UIBarButtonItem *negativeSpacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem: UIBarButtonSystemItemFixedSpace target:nil action:nil];
    negativeSpacer.width = -5;  //偏移距离  -向左偏移, +向右偏移
    self.navigationItem.leftBarButtonItems = @[negativeSpacer, [[UIBarButtonItem alloc] initWithCustomView:self.navLeftBtn]];
}
    
#pragma mark -actionCustomRightBtnWithNrlImage
- (void)actionCustomRightBtnWithNrlImage:(NSString *)nrlImage htlImage:(NSString *)hltImage
                                   title:(NSString *)title
                                btnFrame:(CGRect)frame
                                  action:(void(^)())btnClickBlock {
    self.navRightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    objc_setAssociatedObject(self.navRightBtn, &btnClickAction, btnClickBlock, OBJC_ASSOCIATION_COPY);
    [self actionCustomNavBtn:self.navRightBtn nrlImage:nrlImage htlImage:hltImage title:title btnFrame:frame];
    self.navRightBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    UIBarButtonItem *negativeSpacer = [[UIBarButtonItem alloc] initWithBarButtonSystemItem: UIBarButtonSystemItemFixedSpace target:nil action:nil];
    negativeSpacer.width = -3;  //偏移距离  +向左偏移, -向右偏移
    self.navigationItem.rightBarButtonItems = @[negativeSpacer, [[UIBarButtonItem alloc] initWithCustomView:self.navRightBtn]];
}
    
#pragma mark -actionCustomNavBtn
- (void)actionCustomNavBtn:(UIButton *)btn nrlImage:(NSString *)nrlImage
                  htlImage:(NSString *)hltImage
                     title:(NSString *)title btnFrame:(CGRect)frame{
    if (frame.size.width > 0) {
        btn.frame = frame;
    }else{
        btn.frame = DefaultFrame;
    }
    if (hltImage) {
        
        [btn setImage:[UIImage imageNamed:nrlImage] forState:UIControlStateNormal];
        [btn setImage:[UIImage imageNamed:hltImage] forState:UIControlStateHighlighted];
    }else{
        [btn setImage:[UIImage imageNamed:nrlImage] forState:UIControlStateNormal];
    }
    if (title) {
        btn.titleLabel.font = [UIFont systemFontOfSize:16];
        [btn setTitle:title forState:UIControlStateNormal];
//        [btn setTitle:title forState:UIControlStateHighlighted];
        [btn setTitleColor:TextCOLOR333 forState:UIControlStateNormal];
//        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateHighlighted];
    }
    
    //    [btn sizeToFit];
    [btn addTarget:self action:@selector(actionBtnClick:) forControlEvents:UIControlEventTouchUpInside];
}

#pragma mark -actionBtnClick
- (void)actionBtnClick:(UIButton *)btn {
    void (^btnClickBlock) (void) = objc_getAssociatedObject(btn, &btnClickAction);
    btnClickBlock();
}


#pragma mark -- 地图  导航
- (void)openLocationMap:(NSDictionary *)dic{
    _mapInfo = dic;
    NSMutableArray *maps = [NSMutableArray array];
    
    UIActionSheet *actionSheet;
    if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"baidumap://"]]) {
        if ([[UIApplication sharedApplication] canOpenURL:
             [NSURL URLWithString:@"comgooglemaps://"]]) {
            [maps addObject:@"谷歌地图"];
            actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"百度地图",@"谷歌地图",@"苹果地图", nil];
        }else{
            actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"百度地图",@"苹果地图", nil];
        }
        [maps addObject:@"百度地图"];
    }else{
        if ([[UIApplication sharedApplication] canOpenURL:
             [NSURL URLWithString:@"comgooglemaps://"]]) {
            [maps addObject:@"谷歌地图"];
            actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"谷歌地图",@"苹果地图", nil];
        }else{
            actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"苹果地图", nil];
        }
    }
    
    [actionSheet showInView:self.view];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if ([[actionSheet buttonTitleAtIndex:buttonIndex] isEqualToString:@"百度地图"]) {
        [self openBaiDuMap:_mapInfo];
    }else if ([[actionSheet buttonTitleAtIndex:buttonIndex] isEqualToString:@"谷歌地图"]){
        [self openGoogleMap:_mapInfo];
    }else if ([[actionSheet buttonTitleAtIndex:buttonIndex] isEqualToString:@"苹果地图"]){
        [self openAppleMap:_mapInfo];
    }else{
        
    }
}

/*!
 @method
 @brief mov格式视频转换为MP4格式
 @param movUrl   mov视频路径
 @result  MP4格式视频路径
 */
//- (NSURL *)convert2Mp4:(NSURL *)movUrl
//{
//    NSURL *mp4Url = nil;
//    AVURLAsset *avAsset = [AVURLAsset URLAssetWithURL:movUrl options:nil];
//    NSArray *compatiblePresets = [AVAssetExportSession exportPresetsCompatibleWithAsset:avAsset];
//
//    if ([compatiblePresets containsObject:AVAssetExportPresetHighestQuality]) {
//        AVAssetExportSession *exportSession = [[AVAssetExportSession alloc]initWithAsset:avAsset
//                                                                              presetName:AVAssetExportPresetHighestQuality];
//        NSString *mp4Path = [NSString stringWithFormat:@"%@/%d%d.mp4", [EMCDDeviceManager dataPath], (int)[[NSDate date] timeIntervalSince1970], arc4random() % 100000];
//        mp4Url = [NSURL fileURLWithPath:mp4Path];
//        exportSession.outputURL = mp4Url;
//        exportSession.shouldOptimizeForNetworkUse = YES;
//        exportSession.outputFileType = AVFileTypeMPEG4;
//        dispatch_semaphore_t wait = dispatch_semaphore_create(0l);
//        [exportSession exportAsynchronouslyWithCompletionHandler:^{
//            switch ([exportSession status]) {
//                case AVAssetExportSessionStatusFailed: {
//                    NSLog(@"failed, error:%@.", exportSession.error);
//                } break;
//                case AVAssetExportSessionStatusCancelled: {
//                    NSLog(@"cancelled.");
//                } break;
//                case AVAssetExportSessionStatusCompleted: {
//                    NSLog(@"completed.");
//                } break;
//                default: {
//                    NSLog(@"others.");
//                } break;
//            }
//            dispatch_semaphore_signal(wait);
//        }];
//        long timeout = dispatch_semaphore_wait(wait, DISPATCH_TIME_FOREVER);
//        if (timeout) {
//            NSLog(@"timeout.");
//        }
//        if (wait) {
//            //dispatch_release(wait);
//            wait = nil;
//        }
//    }
//
//    return mp4Url;
//}

#pragma mark ----------------导航------------------------------

//百度地图
- (void)openBaiDuMap:(NSDictionary *)dic{
    //百度地图
    if ([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"baidumap://"]]) {
        NSString *urlString = [[NSString stringWithFormat:@"baidumap://map/direction?origin={{我的位置}}&destination=latlng:%@,%@|name=终点&mode=driving&coord_type=bd09ll",dic[@"la"],dic[@"ln"]]stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlString]];
    }else{
//        [XHToast showBottomWithText:@"打开失败~"];
    }
    
}

//谷歌地图
- (void)openGoogleMap:(NSDictionary *)dic{
    NSURL *testURL = [NSURL URLWithString:@"comgooglemaps://"];
    if ([[UIApplication sharedApplication] canOpenURL:testURL]) {
        //        NSString *directionsRequest = [NSString stringWithFormat:@"comgooglemaps-x-callback://?saddr=&daddr=%@,%@&x-success=%@&x-source=%@&directionsmode=driving",dic[@"la"],dic[@"ln"],@"OFFGRID//?resume=true",@"OFF GRID"];
        NSString *directionsRequest = [NSString stringWithFormat:@"comgooglemaps://?saddr=&daddr=%@,%@&directionsmode=driving&zoom=17",dic[@"la"],dic[@"ln"]];
        
        NSURL *directionsURL = [NSURL URLWithString:directionsRequest];
        [[UIApplication sharedApplication] openURL:directionsURL];
    } else {
//        [XHToast showBottomWithText:@"打开失败~"];
    }
}

//高德地图
- (void)openGaoDeMap:(NSDictionary *)dic{
    if ([[UIApplication sharedApplication]canOpenURL:[NSURL URLWithString:@"iosamap://"]]) {
        CLLocation *location = [[CLLocation alloc] initWithLatitude:[dic[@"la"] doubleValue] longitude:[dic[@"ln"] doubleValue]];
//        location = [location locationMarsFromBearPaw];
        NSString *urlString = [[NSString stringWithFormat:@"iosamap://navi?sourceApplication=%@&backScheme=%@&poiname=%@&lat=%f&lon=%f&dev=1&style=2",@"OFF GRID", @"OFFGRID", @"终点", location.coordinate.latitude, location.coordinate.longitude] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
        [[UIApplication sharedApplication]openURL:[NSURL URLWithString:urlString]];
    }else{
//        [XHToast showBottomWithText:@"打开失败~"];
    }
    
    
}

//苹果地图
- (void)openAppleMap:(NSDictionary *)dic
{
    CLLocation *location = [[CLLocation alloc] initWithLatitude:[dic[@"la"] doubleValue] longitude:[dic[@"ln"] doubleValue]];
    //    location = [location locationMarsFromBearPaw];
    CLLocationCoordinate2D gps = location.coordinate;
    MKMapItem *currentLoc = [MKMapItem mapItemForCurrentLocation];
    MKMapItem *toLocation = [[MKMapItem alloc] initWithPlacemark:[[MKPlacemark alloc] initWithCoordinate:gps addressDictionary:nil]];
    NSArray *items = @[currentLoc,toLocation];
    NSDictionary *info = @{
                          MKLaunchOptionsDirectionsModeKey : MKLaunchOptionsDirectionsModeDriving,
                          MKLaunchOptionsMapTypeKey : @(MKMapTypeStandard),
                          MKLaunchOptionsShowsTrafficKey : @(YES)
                          };
    [MKMapItem openMapsWithItems:items launchOptions:info];
}
    

- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self closeKeyBoard];
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    [self closeKeyBoard];
}

#pragma mark== networkdelegate
- (NSDictionary *)ch_paramWith:(CHNetWorking *)manager{
    return nil;
}
- (void)ch_requestCallApiFail:(CHNetWorking *)manager{
    if (manager.requestNumber == 1) {
        [self.tableView.mj_header endRefreshing];
    }
}
- (void)ch_requestCallAPISuccess:(CHNetWorking *)manager{
    if (manager.requestNumber == 1) {
        [self.tableView.mj_header endRefreshing];
        if ([manager.response.content[@"success"] integerValue] != 1) {
            self.tableView.mj_footer.state = MJRefreshStateNoMoreData;
        }
    }
    NSDictionary *result = manager.response.content;
    
    if (manager.modeClass && [result[@"success"] integerValue] == 1) {//模型转换
        id object = nil;
        if ([result[@"data"] isKindOfClass:[NSArray class]]) {
            object = result[@"data"];
        }else{
            object = result[@"data"][@"data"]?result[@"data"][@"data"]:result[@"data"];
        }
        id model;
        if ([object isKindOfClass:[NSArray class]]) {
            model = [manager.modeClass mj_objectArrayWithKeyValuesArray:object];
        }else if ([object isKindOfClass:[NSDictionary class]] || [object isKindOfClass:[NSString class]]){
            model = [manager.modeClass mj_objectWithKeyValues:object];
        }
        manager.model = model;
    }else if([result isKindOfClass:[NSDictionary class]] &&  [result[@"status"] integerValue] == 0){
        if ([result[@"msg"] isEqualToString:@"会话过期，请重新登录！"]) {
            REMOVENSUserDefault(@"userId");
            REMOVENSUserDefault(@"logintoken");
            
            [(AppDelegate *)[[UIApplication sharedApplication] delegate] setLogin];
        }
    }
}

//- (void)ch_startAccessTheNetwork:(CHNetWorking *)manager{
////    [YCYLoadingView showCoatingView];
//}
//
//- (void)ch_endAccessTheNetwork:(CHNetWorking *)manager{
////    [YCYLoadingView stopActivity];
//}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
