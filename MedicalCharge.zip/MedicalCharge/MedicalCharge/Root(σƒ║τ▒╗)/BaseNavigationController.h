//
//  BaseNavigationController.h
//  Social
//
//  Created by yangchengyou on 17/11/1.
//  Copyright © 2017年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseNavigationController : UINavigationController
- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated;
@end
