//
//  GuideViewController.m
//  OFF GRID
//
//  Created by yangchengyou on 17/5/15.
//  Copyright © 2017年 NULLS. All rights reserved.
//

#import "GuideViewController.h"
#import "AppDelegate.h"
#define IMAGE_SIZE 3
@interface GuideViewController ()

@property(nonatomic,strong)UIScrollView * scrollView;

@end

@implementation GuideViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self setupLeadImage];
}

-(BOOL)prefersStatusBarHidden{
    return YES;
}

-(void)setupLeadImage{
    
    self.scrollView  = [[UIScrollView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    [self.view addSubview:self.scrollView];
    self.scrollView.pagingEnabled = YES;
    self.scrollView.bounces = NO;
    self.scrollView.showsHorizontalScrollIndicator = NO;
    self.scrollView.contentSize = CGSizeMake(CGRectGetWidth(self.scrollView.frame) * IMAGE_SIZE, 0);
//    self.scrollView.delegate = self;
    
    CGFloat w = self.scrollView.frame.size.width;
    CGFloat h = self.scrollView.frame.size.height;
    
    for (int i = 0; i < IMAGE_SIZE; i++) {
        UIImageView * imageview = [[UIImageView alloc]initWithFrame:CGRectMake(w * i, 0, w, h)];
        imageview.userInteractionEnabled = YES;
        [self.scrollView addSubview:imageview];
        NSString * img;
//        if (YCYScreen_Height == 480) {
//            img =[NSString stringWithFormat:@"%d.960",i + 1];
//        }else if (YCYScreen_Height == 568){
//            img =[NSString stringWithFormat:@"%d.1136",i + 1];
//        }else if (YCYScreen_Height == 667){
//            img =[NSString stringWithFormat:@"%d.1334",i + 1];
//        }else if (YCYScreen_Height == 736){
//            img =[NSString stringWithFormat:@"%d.2208",i + 1];
//        }else{
//            img =[NSString stringWithFormat:@"%d.2208",i + 1];
//        }
        img =[NSString stringWithFormat:@"引导页%d",i + 1];
        imageview.image = [UIImage imageNamed:img];
        if (i == IMAGE_SIZE - 1) {
            UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake((YCYScreen_Width - 200)/2, YCYScreen_Height - 160, 200, 160)];
            btn.backgroundColor = [UIColor clearColor];
            [imageview addSubview:btn];
            [btn setTitle:@"" forState:UIControlStateNormal];
            [btn setTitleColor:MainCOLOR forState:UIControlStateNormal];
//            btn.layer.cornerRadius = 5;
//            btn.layer.borderWidth = 1;
//            btn.layer.borderColor = MainCOLOR.CGColor;
            btn.titleLabel.font = YCYFont(14);
            [btn addTarget:self action:@selector(showRoot) forControlEvents:UIControlEventTouchUpInside];
        }
    }
}

-(void)showRoot{
    
    [(AppDelegate *)[[UIApplication sharedApplication] delegate] setMain];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
