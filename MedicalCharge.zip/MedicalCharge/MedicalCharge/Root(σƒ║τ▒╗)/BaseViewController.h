//
//  BaseViewController.h
//  OFF GRID
//
//  Created by yangchengyou on 17/4/24.
//  Copyright © 2017年 NULLS. All rights reserved.
//

#import <UIKit/UIKit.h>
#define DefaultFrame CGRectMake(0, 0, 22, 22)
//#import "UINavigationController+StatusBarStyle.h"
static char *btnClickAction;
@interface BaseViewController : UIViewController<CHNetWorkingDelegate>
@property (nonatomic,retain) UIView *coverToolBarView;//回到顶部view



@property (nonatomic, strong) UIButton *navLeftBtn;
@property (nonatomic, strong) UIButton *navRightBtn;
    
/**
 leftItem
 
 @param nrlImage 普通图片 没有设nil
 @param hltImage 高亮图片 没有设nil
 @param title title   没有设nil
 @param frame 按钮大小  默认DefaultFrame  {22 ，22}
 @param btnClickBlock 点击事件回调
 */
- (void)actionCustomLeftBtnWithNrlImage:(NSString *)nrlImage
                               htlImage:(NSString *)hltImage
                                  title:(NSString *)title
                               btnFrame:(CGRect)frame
                                 action:(void(^)())btnClickBlock;
/**
 rightItem
 
 @param nrlImage 普通图片 没有设nil
 @param hltImage 高亮图片 没有设nil
 @param title title   没有设nil
 @param frame 按钮大小  默认DefaultFrame  {22 ，22}
 @param btnClickBlock 点击事件回调
 */
- (void)actionCustomRightBtnWithNrlImage:(NSString *)nrlImage
                                htlImage:(NSString *)hltImage
                                   title:(NSString *)title
                                btnFrame:(CGRect)frame
                                  action:(void(^)())btnClickBlock;

/**
 设置白色导航栏
 */
- (void)setWhiteNavigation;
/**
 隐藏自定义返回按钮
 */
- (void)hideCustomBackButtonItem;

/**
 显示shadowimage
 */
- (void)showNavigationShadowImage;

/**
 隐藏shadowimage
 */
- (void)hideNavigationShadowImage;

/**
 标题栏显示logo
 */
- (void)showLogoToTitleView;
/**
 添加点击导航栏空白处回到顶部事件
 */
- (void)addNavigationActionForLeftButton:(UIButton *)leftButton andRight:(UIButton *)rightButton;

/**
 点击回到顶部按钮事件
 */
- (void)clickReturnTopViewBtnAction;


/**
 导航

 @param dic 坐标字典
 @{@"la":[NSString stringWithFormat:@"%lf",selectAnno.latitude],@"ln":[NSString stringWithFormat:@"%lf",selectAnno.longitude]}
 */
- (void)openLocationMap:(NSDictionary *)dic;
/**
 打开百度地图

 @param dic @{@"la":@"",@"ln":@""}
 */
- (void)openBaiDuMap:(NSDictionary *)dic;

- (void)openGoogleMap:(NSDictionary *)dic;

- (void)openGaoDeMap:(NSDictionary *)dic;

- (void)openAppleMap:(NSDictionary *)dic;
/**
 mjrefresh配置的刷新加载动画
 */
- (void)initWithTableViewRefreshAnimation;

/**
 关闭刷新状态
 */
- (void)closeRefreshStatus;
/**
 上拉 下拉
 */
- (void)uploadHeader;
- (void)uploadFooter;

//判断是否登录 YES 已登录  NO未登录
- (BOOL)judgeLogin;

//关闭键盘
- (void)closeKeyBoard;

/*!
 @method
 @brief mov格式视频转换为MP4格式
 @param movUrl   mov视频路径
 @result  MP4格式视频路径
 */
- (NSURL *)convert2Mp4:(NSURL *)movUrl;
@end
