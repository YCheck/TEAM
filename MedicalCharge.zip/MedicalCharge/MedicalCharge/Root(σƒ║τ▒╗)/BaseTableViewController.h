//
//  BaseTableViewController.h
//  OFF GRID
//
//  Created by yangchengyou on 17/5/10.
//  Copyright © 2017年 NULLS. All rights reserved.
//
#define DefaultFrame CGRectMake(0, 0, 22, 22)

static char *btnClickAction;
#import <UIKit/UIKit.h>
#pragma mark -- 一般用于storyboard静态界面
@interface BaseTableViewController : UITableViewController<CHNetWorkingDelegate>
@property (nonatomic,retain) UIView *coverToolBarView;//回到顶部view


@property (nonatomic, strong) UIButton *navLeftBtn;
@property (nonatomic, strong) UIButton *navRightBtn;

/**
 leftItem
 
 @param nrlImage 普通图片 没有设nil
 @param hltImage 高亮图片 没有设nil
 @param title title   没有设nil
 @param frame 按钮大小  默认DefaultFrame  {22 ，22}
 @param btnClickBlock 点击事件回调
 */
- (void)actionCustomLeftBtnWithNrlImage:(NSString *)nrlImage
                               htlImage:(NSString *)hltImage
                                  title:(NSString *)title
                               btnFrame:(CGRect)frame
                                 action:(void(^)())btnClickBlock;
/**
 rightItem
 
 @param nrlImage 普通图片 没有设nil
 @param hltImage 高亮图片 没有设nil
 @param title title   没有设nil
 @param frame 按钮大小  默认DefaultFrame  {22 ，22}
 @param btnClickBlock 点击事件回调
 */
- (void)actionCustomRightBtnWithNrlImage:(NSString *)nrlImage
                                htlImage:(NSString *)hltImage
                                   title:(NSString *)title
                                btnFrame:(CGRect)frame
                                  action:(void(^)())btnClickBlock;

/**
 隐藏自定义返回按钮
 */
- (void)hideCustomBackButtonItem;

/**
 显示shadowimage
 */
- (void)showNavigationShadowImage;

/**
 隐藏shadowimage
 */
- (void)hideNavigationShadowImage;

/**
 标题栏显示logo
 */
- (void)showLogoToTitleView;

/**
 点击回到顶部按钮事件
 */
- (void)clickReturnTopViewBtnAction;

//关闭键盘
- (void)closeKeyBoard;
@end
