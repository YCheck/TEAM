//
//  RootViewController.m
//  SocialApp
//
//  Created by yangchengyou on 17/2/22.
//  Copyright © 2017年 NULLS. All rights reserved.
//

#import "RootViewController.h"
#import "YZGHomePageViewController.h"
#import "YZGWorkMatterViewController.h"
#import "YZGMessageViewController.h"
#import "YZGMineViewController.h"
#import "BaseNavigationController.h"
@interface RootViewController ()<UITabBarControllerDelegate>
{
//    UIView *tabbarBackView;
}
@end

@implementation RootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.delegate = self;
    [self initViewControllers];
    [self customNavigationBar];
}

-(void)initViewControllers{
//    self.tabBar.shadowImage = [self createImageWithColor:HexColor(@"666666")];
//    self.tabBar.backgroundColor = HexColor(@"666666");
//    self.tabBar.backgroundImage = [self createImageWithColor:HexColor(@"666666")];
    //首页
    UIStoryboard *HomePageSB = [UIStoryboard storyboardWithName:@"HomePage" bundle:nil];
    UIViewController *HomePageVC = [HomePageSB instantiateViewControllerWithIdentifier:@"HomePageNavi"];
    [self addChildViewController:HomePageVC title:@"" normalimage:@"硅行-LOGO-nor" selectimage:@"硅行-LOGO"];
    //工作提醒
    UIStoryboard *WorkSB = [UIStoryboard storyboardWithName:@"Work" bundle:nil];
    UIViewController *workVC = [WorkSB instantiateViewControllerWithIdentifier:@"WorkNavi"];
    [self addChildViewController:workVC title:@"" normalimage:@"分类变色-nor" selectimage:@"分类变色"];
    //消息
    UIStoryboard *MessageSB = [UIStoryboard storyboardWithName:@"Message" bundle:nil];
    UIViewController *messageVC = [MessageSB instantiateViewControllerWithIdentifier:@"MessageNavi"];
    [self addChildViewController:messageVC title:@"" normalimage:@"消息变色-nor" selectimage:@"消息变色"];
    //我的
    UIStoryboard *MineSB = [UIStoryboard storyboardWithName:@"Mine" bundle:nil];
    UIViewController *mineVC = [MineSB instantiateViewControllerWithIdentifier:@"MineNavi"];
    [self addChildViewController:mineVC title:@"" normalimage:@"账户变色-nor" selectimage:@"账户变色"];
    
//    self.tabBar.opaque = YES;
    
    [self resetTabbar];
}

- (void)resetTabbar{
//    CALayer *shadowLine = [CALayer layer];
//    shadowLine.backgroundColor = HexColor(@"cccccc").CGColor;
//    shadowLine.frame = CGRectMake(0, 0, CGRectGetWidth(self.tabBar.frame), 0.5);
//    [self.tabBar.layer  addSublayer:shadowLine];
    
    
    
//    CGFloat width = Screen_Width/self.viewControllers.count;
//    CALayer *layer = [CALayer layer];
//    layer.contents = (id)[UIImage imageNamed:@"A1_fabu"].CGImage;
//    layer.frame = CGRectMake(width * 2 + (width - 50)/2, -12, 50, 50);
//    layer.backgroundColor = [UIColor clearColor].CGColor;
//    [self.tabBar.layer addSublayer:layer];

}

#pragma mark--添加到控制器
-(void)addChildViewController:(UIViewController *)childController title :(NSString *)title normalimage:(NSString *)normalimage selectimage:(NSString *)selectimage{
    
    childController.view.backgroundColor = BackGroundColor;
    childController.title = title;
//    childController.tabBarItem.titlePositionAdjustment = UIOffsetMake(0,-4);
    UIImage *normalImage = [UIImage imageNamed:normalimage];
    normalImage = [normalImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    childController.tabBarItem.image = normalImage;
    UIImage *selectedImage = [UIImage imageNamed:selectimage];
    // 声明：这张图片按照原始的样子显示出来，不要渲染成其他的颜色（比如说默认的蓝色）
    selectedImage = [selectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    childController.tabBarItem.selectedImage = selectedImage;
    childController.tabBarItem.imageInsets = UIEdgeInsetsMake(0, 0, -8, 0); 
//    UINavigationController * navi = [[UINavigationController alloc]initWithRootViewController:childController];
    [self addChildViewController:childController];
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
}

- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item{

}

- (void)tabBar:(UITabBar *)tabBar didBeginCustomizingItems:(NSArray<UITabBarItem *> *)items{
    
}

// 自定义UINavigationBar
- (void)customNavigationBar
{
    // 获取所有的视图控制器
    NSArray * viewControllers = self.viewControllers;
    
    for (UINavigationController * navi in viewControllers) {
        
        // 获取UINavigationBar
        UINavigationBar * navigationBar = navi.navigationBar;
        // 设置背景图片
        [navigationBar setBarTintColor:BackGroundColor];
        
        [navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont boldSystemFontOfSize:18],
                                                NSForegroundColorAttributeName:[UIColor whiteColor]}];
        
//        navigationBar.tintColor = [UIColor whiteColor];
        //navigationBar.translucent = NO;
        //UITabBarItem 的颜色
        [[UITabBarItem appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                           TextCOLOR999,NSForegroundColorAttributeName,
                                                           [UIFont systemFontOfSize:10],NSFontAttributeName,
                                                           nil]forState:UIControlStateNormal];
//
        [[UITabBarItem appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                           MainCOLOR,NSForegroundColorAttributeName,
                                                           [UIFont systemFontOfSize:10],NSFontAttributeName,
                                                           nil]forState:UIControlStateSelected];
        
        
    }
}

#pragma mark -- 颜色转image
- (UIImage*)createImageWithColor:(UIColor*)color
{
    CGRect rect=CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *theImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return theImage;
}


- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController NS_AVAILABLE_IOS(3_0){
    
//    NSArray *viewcontrollers = tabBarController.viewControllers;
    
//    NSInteger selectIndex = [viewcontrollers indexOfObject:viewController];
    
    
//    点击➕
//    UINavigationController *nav = (UINavigationController *)viewController;
//    UIViewController *vc = [nav.viewControllers firstObject];
//
//    NSString *token = Token;
//    if([vc isKindOfClass:[MineViewController class]] && token.length == 0){
//
//        LoginHomePageViewController *loginVC = [[LoginHomePageViewController alloc] init];
//        loginVC.hidesBottomBarWhenPushed = YES;
//        UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:loginVC];
//        [self presentViewController:navigation animated:YES completion:nil];
//
////       暂时不用 [tabBarController.viewControllers[tabBarController.selectedIndex] pushViewController:loginVC animated:YES];
//        return NO;
//    }
    
    return YES;
}

- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController{
    NSLog(@"didselect");
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
